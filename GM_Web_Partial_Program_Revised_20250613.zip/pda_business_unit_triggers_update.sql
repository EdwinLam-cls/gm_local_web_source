USE [DCL_MOBILE_SALES]
GO

/****** Object:  Trigger [dbo].[insert_pda_business_unit]    Script Date: 6/12/2025 5:19:10 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


ALTER trigger [dbo].[insert_pda_business_unit] on [dbo].[pda_business_unit]
AFTER INSERT
as 
   declare @vanCode nvarchar(50),
           @last_sale_no nvarchar(15),
             @last_sample_no varchar(20),
             @last_exchange_no varchar(30),
             @txn_last_no nvarchar(20),
			 @last_return_no varchar(20)
             


   select @vanCode=vancode,@last_sale_no=last_sale_no, @last_sample_no= last_sample_no,@last_exchange_no=last_exchange_no,@last_return_no=last_return_no from inserted;

--return

     --select top 1 @txn_last_no = refDocNo from txn_header where len(refDocNo) = len(@last_sale_no) and van_id =  right(@vancode,3) and txn_type = 'Sales' order by refDocNO
     --if (@@ROWCOUNT>0)
     --begin
            
     --   if (@txn_last_no >= @last_sale_no)
     --        update business_unit set last_sale_no =  right(@txn_last_no,len(@txn_last_no)-2) where vanCode = @vanCode

     --   if (@txn_last_no < @last_sale_no)
	      if (len(rtrim(ltrim(@last_sale_no))) > 4)
             update business_unit set last_sale_no =  right(@last_sale_no,len(@last_sale_no)-2) where vanCode = @vanCode and right(@last_sale_no,len(@last_sale_no)-2) >= last_sale_no


     --end    
             
     --select top 1 @txn_last_no = refDocNo from txn_header where len(refDocNo) = len(@last_exchange_no) and van_id =  right(@vancode,3) and txn_type = 'Exchange' order by refDocNO
     --if (@@ROWCOUNT>0)
     --begin
            
     --   if (@txn_last_no >= @last_exchange_no)
     --        update business_unit set last_exchange_no =  right(@txn_last_no,len(@txn_last_no)-2) where vanCode = @vanCode

     --   if (@txn_last_no < @last_exchange_no)
	      if (len(rtrim(ltrim(@last_exchange_no))) > 4)
             update business_unit set last_exchange_no =  right(@last_exchange_no,len(@last_exchange_no)-2) where vanCode = @vanCode  and right(@last_exchange_no,len(@last_exchange_no)-2) >= last_exchange_no


     --end  

     --select top 1 @txn_last_no = refDocNo from txn_header where len(refDocNo) = len(@last_sample_no) and van_id =  right(@vancode,3) and txn_type = 'Free' order by refDocNO
     --if (@@ROWCOUNT>0)
     --begin
            
     --   if (@txn_last_no >= @last_sample_no)
     --        update business_unit set last_sample_no =  right(@txn_last_no,len(@txn_last_no)-2) where vanCode = @vanCode

     --   if (@txn_last_no < @last_sample_no)
	      if len(rtrim(ltrim(@last_sample_no))) > 4
             update business_unit set last_sample_no =  right(@last_sample_no,len(@last_sample_no)-2) where vanCode = @vanCode and right(@last_sample_no,len(@last_sample_no)-2) >= last_sample_no

	      if len(rtrim(ltrim(@last_return_no))) > 4
             update business_unit set last_return_no =  right(@last_return_no,len(@last_return_no)-2) where vanCode = @vanCode and right(@last_return_no,len(@last_return_no)-2) >= last_return_no


     --end 


GO


