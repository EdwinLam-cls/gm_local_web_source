﻿'---------------------------------------------------------------------------- 
'程式功能	人員資料管理 > 明細內容
'---------------------------------------------------------------------------- 

Imports System
Imports System.Data.SqlClient
Imports System.Web.Configuration

Partial Public Class _2004
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim strCustNo As String = ""
            Dim SqlString As String = ""
            Dim mErr As String = ""

            ' 檢查使用者權限但不存入登入紀錄 
            Check_Power("2004_view", False)

            ' 承接上一頁的查詢條件設定 
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid").ToString(), ckint) Then
                    lb_page.Text = "?pageid=" & ckint.ToString()
                Else
                    lb_page.Text = "?pageid=" & "0"
                End If
            Else
                lb_page.Text = "?"
            End If

            If Request("s1") IsNot Nothing Then
                lb_page.Text &= "&s1=" & Request("s1")
            End If

            If Request("s2") IsNot Nothing Then
                lb_page.Text &= "&s2=" & Request("s2")
            End If

            If Request("s3") IsNot Nothing Then
                lb_page.Text &= "&s3=" & Request("s3")
            End If

            If Request("s4") IsNot Nothing Then
                lb_page.Text &= "&s4=" & Request("s4")
            End If

            If Request("mg_sid") IsNot Nothing Then
                lb_page.Text &= "&mg_sid=" & Request("mg_sid")
                strCustNo = Request("mg_sid").ToString()
            End If



            ' 檢查傳入參數 
            If Request("mg_sid") IsNot Nothing Then
                If Request("mg_sid").ToString() <> "" Then
                    ' 取得相關資料 
                    Using sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                        sql_conn.Open()

                        ' "取得人員基本資料
                        SqlString = "Select Top 1 c.custNo,c.name1 as c_name,c.city as district,c.region, c.houseAddr,c.telNo,c.shippingPoint,c.personnelNo,c.InfoCodeExist,g.custGroup,g.name1 as g_name, g.block, c.street4 "
                        SqlString &= " From customer_master c inner join customer_group_master g on c.custGroup = g.custGroup Where c.custNo = '" & strCustNo & "'"

                        Using Sql_Command As New SqlCommand(SqlString, sql_conn)
                            Using Sql_Reader As SqlDataReader = Sql_Command.ExecuteReader()
                                If Sql_Reader.Read() Then
                                    lblCustNo.Text = Sql_Reader("custNo").ToString()
                                    lblCustName.Text = Sql_Reader("c_name").ToString()
                                    lblDistrict.Text = Sql_Reader("district").ToString().Trim()
                                    lblRegion.Text = Sql_Reader("region").ToString().Trim()
                                    lblAddress.Text = Sql_Reader("houseAddr").ToString().Trim()
                                    lblTelNo.Text = Sql_Reader("telNo").ToString().Trim()
                                    lblShipping.Text = Sql_Reader("shippingPoint").ToString().Trim()
                                    lblPersonnel.Text = Sql_Reader("personnelNo").ToString().Trim()
                                    lblCustMateExist.Text = IIf(Sql_Reader("InfoCodeExist").ToString().Trim() = "1", "Yes", "No")
                                    lblGpNo.Text = Sql_Reader("custGroup").ToString().Trim()
                                    lblGpName.Text = Sql_Reader("g_name").ToString().Trim()
                                    lblBlock.Text = IIf(Sql_Reader("block").ToString().Trim() = "1", "Yes", "No")
                                    lblStreet4.Text = Sql_Reader("street4").ToString().Trim()
                                Else
                                    mErr = "No record for current user!\n"
                                End If
                            End Using
                        End Using
                    End Using

                    Using sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                        sql_conn.Open()

                        SqlString = "select a.custNo, isnull(b.is_active,'1') as is_active from customer_master a left join block_customer b on a.custNo = b.custNo where  a.custNo = '" & strCustNo & "'"
                        Using Sql_Command As New SqlCommand(SqlString, sql_conn)
                            Using Sql_Reader As SqlDataReader = Sql_Command.ExecuteReader()
                                If Sql_Reader.Read() Then
                                    Dim isActive As String = ""
                                    isActive = IIf(Sql_Reader("is_active").ToString().Trim() = "1", "Yes", "No")
                                    If isActive = "No" Then
                                        btnBlockCust.Text = "UnBlock This Customer"
                                    Else
                                        btnBlockCust.Text = "Block This Customer"
                                    End If
                                End If
                            End Using
                        End Using
                    End Using
                End If
            End If

        End If
    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    'Protected Sub lk_power_Click(ByVal sender As Object, ByVal e As EventArgs) Handles lk_power.Click
    '    Response.Redirect("100511.aspx" & lb_page.Text & "&sid=" & lb_pg_mg_sid.Text)
    'End Sub

    Protected Sub btnBlockCust_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBlockCust.Click
        Dim SqlString As String = ""
        Dim strCustNo As String = ""
        Dim strBlock As String = ""
        If btnBlockCust.Text.Substring(0, 1) = "U" Then
            strBlock = "1" ' Unblock
        Else
            strBlock = "" 'Block
        End If
        strCustNo = Request("mg_sid").ToString()


        Using sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
            sql_conn.Open()

            ' "取得人員基本資料
            SqlString = "Delete from block_customer where custno = '" & strCustNo & "' ; insert into block_customer (custno, is_active) values ( '" & strCustNo & "' , '" & strBlock & "' " & ") "
            'SqlString &= " From customer_master c inner join customer_group_master g on c.custGroup = g.custGroup Where c.custNo = '" & strCustNo & "'"

            Using Sql_Command As New SqlCommand(SqlString, sql_conn)
                Sql_Command.ExecuteNonQuery()

            End Using
        End Using



        btnBlockCust.Enabled = False
    End Sub
End Class
