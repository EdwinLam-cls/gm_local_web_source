﻿'---------------------------------------------------------------------------- 
'程式功能	Customer Manster Master Maintenance
'---------------------------------------------------------------------------- 
Imports System
Imports System.Collections.Generic
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Data
Imports System.Data.SqlClient
Partial Class _2004_2004
    Inherits System.Web.UI.Page
    Private s3 As String
    Private s4 As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()



            ' 檢查使用者權限並存入登入紀錄。 
            Check_Power("2004", True)

            '接受下一頁返回時的舊查詢條件" 
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid"), ckint) Then
                    gv_customer_master.PageIndex = ckint
                    lb_pageid.Text = gv_customer_master.PageIndex
                Else
                    lb_pageid.Text = "0"
                End If

            End If



            If Request("s1") IsNot Nothing Then
                txtCustNo.Text = Request("s1")
            End If

            If Request("s2") IsNot Nothing Then
                tb_customer_code.Text = Request("s2")
            End If

            If Request("s3") IsNot Nothing Then
                tb_company_code.DataSourceID = Nothing
                tb_company_code.DataSource = RetrieveDataTable("select [name1] from [customer_group_master] union select ''")
                tb_company_code.DataBind()
                Try
                    tb_company_code.SelectedValue = Request("s3")
                Catch
                End Try
            End If

            If Request("s4") IsNot Nothing Then
                tb_district_name.DataSourceID = Nothing
                tb_district_name.DataSource = RetrieveDataTable("SELECT distinct UPPER([district_zone_eng]) as district_zone_eng FROM [district_master] union select ''")
                tb_district_name.DataBind()
                Try
                    tb_district_name.SelectedValue = Request("s4")
                Catch
                End Try

            End If

            mgids.Text = Session("mg_sid")

            Chk_Filter()
        End If


    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            'If cfc.Check_Power(Session("stk_code").ToString(), Session("stk_desc").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub gv_customer_master_PageIndexChanged(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        Chk_Filter()
        lb_pageid.Text = e.NewPageIndex()

    End Sub

    Protected Sub Btn_Set_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' 檢查查詢條件是否改變 
        Chk_Filter()
    End Sub

    ' 檢查查詢條件是否改變 
    Private Sub Chk_Filter()
        Dim cfc As New Common_Func()

        Dim ckint As Integer = 0
        Dim tmpstr As String = ""

        Dim strSearchCustNo = cfc.CleanSQL(txtCustNo.Text.Trim)
        Dim strSearchName = cfc.CleanSQL(tb_customer_code.Text.Trim)
        Dim strSearchGroup = cfc.CleanSQL(tb_company_code.SelectedValue.Trim)
        Dim strSearchDistrict = cfc.CleanSQL(tb_district_name.SelectedValue.Trim)
        Dim strSql As String = " select c.custNo,c.name1,c.salesOrg,c.custGroup, g.name1 as g_name1,c.city as district from customer_master c inner join customer_group_master g on g.custGroup = c.custGroup "
        strSql += " where 1=1 "
        If strSearchCustNo <> "" Then strSql += " and c.custNo like '%" & strSearchCustNo & "%'"
        If strSearchName <> "" Then strSql += " and c.name1 like '%" & strSearchName & "%'"
        If strSearchGroup <> "" Then strSql += " and g.name1 = '" & strSearchGroup & "'"
        If strSearchDistrict <> "" Then strSql += " and c.city = '" & strSearchDistrict & "'"

        dsCustomer.SelectCommand = strSql
        gv_customer_master.DataBind()
        If gv_customer_master.PageCount - 1 < gv_customer_master.PageIndex Then
            gv_customer_master.PageIndex = gv_customer_master.PageCount
            gv_customer_master.DataBind()
        End If

        lb_pageid.Text = gv_customer_master.PageIndex.ToString()
    End Sub

    Protected Sub gv_customer_master_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs) Handles gv_customer_master.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim btnView As Button = DirectCast(e.Row.FindControl("btnView"), Button)
            Dim strCustNo As String = e.Row.Cells(0).Text
            btnView.ToolTip = strCustNo
        End If

    End Sub

    Public Sub btnView_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim strCustNo As String = CType(sender, Button).ToolTip

        Dim strCustSearch As String = txtCustNo.Text
        Dim strCustName As String = tb_customer_code.Text
        Dim strCustGroup As String = tb_company_code.Text
        Dim strDistrict As String = tb_district_name.Text

        Response.Redirect(String.Format("2004_view.aspx?pageid={0}&mg_sid={1}&s1={2}&s2={3}&s3={4}&s4={5}", lb_pageid.Text, strCustNo, strCustSearch, strCustName, strCustGroup, strDistrict), False)
    End Sub

    Protected Sub tb_company_code_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tb_company_code.SelectedIndexChanged
        Chk_Filter()
    End Sub

    Protected Sub tb_district_name_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tb_district_name.SelectedIndexChanged
        Chk_Filter()
    End Sub



    Private Function RetrieveDataTable(ByVal strSQL As String) As DataTable
        Dim Sql_Conn1 As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim SqlString1 As String = strSQL


        Dim Sql_Command1 As New SqlCommand(SqlString1, Sql_Conn1)
        Sql_Conn1.Open()

        Dim dt As New DataTable

        Dim Sql_Reader1 As SqlDataReader = Sql_Command1.ExecuteReader()

        dt.Load(Sql_Reader1)

        Sql_Reader1.Close()
        Sql_Conn1.Close()


        Return dt
    End Function
End Class
