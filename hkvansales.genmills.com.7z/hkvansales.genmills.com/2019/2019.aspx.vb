﻿'---------------------------------------------------------------------------- 
'程式功能	District Master > 明細內容 > 新增資料
'---------------------------------------------------------------------------- 

Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration

Partial Class _2019_2019
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0

            ' 檢查使用者權限但不存入登入紀錄 
            Check_Power("2019", False)

            ' 承接上一頁的查詢條件設定
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid").ToString(), ckint) Then
                    lb_page.Text = "?pageid=" & ckint.ToString()
                Else
                    lb_page.Text = "?pageid=0"
                End If
            End If

            If Request("district_id") IsNot Nothing Then
                lb_page.Text &= "&district_id=" & Request("district_id")
            End If

        End If
    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub search_date(ByVal sender As Object, ByVal e As System.EventArgs)

        BindRefDocNo(txtValidTo.Text, txtrefDoc.Text, ddlgp.SelectedValue, ddlcust.SelectedValue)

    End Sub

    Private Sub BindRefDocNo(ByVal dtm As String, ByVal refDoc As String, ByVal CustGp As String, ByVal CustNo As String)
        Dim sToday As Date = Today
        Dim strSql As String = "SELECT refDocNo + space(2) + c.name1 as display, isVoid, isExtract from txn_header h inner join customer_master c on h.custNo = c.custNo where 1=1   "
        strSql += " and convert(varchar(10),h.cr_date,111) = '" & dtm & "'"
        If refDoc <> "" Then
            strSql += " and refDocNo like '" & refDoc & "%' "
        End If
        If CustGp <> "" Then
            strSql += " and c.CustGroup = '" & CustGp & "' "
        End If

        If CustNo <> "" Then
            strSql += " and c.CustNo = '" & CustNo & "' "
        End If

        DSrefDocNo.SelectCommand = strSql
        cbRefDocNo.DataBind()
        cbRefDocNo2.DataBind()

        If cbRefDocNo.Items.Count > 0 Then
            For i = 0 To cbRefDocNo.Items.Count - 1

                cbRefDocNo.Items(i).Selected = (cbRefDocNo.Items(i).Value = "1")

                cbRefDocNo.Items(i).Enabled = (cbRefDocNo2.Items(i).Value <> "1")


            Next


            If (DateDiff(DateInterval.Day, sToday, Convert.ToDateTime(dtm)) = 0) Then
                lb_ok.Enabled = True
            Else
                lb_ok.Enabled = False
            End If


        End If
    End Sub

    Private Sub cbDataBind(ByVal sender As Object, ByVal e As EventArgs) Handles cbRefDocNo.DataBinding
        Dim cb As CheckBoxList = CType(sender, CheckBoxList)

    End Sub

    Protected Sub lb_ok_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim mErr As String = ""
        Dim mg_sid As Integer = -1
        Dim intCountGroupNo As Integer = 0

        ' 載入字串函數 
        Dim sfc As New String_Func()

        ' 載入公用函數 
        Dim cfc As New Common_Func()

        Try
            Dim Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
            Dim Sql_Command As New SqlCommand()
            Sql_Command.Connection = Sql_conn
            Sql_conn.Open()

            For Each item As ListItem In cbRefDocNo.Items
                Dim SqlString As String = ""
                If item.Selected = True Then
                    SqlString = "update txn_header set isVoid = '1' where refDocNo = @refDocNo"
                Else
                    SqlString = "update txn_header set isVoid = '' where refDocNo = @refDocNo"
                End If
                Dim strRefDocNo As String = item.Text.Split(" ")(0)

                Sql_Command.CommandText = SqlString
                Sql_Command.Parameters.AddWithValue("@refDocNo", strRefDocNo)
                Sql_Command.ExecuteNonQuery()
                Sql_Command.Parameters.Clear()

            Next

            Sql_conn.Close()
            Sql_Command.Dispose()
        Catch ex As Exception
            mErr = ex.Message.Replace("""", "").Replace("'", "")
        End Try


        If mErr = "" Then
            mErr = ("alert('Record saved successfully!\n');")
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", mErr, True)
        Else
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('" & mErr & "')", True)
        End If


    End Sub

    Protected Sub ddlgp_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlgp.SelectedIndexChanged
        Dim strSql As String = "select custNo + ' ' + name1 as name , custNo from customer_master where 1= 1  "

        strSql += " and custgroup  = '" & ddlgp.SelectedValue & "'"
        strSql += " union select '', ''  order by custNo "

        dscust.SelectCommand = strSql
        ddlcust.DataBind()



    End Sub

    Private Sub Chk_Filter2()
        Dim cfc As New Common_Func()

        Dim ckint As Integer = 0
        Dim tmpstr As String = ""



        'Dim strSearchCode = cfc.CleanSQL(ddlCode.selectedValue)
        'Dim strSearchDesc = cfc.CleanSQL(txtDescription.Text)

        'Dim strSql As String = "select * from item_group_desc_master "
        'strSql += " where 1=1 "
        'If strSearchCode.trim <> "" Then
        '    strSql += " and [id] ='" & strSearchCode.Trim & "' "
        'End If
        'If strSearchDesc.Trim <> "" Then
        '    strSql += " and [chiDesc] like '%" & strSearchDesc.Trim & "%'"
        'End If
        'dsDeliverMaster.SelectCommand = strSql




        'gv_delivery_master.DataBind()
        'If gv_delivery_master.PageCount - 1 < gv_delivery_master.PageIndex Then
        '    gv_delivery_master.PageIndex = gv_delivery_master.PageCount
        '    gv_delivery_master.DataBind()
        'End If

        'lb_pageid.Text = gv_delivery_master.PageIndex.ToString()
    End Sub


End Class
