﻿Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration
Imports System.Data.Common
Imports Common_Func


Partial Class _6033_6033

    Inherits System.Web.UI.Page

    Dim gErr As String = ""


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim tmpstr As String = ""

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("6033", True)
            mg_name.Value = Session("mg_name").ToString

            'ddlFYear.Text = "F" & IIf(Right(Today.Year, 2) = "19", "20", Right(Today.Year, 2))
        End If

        'Dim xVal() As String = {"1", "2", "3"}
        'Dim yval() As Double = {12, 34, 45}

        'Chart1.Series("Series1").Points.DataBindXY(xVal, yval)

        'System.Diagnostics.Debug.WriteLine(SqlMainSource.SelectCommand)


        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""

    End Sub


    ' Check_Power() 檢查使用者權限並存入登入紀錄
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub
    Protected Sub btn_search_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_search.Click
        Chk_Filter()
    End Sub

    Private Sub Chk_Filter()

        Dim strFrom As String = ""
        Dim strTo As String = ""
        getDateFromTo(strFrom, strTo)


        Dim myDataTable As DataTable = New DataTable()
        'Dim myDataSet As New DataSet

        Dim Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Sql_conn.Open()

        Dim SqlString As String = "rpt_WriteOff"



        Dim Sql_Command As New SqlCommand(SqlString, Sql_conn)
        Sql_Command.CommandType = CommandType.StoredProcedure
        Sql_Command.Parameters.Add("@dateFrom", SqlDbType.DateTime, 100)
        Sql_Command.Parameters.Add("@dateTo", SqlDbType.DateTime, 100)
        Sql_Command.Parameters.Add("@txn_type", SqlDbType.NVarChar, 100)
        Sql_Command.Parameters.Add("@txn_period", SqlDbType.NVarChar, 100)

        Sql_Command.Parameters("@dateFrom").Value = strFrom
        Sql_Command.Parameters("@dateTo").Value = strTo
        Sql_Command.Parameters("@txn_type").Value = "Exchange"
        Sql_Command.Parameters("@txn_period").Value = ddlFYear.Text & " " & ddlFPeriod.Text
        Dim reader As SqlDataReader = Sql_Command.ExecuteReader()

        myDataTable.Load(reader)
        myDataTable.TableName = "t"
        reader.Close()

        Sql_Command.Parameters("@txn_type").Value = "Sales"
        reader = Sql_Command.ExecuteReader()
        Dim dt As New DataTable
        dt.Load(reader)
        dt.TableName = "t2"
        myDataTable.Merge(dt)
        Sql_Command.Dispose()
        Sql_conn.Close()

     


        If myDataTable.Rows.Count = 2 And myDataTable.Columns.Count > 2 Then
            Dim dr As DataRow = dt.Rows(0)
            myDataTable.ImportRow(dr)
            myDataTable.Columns(0).ReadOnly = False
            myDataTable.Rows.Item(2)(0) = "Write-off %"

            For j = 2 To myDataTable.Columns.Count - 1
                myDataTable.Columns(j).ReadOnly = False
                Dim intUpper As Integer = myDataTable.Rows.Item(0)(j)
                Dim intLower As Integer = myDataTable.Rows.Item(1)(j)

                If intLower = 0 Then
                    myDataTable.Rows.Item(2)(j) = "0.00"
                Else
                    myDataTable.Rows.Item(2)(j) = Math.Round(intUpper * 100 / intLower, 2)
                End If

            Next
        End If
        myDataTable.AcceptChanges()



        Dim dtNew As DataTable = myDataTable.Clone


        For j = 0 To dtNew.Columns.Count - 1
            dtNew.Columns(j).DataType = GetType(String)
        Next

        For i = 0 To myDataTable.Rows.Count - 1
            Dim dtRow As DataRow = myDataTable.Rows(i)
            dtNew.ImportRow(dtRow)
        Next

        If dtNew.Rows.Count > 1 Then
            For j = 2 To myDataTable.Columns.Count - 1
                dtNew.Rows.Item(2)(j) = dtNew.Rows.Item(2)(j) & "%"
            Next

        End If

        ViewState("myDataTable") = dtNew

        gv_txn_detail.DataSource = dtNew
        gv_txn_detail.DataBind()
        If gv_txn_detail.PageCount - 1 < gv_txn_detail.PageIndex Then
            gv_txn_detail.PageIndex = gv_txn_detail.PageCount
            gv_txn_detail.DataBind()
        End If





    End Sub

    Protected Sub gv_txn_detail_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gv_txn_detail.Sorting
        Dim dt As DataTable = ViewState("myDataTable")
        Dim dv As DataView = dt.DefaultView
        dv.Sort = e.SortExpression + " " + ConvertSortDirectionToSql(e.SortDirection)
        gv_txn_detail.DataSource = dv
        ViewState("myDataTable") = dv.ToTable
        gv_txn_detail.DataBind()

    End Sub

    Private Function ConvertSortDirectionToSql(ByVal sortDirect As SortDirection) As String

        If ViewState("orderBy") = "ASC" Then
            ViewState("orderBy") = "DESC"
            Return "DESC"
        Else
            ViewState("orderBy") = "ASC"
            Return "ASC"
        End If
        Return 0
    End Function


    Protected Sub gv_txn_detail_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gv_txn_detail.PageIndexChanging
        gv_txn_detail.PageIndex = e.NewPageIndex
        gv_txn_detail.DataSource = ViewState("myDataTable")
        gv_txn_detail.DataBind()


    End Sub

    Private Sub getDateFromTo(ByRef strFrom As String, ByRef strTo As String)
        Dim myDataTable As DataTable
        Dim strPeriod As String = ""
        Dim strSql As String = "  select finyear+finperiod as p ,  isnull(CONVERT(varchar(10),MIN(startDate),111),'') a, isnull(CONVERT(varchar(10),MAX(EndDate),111),'') b from fin_period " & _
                     " where finyear = '" & ddlFYear.Text & "' and finperiod ='" & ddlFPeriod.Text & "' group by finyear, finperiod "
        myDataTable = ExeSQLGetDataTable(strSql)
        If myDataTable.Rows.Count > 0 Then
            strPeriod = myDataTable.Rows.Item(0)("p")
            strFrom = myDataTable.Rows.Item(0)("a")
            strTo = myDataTable.Rows.Item(0)("b")
        End If
        If strFrom <> "" Then
            lblPeriod.Text = "Financial Period (" & strPeriod & ") : " & strFrom & " - " & strTo
        Else
            lblPeriod.Text = ""
        End If

    End Sub



End Class
