﻿Imports System.Data
Imports Common_Func

Partial Class _6005_6005
    Inherits System.Web.UI.Page

    Dim gErr As String = ""
    Dim StrCriteria As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim criteriaSQL As String = ""

        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim tmpstr As String = ""

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("6005", True)




        End If



        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""


       

    End Sub


    ' Check_Power() 檢查使用者權限並存入登入紀錄
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        Dim strSql As String = getStrSql()
        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()

        Dim SQLString As String = "select sum(d.netPrice * d.quantity) as total_price from txn_header h inner join txn_detail d on h.refDocNo = d.refDocNo inner join customer_master c on h.custNo = c.custNo inner join item_master i on d.materialCode = i.materialCode inner join customer_group_master g on c.custGroup = g.custGroup  where 1=1 and h.isVoid <> '1' " & StrCriteria
        Dim myDataTable As DataTable = ExeSQLGetDataTable(SQLString)
        If myDataTable.Rows.Count > 0 Then
            lbl_total.Text = "Total: " & myDataTable.Rows(0).Item("total_price").ToString
        Else
            lbl_total.Text = ""
        End If
    End Sub

    Private Function getStrSql() As String
        Dim strDistrict As String = ddlDistrict.Text.Trim
        Dim strCustomerGroup As String = ddlCustomerGroup.Text.Trim
        Dim strAddress As String = txtAddress.Text.Trim
        Dim strDateFrom As String = txtDateFrom.Text.Trim
        Dim strDateTo As String = txtDateTo.Text.Trim

        Dim strSql As String = ""

        If strDistrict <> "" Then
            strSql += " and c.city = '" & strDistrict & "'"
        End If

        If strCustomerGroup <> "" Then
            strSql += " and g.name1 = '" & strCustomerGroup & "'"
        End If

        If strAddress <> "" Then
            strSql += " and c.houseAddr like '%" & strAddress & "%'"
        End If

        If strDateFrom <> "" Then
            Try
                Dim dtmTest As DateTime = CDate(strDateFrom)
                strSql += " and convert(varchar(10),h.cr_date,111) >= '" & strDateFrom & "'"
            Catch ex As Exception

            End Try

        End If

        If strDateTo <> "" Then
            Try
                Dim dtmTest As DateTime = CDate(strDateTo)
                strSql += " and convert(varchar(10),h.cr_date,111) <= '" & strDateTo & "'"
            Catch ex As Exception

            End Try
        End If
        StrCriteria = strSql
        strSql = "select h.refDocNo, h.PO_no, h.custNo,c.name1,c.houseAddr,d.materialCode,i.chiDesc,d.grossPrice,d.netPrice,d.quantity, (netPrice * quantity) as totalPrice from txn_header h inner join txn_detail d on h.refDocNo = d.refDocNo inner join customer_master c on h.custNo = c.custNo inner join item_master i on d.materialCode = i.materialCode inner join customer_group_master g on c.custGroup = g.custGroup  where 1=1 and h.isVoid <> '1' " + strSql

        Return strSql
    End Function

    Protected Sub gv_custmaster_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gv_custmaster.PageIndexChanging

        Dim strSql As String = getStrSql()
        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()
    End Sub
    Protected Sub gv_custmaster_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gv_custmaster.Sorting
        Dim strSql As String = getStrSql()
        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()
    End Sub
End Class
