﻿Imports System
Imports System.Data.SqlClient
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.Configuration

Partial Public Class _1001
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            ' Check user access right and record the login
            Check_Power("1001", True)
        End If

        Dim mg_id As String = "", SqlString As String = ""
        Dim Sql_conn As SqlConnection
        Dim Sql_command As SqlCommand
        Dim Sql_reader As SqlDataReader

        SqlString = "Select Top 1 mg_id, mg_pass From Manager Where mg_sid = @mg_sid"

        Sql_conn = New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Sql_conn.Open()
        Sql_command = New SqlCommand(SqlString, Sql_conn)
        Sql_command.Parameters.AddWithValue("@mg_sid", Session("mg_sid").ToString())
        Sql_reader = Sql_command.ExecuteReader()
        If Sql_reader.Read() Then
            mg_id = Sql_reader("mg_id").ToString().Trim()
        End If
        Sql_reader.Close()

        Me.tb_id.Text = mg_id

    End Sub

    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        Dim cfc As New Common_Func()

        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub bn_ok_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim cfc As New Common_Func()

        Dim mErr As String = "", mg_npass As String = ""

        mg_npass = tb_npass.Text.Trim()

        If tb_spass.Text.Trim() = "" Then
            mErr = mErr & "Please enter password!\n"
        End If

        If mg_npass = "" Then
            mErr = mErr & "Please enter new password!\n"
        ElseIf cfc.CheckSQL(mg_npass) Then
            mErr = mErr & "Special Characters not allowed in new password!\n"
        ElseIf mg_npass.Length > 12 OrElse mg_npass.Length < 4 Then
            mErr = mErr & "The length of the new password is between 4 and 12!\n"
        End If

        If mg_npass <> tb_rpass.Text.Trim() Then
            mErr = mErr & "New Password does not match!\n"
        Else
            If tb_spass.Text.Trim() = tb_npass.Text.Trim() Then
                mErr = mErr & "New Password should be different!\n"
            End If
        End If

        If mErr = "" Then
            Dim mg_pass As String = "", mg_id As String = ""
            Dim SqlString As String = ""
            Dim Sql_conn As SqlConnection
            Dim Sql_command As SqlCommand
            Dim Sql_reader As SqlDataReader
            Dim dcd As New Decoder()

            SqlString = "Select Top 1 mg_id, mg_pass From Manager Where mg_sid = @mg_sid"

            Sql_conn = New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
            'Sql_conn = New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
            Sql_conn.Open()
            Sql_command = New SqlCommand(SqlString, Sql_conn)
            Sql_command.Parameters.AddWithValue("@mg_sid", Session("mg_sid").ToString())
            Sql_reader = Sql_command.ExecuteReader()
            If Sql_reader.Read() Then
                mg_id = Sql_reader("mg_id").ToString().Trim()

                mg_pass = dcd.DeCode(Sql_reader("mg_pass").ToString().Trim())
            End If
            Sql_reader.Close()

            If mg_id = tb_id.Text.Trim() AndAlso mg_pass = tb_spass.Text.Trim() Then
                ' Encode new password.
                mg_pass = dcd.EnCode(tb_npass.Text.Trim())

                ' Change password
                SqlString = "Update Manager Set mg_pass = @mg_pass Where mg_sid = @mg_sid and mg_id = @mg_id"
                Sql_command.Parameters.Clear()

                Sql_command = New SqlCommand(SqlString, Sql_conn)
                Sql_command.Parameters.AddWithValue("@mg_sid", Session("mg_sid").ToString())
                Sql_command.Parameters.AddWithValue("@mg_id", mg_id)
                Sql_command.Parameters.AddWithValue("@mg_pass", mg_pass)

                Sql_command.ExecuteNonQuery()

                mErr = "Password Changed!\n"
            Else
                mErr = mErr & "Incorrect User or Password!\n"
            End If

            Sql_command.Dispose()
            Sql_conn.Close()
        End If

        Dim txtMsg As New Literal()

        txtMsg.Text = "<script language=javascript>alert('" & mErr & "');</script>"

        Page.Controls.Add(txtMsg)
    End Sub
End Class