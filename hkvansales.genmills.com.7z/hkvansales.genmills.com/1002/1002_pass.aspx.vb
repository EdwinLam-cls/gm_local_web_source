﻿'---------------------------------------------------------------------------- 
'程式功能	人員資料管理 > 明細內容 > 變更密碼
'---------------------------------------------------------------------------- 

Imports System
Imports System.Data.SqlClient
Imports System.Web.Configuration

Partial Public Class _1002_pass
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Dim mg_sid As Integer = -1
        Dim SqlString As String = "", mErr As String = ""

        If Not IsPostBack Then
            Dim ckint As Integer = 0

            ' 檢查使用者權限但不存入登入紀錄 
            Check_Power("1005", False)

            ' 承接上一頁的查詢條件設定
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid").ToString(), ckint) Then
                    lb_page.Text = "?pageid=" & ckint.ToString()
                Else
                    lb_page.Text = "?pageid=0"
                End If
            End If

            If Request("mg_sid") IsNot Nothing Then
                lb_page.Text &= "&mg_sid=" & Request("mg_sid")
            End If

            If Request("mg_name") IsNot Nothing Then
                lb_page.Text &= "&mg_name=" & Server.UrlEncode(Request("mg_name"))
            End If

            If Request("mg_nike") IsNot Nothing Then
                lb_page.Text &= "&mg_nike=" & Server.UrlEncode(Request("mg_nike"))
            End If

            If Request("btime") IsNot Nothing Then
                lb_page.Text &= "&btime=" & Server.UrlEncode(Request("btime"))
            End If

            If Request("etime") IsNot Nothing Then
                lb_page.Text &= "&etime=" & Server.UrlEncode(Request("etime"))
            End If

            ' 檢查傳入參數
            If Request("sid") IsNot Nothing Then
                ' 取得相關資料
                If Integer.TryParse(Request("sid").ToString(), mg_sid) Then
                    lb_page.Text &= "&sid=" & mg_sid.ToString()

                    Using sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                        sql_conn.Open()

                        ' 取得人員基本資料
                        SqlString = "Select Top 1 mg_sid, mg_name, mg_id From Manager Where mg_sid =" & mg_sid.ToString()

                        Using Sql_Command As New SqlCommand(SqlString, sql_conn)
                            Using Sql_Reader As SqlDataReader = Sql_Command.ExecuteReader()
                                If Sql_Reader.Read() Then
                                    lb_mg_sid.Text = Sql_Reader("mg_sid").ToString()
                                    lb_mg_id.Text = Sql_Reader("mg_id").ToString()
                                    lb_mg_name.Text = Sql_Reader("mg_name").ToString().Trim()

                                    lb_pg_mg_sid.Text = mg_sid.ToString()
                                Else
                                    mErr = "Cannot find record!\n"
                                End If
                            End Using
                        End Using
                    End Using
                Else
                    mErr = "parameters error!\n"
                End If
            Else
                mErr = "parameters error!\n"
            End If

            If mErr <> "" Then
                lt_show.Text = "<script language='javascript'>alert('" & mErr & "');history.go(-1);</script>"
            End If
        End If
    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub lb_ok_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim mErr As String = ""
        Dim mg_pass As String, mg_pass1 As String

        ' 載入公用函數 
        Dim cfc As New Common_Func()

        mg_pass = tb_mg_pass.Text.Trim()
        mg_pass1 = tb_mg_pass1.Text.Trim()

        If mg_pass = "" Then
            mErr = mErr & "Please enter new password!\n"
        ElseIf cfc.CheckSQL(mg_pass) Then
            mErr = mErr & "Special Characters not allowed in new password!\n"
        ElseIf mg_pass.Length > 12 OrElse mg_pass.Length < 4 Then
            mErr = mErr & "New password's length should be between 4 and 12\n"
        End If

        If mg_pass <> mg_pass1 Then
            mErr = mErr & "New Password should be different!\n"
        End If

        If mErr = "" Then
            Using Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                Dim SqlString As String = ""
                Dim decoder As New Decoder()

                Sql_conn.Open()

                ' 建立 SQL 修改資料的語法 
                SqlString = "Update Manager Set mg_pass = @mg_pass Where mg_sid = @mg_sid"

                Using Sql_Command As New SqlCommand(SqlString, Sql_conn)
                    Sql_Command.Parameters.AddWithValue("@mg_pass", decoder.EnCode(mg_pass))
                    Sql_Command.Parameters.AddWithValue("@mg_sid", lb_pg_mg_sid.Text)

                    Sql_Command.ExecuteNonQuery()
                End Using
            End Using
        End If

        If mErr = "" Then
            mErr = "alert('Password Changed!\n');location.replace('1002_view.aspx" & lb_page.Text & "');"
        Else
            mErr = "alert('" & mErr & "')"
        End If

        lt_show.Text = "<script language=javascript>" & mErr & "</script>"
    End Sub
End Class