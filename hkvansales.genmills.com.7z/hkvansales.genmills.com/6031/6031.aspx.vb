﻿Imports System.Data
Imports Common_Func


Partial Class _6031_6031
    Inherits System.Web.UI.Page

    Dim gErr As String = ""
    Dim ssql As String = ""



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim tmpstr As String = ""

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("6031", True)

        End If

        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""

        showData()




    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub



    Private Sub showData()
        Dim Weekday As String = ""
        Dim clientDate As DateTime = Now
        If Not ConfigurationManager.AppSettings("TimeZoneID") Is Nothing Then
            clientDate = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID")))
            Weekday = clientDate.DayOfWeek.ToString()
        End If

        Dim strSql As String
        Dim strVanNo As String = Right(ddlVanID.Text, 3)

        strSql = "SELECT c.shippingPoint, c.custNo,c.name1,isnull(h.PO_no,'') as PO_no, c.street4, c.adrc_telNo,'' as 'QOE' from ( "
        strSql &= " SELECT g.custNo "
        strSql &= " FROM gm_route g, customer_master c "
        strSql &= " WHERE c.custNo = g.custNo and c.is_active= '1' "
        strSql &= " and g.is_active = '1' "
        If strVanNo <> "" Then strSql &= " and right(vanCode,3) = '" & strVanNo & "'"
        strSql &= String.Format(" and ({0} = 'x' or {0} = '1') ", Weekday)
        strSql &= " union SELECT c.custNo"
        strSql &= " FROM rush_order_header h, customer_master c "
        strSql &= " WHERE h.custNo = c.custNo and h.isException <>'1' "
        strSql &= " AND convert(varchar(10),ship_date,111) = '" & clientDate.ToString("yyyy/MM/dd") & "'"
        If strVanNo <> "" Then strSql &= " and right(c.shippingPoint,3) = '" & strVanNo & "'"

        strSql &= ") o left outer join rush_order_header h on h.custNo = o.custNo and h.isException <>'1' "
        strSql &= " and convert(varchar(10),h.ship_date,111) = '" & clientDate.ToString("yyyy/MM/dd") & "'"
        strSql &= " inner join customer_master c on c.custNo = o.custNo where 1=1 order by  PO_no desc"
        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()
    End Sub
End Class
