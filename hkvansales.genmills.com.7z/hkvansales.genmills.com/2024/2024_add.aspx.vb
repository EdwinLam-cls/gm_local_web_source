﻿'---------------------------------------------------------------------------- 
'程式功能	UOM Master > 明細內容 > 新增資料
'---------------------------------------------------------------------------- 

Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration
Imports System.IO
Imports System.Drawing

Partial Class _2024_2024_add
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0

            ' 檢查使用者權限但不存入登入紀錄 
            Check_Power("2024", False)

            ' 承接上一頁的查詢條件設定
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid").ToString(), ckint) Then
                    lb_page.Text = "?pageid=" & ckint.ToString()
                Else
                    lb_page.Text = "?pageid=0"
                End If
            End If

            If Request("Code") IsNot Nothing Then
                lb_page.Text &= "&Code=" & Request("Code")
            End If

        End If
    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub





    Protected Sub lb_ok_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim mErr As String = ""
        Dim mg_sid As Integer = -1
        Dim intCountGroupNo As Integer = 0
        Dim sfc As New String_Func()
        Dim imgbyte As Byte()
        Dim sToday As String = ""

        ' 載入公用函數 
        Dim cfc As New Common_Func()

        If txtPeriod.Text = "" Then
            mErr &= "Please input Period\n"
        End If

        If txtValidFrom.Text = "" Then
            mErr &= "Please input Valid From Date\n"
        End If

        If txtValidTo.Text = "" Then
            mErr &= "Please input Valid To Date\n"
        End If

        If txtValidFrom.Text <> "" And txtValidTo.Text > "" Then
            If DateDiff(DateInterval.Day, Convert.ToDateTime(txtValidFrom.Text), Convert.ToDateTime(txtValidTo.Text)) < 0 Then
                mErr &= "Valid To Date must be later than From Date \n"
            End If
        End If

            Using Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                Dim SqlString As String = ""
                ' Dim decoder As New Decoder()
            Dim pid As String = UCase(txtPeriod.Text)
            SqlString &= " select period from fiscal_calendar where period = '" & pid & "' "

                Using Sql_Command1 As New SqlCommand(SqlString, Sql_conn)
                    Sql_conn.Open()

                    Using Sql_Reader1 As SqlDataReader = Sql_Command1.ExecuteReader()
                        If Sql_Reader1.Read() Then
                        pid = Sql_Reader1(0).ToString()
                        mErr &= "Period already Added !\n"
                        Else

                        End If
                    End Using
                    Sql_Command1.Dispose()
                End Using

                If mErr = "" Then
                    ' 建立 SQL 的語法 
                SqlString = "Insert Into fiscal_calendar (period, fromdate, todate)"
                SqlString &= " Values (@period, @frdate, @todate);"

                    Using Sql_Command As New SqlCommand()
                        Sql_Command.Connection = Sql_conn
                        Sql_Command.CommandText = SqlString

                    Sql_Command.Parameters.AddWithValue("@period", pid)

                        Sql_Command.Parameters.AddWithValue("@frdate", txtValidFrom.Text.Trim())
                        Sql_Command.Parameters.AddWithValue("@todate", txtValidTo.Text.Trim())

                        'Dim spt_mg_sid As SqlParameter = Sql_Command.Parameters.Add("@UOM_ID", SqlDbType.Int)
                        'spt_mg_sid.Direction = ParameterDirection.Output

                        ' Sql_conn.Open()

                        Sql_Command.ExecuteNonQuery()
                        Sql_Command.Dispose()

                        ' 取得新增資料的主鍵值 
                        mg_sid = 0
                    End Using
                End If
            End Using




        If mErr = "" Then
            mErr = ("alert('Save Success!\n');location.replace('2024.aspx" & lb_page.Text & "&sid=") + mg_sid.ToString() & "');"
        Else
            mErr = "alert('" & mErr & "')"
        End If

        lt_show.Text = "<script language=javascript>" & mErr & "</script>"


    End Sub


End Class
