﻿Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration
Imports System.Data.Common
Imports System.Array
Imports Common_Func

Partial Class _6029_6029
    Inherits System.Web.UI.Page

    Dim gErr As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim tmpstr As String = ""

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("6029", True)

            Dim sqlString As String = ""
            'sqlString = "select SUM (a.base_qty) as total, sum(a.base_qty*a.stk_price) as total_price from daily_sales_tx_summary a "
            'sqlString &= "inner join custmas b on a.customer_code = b.customer_code where b.company_code = 'OK' and a.txn_type = N'銷售' and a.stk_code = (select top 1 stk_code from stkmas where stk_type = 'S' or stk_type = 'D' order by seqno) " & getCriteriaSQL()
            sqlString = "select sum(txn_detail.stk_price * txn_detail.basic_qty) as total_price from txn_detail, txn_header , custmas "
            sqlString &= "where txn_detail.txn_code = txn_header.txn_code and custmas.customer_code = txn_header.cust_code and txn_type = N'銷售' " & getCriteriaSQL()
            'sqlString &= "group by txn_header.cust_code,txn_header.cust_name,txn_header.txn_code,txn_header.cr_date,clientref "
            'sqlString &= "order by txn_header.cust_code,txn_header.cust_name,txn_header.txn_code,txn_header.cr_date,clientref"
            Dim myDataTable As DataTable = ExeSQLGetDataTable(sqlString)
            If myDataTable.Rows.Count > 0 Then
                lbl_total.Text = "總計:" & Replace(myDataTable.Rows(0).Item("total_price").ToString, ".0000", ".00")
                'lbl_totalprice.Text = "總計銷售:" & myDataTable.Rows(0).Item("total_price").ToString
            End If
        End If


        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""

    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Dim sqlString As String = ""
        sqlString = "select txn_header.cust_code,txn_header.cust_name,txn_header.txn_code,txn_header.cr_date,clientref, sum(txn_detail.stk_price * txn_detail.basic_qty) as total_price from txn_detail, txn_header , custmas  "
        sqlString &= "where txn_detail.txn_code = txn_header.txn_code and custmas.customer_code = txn_header.cust_code and txn_type = N'銷售' " & getCriteriaSQL()
        sqlString &= "group by txn_header.cust_code,txn_header.cust_name,txn_header.txn_code,txn_header.cr_date,clientref "
        sqlString &= "order by txn_header.cust_code,txn_header.cust_name,txn_header.txn_code,txn_header.cr_date,clientref"

        SqlMainSource.SelectCommand = sqlString

        'sqlString = "select SUM (a.base_qty) as total from daily_sales_tx_summary a "
        'sqlString &= "inner join custmas b on a.customer_code = b.customer_code where a.txn_type = N'銷售' " & getCriteriaSQL()
        sqlString = "select sum(txn_detail.stk_price * txn_detail.basic_qty) as total_price from txn_detail, txn_header , custmas "
        sqlString &= "where txn_detail.txn_code = txn_header.txn_code and custmas.customer_code = txn_header.cust_code and txn_type = N'銷售' " & getCriteriaSQL()
        'sqlString &= "group by txn_header.cust_code,txn_header.cust_name,txn_header.txn_code,txn_header.cr_date,clientref "
        'sqlString &= "order by txn_header.cust_code,txn_header.cust_name,txn_header.txn_code,txn_header.cr_date,clientref"


        Dim myDataTable As DataTable = ExeSQLGetDataTable(sqlString)
        If myDataTable.Rows.Count > 0 Then
            lbl_total.Text = "總計:" & myDataTable.Rows(0).Item("total_price").ToString
        End If

        'Dim myDataTable As DataTable = New DataTable()
        ''Dim myDataSet As New DataSet

        'Dim Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        'Sql_conn.Open()



        'Dim Sql_Command As New SqlCommand(sqlString, Sql_conn)
        'Dim reader As SqlDataReader = Sql_Command.ExecuteReader()

        'myDataTable.Load(reader)
        'Sql_Command.Dispose()
        'Sql_conn.Close()
        'ViewState("myDataTable") = myDataTable
        'gv_custmaster.DataSource = myDataTable
        'gv_custmaster.DataBind()
        'If gv_custmaster.PageCount - 1 < gv_custmaster.PageIndex Then
        '    gv_custmaster.PageIndex = gv_custmaster.PageCount
        '    gv_custmaster.DataBind()
        'End If


    End Sub

    Function getCriteriaSQL() As String
        Dim sqlQuery As String = ""
        If Me.txt_custcode.Text <> "" Then
            sqlQuery = sqlQuery & " and txn_header.cust_code like N'" & Me.txt_custcode.Text & "%' "
        End If
        If Me.ls_stk_desc.SelectedValue.Trim <> "" Then
            sqlQuery = sqlQuery & " and stk_code = N'" & Me.ls_stk_desc.SelectedValue.Trim & "' "
        End If

        If tb_fr_date.Text <> "" AndAlso DateTime.Parse(tb_fr_date.Text).Year <> 1900 Then
            sqlQuery &= " and convert(nvarchar, txn_header.cr_date, 112) >= convert(nvarchar, cast('" & tb_fr_date.Text & "' as date), 112) "
        End If

        If tb_to_date.Text <> "" AndAlso DateTime.Parse(tb_to_date.Text).Year <> 1900 Then
            sqlQuery &= " and convert(nvarchar, txn_header.cr_date, 112) <= convert(nvarchar, cast('" & tb_to_date.Text & "' as date), 112) "
        End If

        If Me.tb_comp_code.Text <> "" Then
            sqlQuery = sqlQuery & " and company_code = N'" & Me.tb_comp_code.Text & "'"
        End If

        Return sqlQuery '& " group by a.stk_code ,a.customer_code order by a.customer_code"
    End Function

    Protected Sub gv_custmaster_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gv_custmaster.PageIndexChanging
        Dim sqlString As String = ""
        'sqlString = "select max(b.customer_type) as customer_type,a.stk_code,a.customer_code, SUM (a.base_qty) as qty,max(b.customer_name) as customer_name, MAX(isnull(addr1,'') + isnull(addr2,'') + isnull(addr3,'')) as customer_add  from daily_sales_tx_summary a "
        'sqlString &= "inner join custmas b on a.customer_code = b.customer_code where 1=1 " & getCriteriaSQL()
        'sqlString &= "group by a.stk_code ,a.customer_code "
        'sqlString &= "order by a.customer_code "
        sqlString = "select txn_header.cust_code,txn_header.cust_name,txn_header.txn_code,txn_header.cr_date,clientref, sum(txn_detail.stk_price * txn_detail.basic_qty) as total_price from txn_detail, txn_header , custmas  "
        sqlString &= "where txn_detail.txn_code = txn_header.txn_code and custmas.customer_code = txn_header.cust_code and 1=1 and txn_type = N'銷售' " & getCriteriaSQL()
        sqlString &= "group by txn_header.cust_code,txn_header.cust_name,txn_header.txn_code,txn_header.cr_date,clientref "
        sqlString &= "order by txn_header.cust_code,txn_header.cust_name,txn_header.txn_code,txn_header.cr_date,clientref"

        SqlMainSource.SelectCommand = sqlString
        gv_custmaster.DataBind()
    End Sub
    Protected Sub gv_custmaster_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gv_custmaster.Sorting
        Dim sqlString As String = ""
        'sqlString = "select max(b.customer_type) as customer_type,a.stk_code,a.customer_code, SUM (a.base_qty) as qty,max(b.customer_name) as customer_name, MAX(isnull(addr1,'') + isnull(addr2,'') + isnull(addr3,'')) as customer_add  from daily_sales_tx_summary a "
        'sqlString &= "inner join custmas b on a.customer_code = b.customer_code where 1=1 " & getCriteriaSQL()
        'sqlString &= "group by a.stk_code ,a.customer_code "
        'sqlString &= "order by a.customer_code "

        sqlString = "select txn_header.cust_code,txn_header.cust_name,txn_header.txn_code,txn_header.cr_date,clientref, sum(txn_detail.stk_price * txn_detail.basic_qty) as total_price from txn_detail, txn_header , custmas  "
        sqlString &= "where txn_detail.txn_code = txn_header.txn_code and custmas.customer_code = txn_header.cust_code and 1=1 and txn_type = N'銷售' " & getCriteriaSQL()
        sqlString &= "group by txn_header.cust_code,txn_header.cust_name,txn_header.txn_code,txn_header.cr_date,clientref "
        sqlString &= "order by txn_header.cust_code,txn_header.cust_name,txn_header.txn_code,txn_header.cr_date,clientref"

        SqlMainSource.SelectCommand = sqlString
        gv_custmaster.DataBind()
    End Sub
End Class
