﻿'---------------------------------------------------------------------------- 
'程式功能	Delivery Master Maintenance
'---------------------------------------------------------------------------- 
Imports System.Data.SqlClient
Imports System
Imports System.Collections.Generic
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO
Imports System.Data.OleDb
Imports System.Data
Imports System.Windows.Forms


Partial Class _2010_2010
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()

            ' 檢查使用者權限並存入登入紀錄。 
            Check_Power("2010", True)

            '接受下一頁返回時的舊查詢條件" 
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid"), ckint) Then
                    gv_delivery_master.PageIndex = ckint
                Else
                    lb_pageid.Text = "0"
                End If
            End If



        End If
        Chk_Filter()

    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            'If cfc.Check_Power(Session("stk_code").ToString(), Session("stk_desc").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub gv_delivery_master_PageIndexChanged(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        lb_pageid.Text = e.NewPageIndex()
    End Sub

    Protected Sub Btn_Set_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Btn_Set.Click
        ' 檢查查詢條件是否改變 
        Chk_Filter()
    End Sub

    ' 檢查查詢條件是否改變 
    Private Sub Chk_Filter()
        Dim cfc As New Common_Func()

        Dim ckint As Integer = 0
        Dim tmpstr As String = ""


        Dim strSearchCode = cfc.CleanSQL(ddlVanID.Text)
        Dim strDistrict = cfc.CleanSQL(ddlDistrict.Text)


        Dim strSql As String = "select * from gm_route "
        strSql += " where is_active =1 "
        If strSearchCode.trim <> "" Then
            strSql += " and [vanCode] ='" & strSearchCode & "'"
        End If

        If strDistrict.Trim <> "" Then
            strSql += " and [District] ='" & strDistrict & "'"
        End If

        dsDeliverMaster.SelectCommand = strSql


        gv_delivery_master.DataBind()

        If gv_delivery_master.PageCount - 1 < gv_delivery_master.PageIndex Then
            gv_delivery_master.PageIndex = gv_delivery_master.PageCount
            gv_delivery_master.DataBind()
        End If

        lb_pageid.Text = gv_delivery_master.PageIndex.ToString()
    End Sub

    Protected Sub btnUpload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpload.Click
        Dim connectionString As String = ""
        If FileUpload1.HasFile Then

            Dim fileName As String = Path.GetFileName(FileUpload1.PostedFile.FileName)
            Dim fileExtension As String = Path.GetExtension(FileUpload1.PostedFile.FileName)
            Dim fileLocation As String = Server.MapPath("~/ExcelExport/" & fileName)
            FileUpload1.SaveAs(fileLocation)
            'If fileExtension = ".xls" Then
            If fileExtension = ".xls" Then
                connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=2"""
                'connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 12.0;HDR=Yes;IMEX=2"";"
            ElseIf fileExtension = ".xlsx" Then
                connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 12.0 xml;HDR=Yes"";"
            Else
                ClientScript.RegisterStartupScript(Me.GetType(), "errorScript", "alert('" & "Please select MS Excel file" & "');", True)
                Exit Sub
            End If

            gv_delivery_master.DataSource = Nothing

            Dim con As New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand()
            cmd.CommandType = System.Data.CommandType.Text
            cmd.Connection = con
            Dim dAdapter As New OleDbDataAdapter(cmd)
            Dim dtExcelRecords As New DataTable()
            Try

                con.Open()
                Dim dtExcelSheetName As DataTable = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)
                Dim getExcelSheetName As String = ""
                If dtExcelSheetName.Rows.Count > 1 Then
                    getExcelSheetName = dtExcelSheetName.Rows(1)("Table_Name").ToString()
                Else
                    getExcelSheetName = "Sheet1$"
                End If

                cmd.CommandText = "SELECT * FROM [" & getExcelSheetName & "] where vanCode is not null "
                dAdapter.SelectCommand = cmd
                dAdapter.Fill(dtExcelRecords)
                con.Close()
                If InsertExceltoDB(dtExcelRecords) = True Then
                    gv_delivery_master.DataBind()
                    ddlVanID.DataBind()
                    ddlDistrict.DataBind()
                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Upload Completed');", True)
                Else
                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Upload Failed. Please choose the right file');", True)
                End If

            Catch ex As Exception
                ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('" & ex.Message.Replace("'", "''") & "');", True)
            End Try

        Else
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Please select an excel file');", True)
        End If


    End Sub

    Private Function InsertExceltoDB(ByVal dt As DataTable) As Boolean
        dt.Columns(0).ColumnName = "vancode"
        dt.Columns(1).ColumnName = "custName"
        dt.Columns(2).ColumnName = "custNo"
        dt.Columns(3).ColumnName = "district"
        dt.Columns(4).ColumnName = "monday"
        dt.Columns(5).ColumnName = "tuesday"
        dt.Columns(6).ColumnName = "wednesday"
        dt.Columns(7).ColumnName = "thursday"
        dt.Columns(8).ColumnName = "friday"
        dt.Columns(9).ColumnName = "saturday"
        dt.Columns(10).ColumnName = "sunday"
        Dim isSucceed As Boolean = False
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim tran As SqlTransaction
        Dim da As New SqlDataAdapter
        Dim cmd As New SqlCommand()
        cmd.Connection = conn
        cmd.Connection.Open()
        tran = conn.BeginTransaction
        cmd.Transaction = tran
        Dim strSql As String
        Try
            strSql = " update gm_route set is_active = 0"
            cmd = New SqlCommand(strSql, conn)
            cmd.Transaction = tran
            cmd.ExecuteNonQuery()

            strSql = "Insert Into gm_route(vanCode,custName,custNo,district,monday,tuesday,wednesday,thursday,friday,saturday,sunday) " & _
                         " values(@vanCode, @custName, @custNo,@district,@monday,@tuesday,@wednesday,@thursday,@friday,@saturday,@sunday) "
            cmd = New SqlCommand(strSql, conn)

            cmd.CommandType = CommandType.Text
            cmd.Transaction = tran
            cmd.Parameters.Add("@vanCode", SqlDbType.VarChar, 50, "vanCode")
            cmd.Parameters.Add("@custName", SqlDbType.NVarChar, 1000, "custName")
            cmd.Parameters.Add("@custNo", SqlDbType.NVarChar, 50, "custNo")
            cmd.Parameters.Add("@district", SqlDbType.NVarChar, 50, "district")
            cmd.Parameters.Add("@monday", SqlDbType.Char, 1, "monday")
            cmd.Parameters.Add("@tuesday", SqlDbType.Char, 1, "tuesday")
            cmd.Parameters.Add("@wednesday", SqlDbType.Char, 1, "wednesday")
            cmd.Parameters.Add("@thursday", SqlDbType.Char, 1, "thursday")
            cmd.Parameters.Add("@friday", SqlDbType.Char, 1, "friday")
            cmd.Parameters.Add("@saturday", SqlDbType.Char, 1, "saturday")
            cmd.Parameters.Add("@sunday", SqlDbType.Char, 1, "sunday")
            For Each dr As DataRow In dt.Rows
                dr.SetAdded()
            Next
            da.InsertCommand = cmd
            da.Update(dt)


            strSql = " update gm_route set is_active = 1, update_date =@getdate, updated_by ='" & Session("mg_name") & "' where is_active is null"
            cmd = New SqlCommand(strSql, conn)
            cmd.Transaction = tran
            cmd.Parameters.Add("@getdate", SqlDbType.DateTime)
            cmd.Parameters("@getdate").Value = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID")))
            cmd.ExecuteNonQuery()

            tran.Commit()
            isSucceed = True
        Catch ex As Exception
            tran.Rollback()
            isSucceed = False
        End Try

        cmd.Dispose()
        da.Dispose()
        conn.Dispose()
        Return isSucceed
    End Function


    Protected Sub btnExportxlsx_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnExportxlsx.Click
        Try
            Dim dtCurrentRecord As New DataTable
            Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)

            Dim strSql As String = "Select vanCode,custName,custNo,district,monday,tuesday,wednesday,thursday,friday,saturday,sunday from gm_route where is_active = 1"
            Dim cmd As New SqlCommand(strSql, conn)
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            Dim da As New SqlDataAdapter(cmd)
            cmd.Connection.Open()
            da.Fill(dtCurrentRecord)
            cmd.Connection.Close()
            cmd.Dispose()
            da.Dispose()
            dtCurrentRecord.TableName = "gm_route"
            Dim strFileName As String = "ExcelExport_" + "_" + Format(TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))), "yyyyMMddhhmmss") + ".xlsx"
            Dim strNewPath As String = HttpContext.Current.Server.MapPath("~/ExcelExport/" & strFileName)
            Dim strPhysicalPath As String = HttpContext.Current.Server.MapPath("~/ExcelExport/" & strFileName)

            If Not IO.Directory.Exists(HttpContext.Current.Server.MapPath("~/ExcelExport")) Then
                IO.Directory.CreateDirectory(HttpContext.Current.Server.MapPath("~/ExcelExport"))
            End If

            Dim connectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & strNewPath & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=2"""
            connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & strNewPath & ";Extended Properties=""Excel 12.0 xml;Mode=ReadWrite;HDR=Yes"""

            InsertDBtoExcel(dtCurrentRecord, connectionString)

            HttpContext.Current.Response.Clear()
            Response.WriteFile(strNewPath)
            Dim httpHeader As String = "attachment;filename=" + "gm_route" + ".xlsx"
            HttpContext.Current.Response.ContentType = "application/vnd.ms-excel"
            HttpContext.Current.Response.AppendHeader("Content-Disposition", httpHeader)
            HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.Unicode


            HttpContext.Current.Response.Flush()
            System.IO.File.Delete(strNewPath)
            HttpContext.Current.Response.End()
        Catch ex As Exception
            Response.Write(ex.Message)
        End Try


    End Sub


    Protected Sub btnExport_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnExport.Click
        Try
            Dim dtCurrentRecord As New DataTable
            Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)

            Dim strSql As String = "Select vanCode,custName,custNo,district,monday,tuesday,wednesday,thursday,friday,saturday,sunday from gm_route where is_active = 1"
            Dim cmd As New SqlCommand(strSql, conn)
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            Dim da As New SqlDataAdapter(cmd)
            cmd.Connection.Open()
            da.Fill(dtCurrentRecord)
            cmd.Connection.Close()
            cmd.Dispose()
            da.Dispose()
            dtCurrentRecord.TableName = "gm_route"
            Dim strFileName As String = "ExcelExport_" + "_" + Format(TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))), "yyyyMMddhhmmss") + ".xls"
            Dim strNewPath As String = HttpContext.Current.Server.MapPath("~/ExcelExport/" & strFileName)
            Dim strPhysicalPath As String = HttpContext.Current.Server.MapPath("~/ExcelExport/" & strFileName)

            If Not IO.Directory.Exists(HttpContext.Current.Server.MapPath("~/ExcelExport")) Then
                IO.Directory.CreateDirectory(HttpContext.Current.Server.MapPath("~/ExcelExport"))
            End If

            Dim connectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & strNewPath & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=2"""
            'connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & strNewPath & ";Extended Properties=""Excel 12.0;Mode=ReadWrite;HDR=Yes;IMEX=0"""

            InsertDBtoExcel(dtCurrentRecord, connectionString)

            HttpContext.Current.Response.Clear()
            Response.WriteFile(strNewPath)
            Dim httpHeader As String = "attachment;filename=" + "gm_route" + ".xls"
            HttpContext.Current.Response.ContentType = "application/vnd.ms-excel"
            HttpContext.Current.Response.AppendHeader("Content-Disposition", httpHeader)
            HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.Unicode


            HttpContext.Current.Response.Flush()
            System.IO.File.Delete(strNewPath)
            HttpContext.Current.Response.End()
        Catch ex As Exception
            Response.Write(ex.Message)
        End Try


    End Sub

    Private Sub InsertDBtoExcel(ByVal dt As DataTable, ByVal connectionString As String)
        Dim sTime As String = Today.Year & Today.Month & Today.Day & DateTime.Now.Hour & DateTime.Now.Minute & DateTime.Now.Second
        Dim sPath = HttpContext.Current.Server.MapPath("~/ExcelExport")
        Dim objWriter As New System.IO.StreamWriter(sPath + "/route" & sTime & ".txt")

        Try



            Dim strTable As String = ""
            strTable = "CREATE TABLE [" & dt.TableName & "]("

            Dim j As Integer = 0
            For j = 0 To dt.Columns.Count - 1
                Dim dCol As DataColumn
                dCol = dt.Columns(j)

                strTable &= " [" & dCol.ColumnName & "] nvarchar(255) , "


            Next
            strTable = strTable.Substring(0, strTable.Length - 2)
            strTable &= ")"

            objWriter.WriteLine(strTable)

            Dim conn As OleDbConnection = New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand(strTable, conn)
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            cmd.Dispose()


            Dim strInsert As String
            strInsert = "Insert Into " & dt.TableName & " Values ("
            For k As Integer = 0 To dt.Columns.Count - 1
                strInsert &= "@" & dt.Columns(k).ColumnName & " , "
            Next
            strInsert = strInsert.Substring(0, strInsert.Length - 2)
            strInsert &= ")"

            objWriter.WriteLine(strInsert)

            conn.Open()

            objWriter.WriteLine("Rowcount=" & dt.Rows.Count.ToString())
            For j = 0 To dt.Rows.Count - 1
                Dim cmd2 As New OleDbCommand(strInsert, conn)
                objWriter.WriteLine("j=" & j.ToString())
                For k As Integer = 0 To dt.Columns.Count - 1

                    objWriter.WriteLine("columnName=" & dt.Columns(k).ColumnName.ToString() & " value=" & dt.Rows(j)(k).ToString())
                    If dt.Columns(k).ColumnName.EndsWith("day") Then
                        cmd2.Parameters.AddWithValue("@" & dt.Columns(k).ColumnName.ToString(), dt.Rows(j)(k).ToString().Replace("1", "x"))

                    Else
                        cmd2.Parameters.AddWithValue("@" & dt.Columns(k).ColumnName.ToString(), dt.Rows(j)(k).ToString())

                    End If

                Next

                cmd2.ExecuteNonQuery()
                cmd2.Parameters.Clear()
                cmd2.Dispose()
            Next
            conn.Close()
            objWriter.Close()

        Catch ex As Exception
            objWriter.Close()
        End Try

    End Sub


End Class
