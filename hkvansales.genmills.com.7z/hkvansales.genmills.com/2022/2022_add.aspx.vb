﻿'---------------------------------------------------------------------------- 
'程式功能	UOM Master > 明細內容 > 新增資料
'---------------------------------------------------------------------------- 

Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration
Imports System.IO
Imports System.Drawing


Partial Class _2022_2022_add
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0

            ' 檢查使用者權限但不存入登入紀錄 
            Check_Power("2022", False)

            ' 承接上一頁的查詢條件設定
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid").ToString(), ckint) Then
                    lb_page.Text = "?pageid=" & ckint.ToString()
                Else
                    lb_page.Text = "?pageid=0"
                End If
            End If

            If Request("Code") IsNot Nothing Then
                lb_page.Text &= "&Code=" & Request("Code")
            End If

        End If
    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub



    Protected Sub btnUpload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpload.Click
        Dim connectionString As String = ""
        Dim errMsg As String = ""
        If FileUpload1.HasFile Then

            Dim fileName As String = Path.GetFileName(FileUpload1.PostedFile.FileName)
            Dim fileExtension As String = Path.GetExtension(FileUpload1.PostedFile.FileName)
            Dim fileLocation As String = Server.MapPath("~/Photo/" & fileName)
            FileUpload1.SaveAs(fileLocation)
        End If

    End Sub


    Protected Sub lb_ok_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim mErr As String = ""
        Dim mg_sid As Integer = -1
        Dim intCountGroupNo As Integer = 0
        'Dim sfc As New String_Func()

        ' 載入公用函數 
        Dim cfc As New Common_Func()


        If FileUpload1.HasFile Then

            Dim fileName As String = Path.GetFileName(FileUpload1.PostedFile.FileName)
            Dim fileExtension As String = Path.GetExtension(FileUpload1.PostedFile.FileName)
            Dim fileLocation As String = Server.MapPath("~/Photo/" & fileName)
            FileUpload1.SaveAs(fileLocation)

            Dim length As Integer = FileUpload1.PostedFile.ContentLength
            Dim imgbyte As Byte() = New Byte(length - 1) {}
            Dim img As HttpPostedFile = FileUpload1.PostedFile

            img.InputStream.Read(imgbyte, 0, length)


            Using Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                Dim SqlString As String = ""
                ' Dim decoder As New Decoder()
                Dim gid As String = ""
                'SqlString &= " select isnull( max(substring(grp_id,3,6)) ,0) as gid from [customer_grp_icon] "

                'Using Sql_Command1 As New SqlCommand(SqlString, Sql_conn)
                '    Sql_conn.Open()

                '    Using Sql_Reader1 As SqlDataReader = Sql_Command1.ExecuteReader()
                '        If Sql_Reader1.Read() Then
                '            gid = (Sql_Reader1(0) + 1).ToString()
                '            gid = sfc.FillLeft(gid, 6)
                '            gid = "IC" + gid
                '        Else
                '            mErr = "Photo ID error !\n"
                '        End If
                '    End Using
                '    Sql_Command1.Dispose()
                'End Using

                gid = ddlCustGp.SelectedValue

                If mErr = "" Then
                    Sql_conn.Open()

                    ' 建立 SQL 的語法 
                    SqlString = "Insert Into [customer_grp_icon] (grp_id, grp_image)"
                    SqlString &= " Values (@photoid, @image);"

                    Using Sql_Command As New SqlCommand()
                        Sql_Command.Connection = Sql_conn
                        Sql_Command.CommandText = SqlString

                        Sql_Command.Parameters.AddWithValue("@photoid", gid)
                        Sql_Command.Parameters.AddWithValue("@image", imgbyte)

                        'Dim spt_mg_sid As SqlParameter = Sql_Command.Parameters.Add("@UOM_ID", SqlDbType.Int)
                        'spt_mg_sid.Direction = ParameterDirection.Output

                        ' Sql_conn.Open()

                        Sql_Command.ExecuteNonQuery()
                        Sql_Command.Dispose()

                        ' 取得新增資料的主鍵值 
                        mg_sid = 0
                    End Using
                End If
            End Using

        Else
            mErr &= "Please select Image \n"

        End If



        If mErr = "" Then
            mErr = ("alert('Save Success!\n');location.replace('2022.aspx" & lb_page.Text & "&sid=") + mg_sid.ToString() & "');"
        Else
            mErr = "alert('" & mErr & "')"
        End If

        lt_show.Text = "<script language=javascript>" & mErr & "</script>"


    End Sub

    Private Sub FlipImage()
        'Dim bitmap1 As Bitmap


        'Dim bmp1 As Bitmap
        'Dim img1 As Image = DirectCast(img, Image)

        'bmp1 = DirectCast(Image1, Image)

        'If bitmap1 IsNot Nothing Then
        '    bitmap1.RotateFlip(RotateFlipType.Rotate180FlipY)
        '    'PictureBox1.Image = bitmap1
        'End If



    End Sub
End Class
