﻿'---------------------------------------------------------------------------- 
'程式功能	Company Promtion Master Maintenance
'---------------------------------------------------------------------------- 
Imports System
Imports System.Collections.Generic
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Data
Imports System.Data.SqlClient
Imports Common_Func
Partial Class _2005_2005
    Inherits System.Web.UI.Page

    Private Property updateMode() As String
        Get
            Return ViewState("updateMode")
        End Get
        Set(ByVal value As String)
            ViewState("updateMode") = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()

            ' 檢查使用者權限並存入登入紀錄。 
            Check_Power("2005", True)

            '接受下一頁返回時的舊查詢條件" 
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid"), ckint) Then
                    gv_company_promotion_master.PageIndex = ckint
                Else
                    lb_pageid.Text = "0"
                End If
            End If
            SetWdayValue()


        End If


    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            'If cfc.Check_Power(Session("stk_code").ToString(), Session("stk_desc").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub gv_company_promotion_master_PageIndexChanging(ByVal sender As Object, ByVal e As GridViewPageEventArgs) Handles gv_company_promotion_master.PageIndexChanging
        'lb_pageid.Text = e.NewPageIndex()
    End Sub

    Protected Sub Btn_Set_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' 檢查查詢條件是否改變 
        Chk_Filter()
    End Sub

    ' 檢查查詢條件是否改變 
    Private Sub Chk_Filter()
        Dim cfc As New Common_Func()

        Dim ckint As Integer = 0
        Dim tmpstr As String = ""

     

        Dim strSearchGroup = cfc.CleanSQL(ddl_company_code.SelectedValue.Trim)
        Dim strSearchEngDesc = cfc.CleanSQL(ddl_stk_desc.SelectedValue.Trim)

        Dim strSql As String = "select * from item_group_master"
        strSql += " where 1=1 "

        If strSearchGroup.Trim <> "" Then strSql += " and [materialGroupCode] like '%" & strSearchGroup & "%'"
        If strSearchEngDesc.Trim <> "" Then strSql += " and [chiDesc] like '%" & strSearchEngDesc & "%'"


        dsMaterial.SelectCommand = strSql


        gv_company_promotion_master.DataBind()
        If gv_company_promotion_master.PageCount - 1 < gv_company_promotion_master.PageIndex Then
            gv_company_promotion_master.PageIndex = gv_company_promotion_master.PageCount
            gv_company_promotion_master.DataBind()
        End If

        lb_pageid.Text = gv_company_promotion_master.PageIndex.ToString()
        lb_pageid.Text = ""

        'SetWdayValue()
    End Sub

    Protected Sub GridView1_RowCommand(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        If e.CommandName = "Update" Then
            Dim strmaterialDescChi As String = DirectCast(gv_company_promotion_master.Rows(e.CommandArgument).Controls(2).Controls(0), TextBox).Text
            Dim strmaterialGroup As String = gv_company_promotion_master.Rows(e.CommandArgument).Cells(1).Text

            dsMaterial.UpdateParameters("chiDesc").DefaultValue = strmaterialDescChi
            dsMaterial.UpdateParameters("materialGroupCode").DefaultValue = strmaterialGroup
            dsMaterial.Update()
        End If
        If e.CommandName = "Edit" Then
            updateMode = "Update"
        Else
            updateMode = ""
        End If
        Chk_Filter()
    End Sub

    Protected Sub ChangeSelectedIndex(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddlGrouping As DropDownList = CType(sender, DropDownList)
        Dim strChiDesc As String = ddlGrouping.Text

        If strChiDesc.Trim <> "" Then
            Dim lblGroup As Label = CType(ddlGrouping.Parent.FindControl("lblGroup"), Label)
            Dim strMaterialGroupCode As String = lblGroup.Text
            dsMaterial.UpdateParameters("materialGroupCode").DefaultValue = strMaterialGroupCode
            dsMaterial.UpdateParameters("chiDesc").DefaultValue = strChiDesc
            dsMaterial.Update()

            ddl_stk_desc.DataBind()
            Chk_Filter()
        End If
    End Sub

    Protected Sub ddl_company_code_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddl_company_code.SelectedIndexChanged
        Chk_Filter()
    End Sub

    Protected Sub ddl_stk_desc_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddl_stk_desc.SelectedIndexChanged
        Chk_Filter()
    End Sub

    Protected Sub SetWdayValue()
        Dim dt As DataTable = ExeSQLGetDataTable("select materialGroupCode as g , isnull(wDay,'') as wDay from item_group_master ")


        For Each row In gv_company_promotion_master.Rows
            Dim strGroup As String = CType(row.cells(1).findcontrol("lblGroup"), Label).Text.Trim

            Dim dr() As DataRow = dt.Select("g = '" & strGroup & "'")
            If dr.Length > 0 Then
                Dim strWday As String = dr(0)("wDay")
                row.cells(5).findcontrol("ddlwday").selectedvalue = strWday

            End If

        Next
    End Sub

    Protected Sub UpdateWeekDay(ByVal sender As Object, ByVal e As System.EventArgs)

        Dim ddlWeekDay As DropDownList = CType(sender, DropDownList)
        Dim strWeekDay As String = ddlWeekDay.SelectedValue

        Dim lblGroup As Label = CType(ddlWeekDay.Parent.FindControl("lblGroup"), Label)
        Dim strMaterialGroupCode As String = lblGroup.Text
        Dim strUpdateSQL As String = "update item_group_master set wDay =  '" & strWeekDay & "' where materialGroupCode = '" & strMaterialGroupCode & "'"
        Dim strMsg As String = ""
        If ExeNonQuery(strUpdateSQL, strMsg) = True Then
            'OK
        Else
            ClientScript.RegisterStartupScript(Me.GetType(), "errorScript", "alert('" & strMsg.Replace("'", "") & "');", True)
            Exit Sub
        End If

    End Sub
End Class
