﻿
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration

Partial Class _4002
    Inherits System.Web.UI.Page

    Public strCommonSql As String = "from item_master i inner join item_group_master g on i.materialGroupCode = g.materialGroupCode inner join price_list p on i.materialCode = p.materialCode inner join customer_master c on p.custNo = c.custNo "


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Check_Power("4002", True)

            Dim dt As New DataTable
            dt = getNewDatatable()
            Session("IN") = dt

            ddlCustomerGroup.Items.Clear()
            ddlCustomerCode.Items.Clear()
            ddlMaterialGroup.Items.Clear()
            ddlMaterial.Items.Clear()
            SetInterface("New")
        End If
        Literal1.Text = ""

    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim strMsg As String = ""

        If gv_products.Rows.Count = 0 Then
            strMsg = "Please Add some items before saving"
        End If

        If strMsg = "" Then
            If ValidateIsDuplicated(strMsg) And rdbNew.Checked = True Then
                strMsg = "This customer has a pre-order on the same shipping date. \n Record is not saved."
            End If
        End If

        If strMsg = "" Then
            If rdbNew.Checked = True Then                       'New Record
                Dim strDB_PreOrderNo As String = RetrieveRunningPreOrderNo(ddlVan.SelectedValue)
                InsertToDB(strMsg, strDB_PreOrderNo)

            ElseIf rdbEdit.Checked = True Then                  'Update Record
                Dim strDB_PreOrderNo As String = ddlRecord.Text
                UpdateToDB(strMsg, strDB_PreOrderNo)
            End If
        End If

        If strMsg = "" Then
            strMsg = "Record saved successfully!"
            SetInterface("New")
        End If

        ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('" & strMsg & "')", True)


    End Sub

    Protected Sub ddlVan_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlVan.SelectedIndexChanged
        ddlCustomerGroup.Items.Clear()
        ddlCustomerCode.Items.Clear()
        ddlMaterialGroup.Items.Clear()
        ddlMaterial.Items.Clear()

        Dim strVanId As String = Right(ddlVan.SelectedValue, 3)
        dsCustomerGroup.SelectCommand = String.Format("SELECT g.name1, g.custGroup FROM customer_group_master g inner join customer_master c on g.custGroup = c.custGroup WHERE right(c.shippingPoint,3) = '{0}' union select '','' ORDER BY [name1]", strVanId)
        ddlCustomerGroup.DataBind()
    End Sub
  
    Protected Sub ddlCustomerGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCustomerGroup.SelectedIndexChanged
        ddlCustomerCode.Items.Clear()
        ddlMaterialGroup.Items.Clear()
        ddlMaterial.Items.Clear()

        Dim strName1 As String = ddlCustomerGroup.SelectedValue
        Dim strVanId As String = Right(ddlVan.SelectedValue, 3)
        dsCustomerMaster.SelectCommand = String.Format("SELECT [custNo]+' '+ [name1] as custNo,name1 FROM [customer_master] WHERE right(shippingPoint,3) ='{0}' and custGroup = '{1}' union select '','' ORDER BY [custNo]", strVanId, strName1)
        ddlCustomerCode.DataBind()
    End Sub

    Protected Sub ddlCustomerCode_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCustomerCode.SelectedIndexChanged

        ddlMaterialGroup.Items.Clear()
        ddlMaterial.Items.Clear()

        Dim strCustNo As String = ddlCustomerCode.SelectedValue.Substring(0, 10)
        If IsInfoCodeExist(strCustNo) Then
            dsItemGroup.SelectCommand = "SELECT DISTINCT  g.chiDesc " & strCommonSql & " and c.custNo = '" & strCustNo & "' inner join customer_material_info info on c.custNo = info.custNo and i.materialCode = info.materialCode where c.custNo = '" & strCustNo & "' union select  '' ORDER BY [chiDesc]"
        Else
            dsItemGroup.SelectCommand = "SELECT DISTINCT  g.chiDesc " & strCommonSql & " where c.custNo = '" & strCustNo & "' union select '' ORDER BY [chiDesc]"
        End If
        ddlMaterialGroup.DataBind()
    End Sub

    Protected Sub ddlMaterialGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlMaterialGroup.SelectedIndexChanged
        ddlMaterial.Items.Clear()

        Dim strName1 As String = ddlMaterialGroup.SelectedValue
        Dim strCustNo As String = ddlCustomerCode.SelectedValue.Substring(0, 10)

        If IsInfoCodeExist(strCustNo) Then
            dsItem.SelectCommand = String.Format("SELECT DISTINCT i.materialCode +' '+ i.chiDesc as materialCode2, i.materialCode FROM [item_master] i inner join price_list p on i.materialCode = p.materialCode and p.custNo = '" & strCustNo & "' inner join customer_material_info info on p.custNo = info.custNo and i.materialCode = info.materialCode inner join item_group_master im on im.materialGroupCode = i.materialGroupCode where im.chiDesc = '{0}' union select '','' ORDER BY [materialCode]", strName1)
        Else
            dsItem.SelectCommand = String.Format("SELECT DISTINCT i.materialCode +' '+ i.chiDesc as materialCode2, i.materialCode FROM [item_master] i inner join price_list p on i.materialCode = p.materialCode inner join item_group_master im on im.materialGroupCode = i.materialGroupCode where im.chiDesc = '{0}' union select '','' ORDER BY [materialCode]", strName1)
        End If

        ddlMaterial.DataBind()
    End Sub

    Protected Sub GridView1_RowDeleting(ByVal sender As Object, ByVal e As GridViewDeleteEventArgs)

        Dim dt As DataTable
        dt = Session("IN")
        dt.Rows(e.RowIndex.ToString()).Delete()
        dt.AcceptChanges()
        gv_products.DataSourceID = Nothing
        gv_products.DataSource = dt

        Session("IN") = dt

        If (dt.Rows.Count = 0) Then
            gv_products.DataSource = Nothing
        End If
        gv_products.DataBind()

        LockHeader()
    End Sub

    Protected Sub gv_products_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs) Handles gv_products.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim lb As LinkButton = DirectCast(e.Row.Cells(4).Controls(0), LinkButton)
            lb.OnClientClick = "return confirm('Confirm to delete record?')"
        End If

    End Sub
  
    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Dim strMsg As String = ""
        If ValidateAdd(strMsg) Then
            Dim dt As DataTable
            dt = Session("IN")

            Dim strItem As String = ddlMaterial.SelectedValue.Trim
            Dim strCustNo As String = ddlCustomerCode.SelectedItem.Text.Substring(0, 10)
            Dim strQuantity As String = txtQuantity.Text

            Dim getDb As New RetrieveItemCustDetail(strItem, strCustNo)

            dt.Rows.Add(strItem, getDb.strCustMaterialCode, strQuantity, getDb.strNetPrice)

            gv_products.DataSourceID = Nothing
            gv_products.DataSource = dt
            gv_products.DataBind()

            ClearHeader()

        Else

            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "key", "alert('" & strMsg & "');", True)
        End If
        LockHeader()
    End Sub

    Protected Sub rdbNew_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdbNew.CheckedChanged
        SetInterface("New")
    End Sub

    Protected Sub rdbEdit_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdbEdit.CheckedChanged
        SetInterface("Edit")
    End Sub

    Protected Sub ddlRecord_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlRecord.SelectedIndexChanged
        ddlMaterial.Items.Clear()
        txtQuantity.Text = ""
        If ddlRecord.Text <> "" Then
            BindRecordHeader(ddlRecord.Text)
            BindRecordDetail(ddlRecord.Text)
            btnDelete.Enabled = True
            btnAdd.Enabled = True
            btnSave.Enabled = True

        Else
            btnDelete.Enabled = False
            btnAdd.Enabled = False
            btnSave.Enabled = False
            SetInterface("Edit")
        End If

    End Sub

    Protected Sub btnDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Dim Sql_Conn1 As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim SqlString1 As String = "delete from rush_order_header where refDocNo = '" & ddlRecord.Text & "' "
        SqlString1 += " delete from rush_order_detail where refDocNo = '" & ddlRecord.Text & "' "

        Dim Sql_Command1 As New SqlCommand(SqlString1, Sql_Conn1)
        Sql_Conn1.Open()
        Sql_Command1.ExecuteNonQuery()
        Sql_Conn1.Close()
        ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('" & "Record Deleted" & "')", True)
        SetInterface("Edit")
    End Sub

    Protected Sub btnClear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClear.Click
        SetInterface("New")
    End Sub

    Private Function ValidateAdd(ByRef strMsg As String) As Boolean

        If txtShippingDate.Text.Trim = "" Then
            strMsg &= "Ship Date should not be empty!\n"
        End If

        Try
            Dim dtmtest As Date = CDate(txtShippingDate.Text.Trim)
            If dtmtest < TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))) Then
                strMsg &= "Ship Date should be a future date!\n"
            End If
        Catch ex As Exception
            strMsg &= "Ship Date should be [yyyy/MM/dd]!\n"
        End Try



        If ddlVan.Text = "" Then
            strMsg &= "Van Id should not be empty!\n"
        End If

        If ddlVan.Text = "" Then
            strMsg &= "Van Id should not be empty!\n"
        End If

        If ddlCustomerGroup.Text = "" Then
            strMsg &= "Customer Group should not be empty!\n"
        End If

        If ddlCustomerCode.Text = "" Then
            strMsg &= "Customer No. should not be empty!\n"
        End If


        If ddlMaterialGroup.Text = "" Then
            strMsg &= "Item Group should not be empty!\n"
        End If

        If ddlMaterial.Text = "" Then
            strMsg &= "Material should not be empty!\n"
        End If


        Dim dt As DataTable = Session("IN")

        For i = 0 To dt.Rows.Count - 1
            If dt.Rows.Item(i)("MaterialCode") = ddlMaterial.SelectedValue.Trim Then
                strMsg &= "Duplicated record is not allowed!\n"
            End If
        Next

        If txtQuantity.Text.Trim = "" Then
            strMsg &= "Quantity should not be empty!\n"
        ElseIf Not IsNumeric(txtQuantity.Text.Trim) Then
            strMsg &= "Quantity should be numeric!\n"
        ElseIf Not CInt(txtQuantity.Text.Trim) = txtQuantity.Text.Trim Then
            strMsg &= "Quantity should not be integer!\n"
        ElseIf CInt(txtQuantity.Text.Trim) = 0 Then
            strMsg &= "Quantity should not be 0!\n"
        ElseIf Not Math.Abs(CInt(txtQuantity.Text.Trim)) = CInt(txtQuantity.Text.Trim) Then
            strMsg &= "Quantity should not be negative!\n"
        End If

        If strMsg <> "" Then
            Return False
        End If


        Return True
    End Function

    Private Function ValidateIsDuplicated(ByRef strMsg As String) As Boolean

        Dim result As Boolean = False
        Dim Sql_Conn1 As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim SqlString1 As String = "select refDocNo from rush_order_header where custNo = @custNo and ship_date = @ship_date"

        Dim Sql_Command1 As New SqlCommand(SqlString1, Sql_Conn1)

        Sql_Command1.Parameters.Add("@custNo", SqlDbType.NVarChar, 100)
        Sql_Command1.Parameters("@custNo").Value = ddlCustomerCode.Text.Substring(0, 10)

        Sql_Command1.Parameters.Add("@ship_date", SqlDbType.DateTime, 100)
        Sql_Command1.Parameters("@ship_date").Value = CDate(txtShippingDate.Text)
        Try
            Sql_Conn1.Open()
            Dim Sql_Reader1 As SqlDataReader = Sql_Command1.ExecuteReader()
            If Sql_Reader1.Read() Then

                result = True
            End If
            Sql_Reader1.Close()
            Sql_Conn1.Close()

        Catch ex As Exception
            strMsg = ex.Message
        End Try
        Return result
    End Function

    Private Sub ClearHeader()
        txtQuantity.Text = ""
    End Sub

    Private Sub ClearAll()
        txtQuantity.Text = ""
        ddlCustomerCode.Items.Clear()
        ddlCustomerGroup.Items.Clear()
        ddlMaterialGroup.Items.Clear()
        ddlRecord.Items.Clear()
        ddlVan.Items.Clear()
        ddlMaterial.Items.Clear()
        txtShippingDate.Text = ""

        Dim dt As New DataTable
        Session("IN") = getNewDatatable()
        dt = Session("IN")
        If (dt.Rows.Count = 0) Then
            gv_products.DataSource = Nothing
        End If
        gv_products.DataBind()

    End Sub

    Private Sub LockHeader()
        If gv_products.Rows.Count > 0 Or rdbEdit.Checked = True Then
            ddlVan.Enabled = False
            ddlCustomerGroup.Enabled = False
            ddlCustomerCode.Enabled = False
            txtShippingDate.Enabled = False
        Else
            ddlVan.Enabled = True
            ddlCustomerGroup.Enabled = True
            ddlCustomerCode.Enabled = True
            txtShippingDate.Enabled = True
        End If
    End Sub

    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Private Function getNewDatatable() As DataTable
        Dim dt As New DataTable
        dt.Columns.Add("materialCode", GetType(System.String))
        dt.Columns.Add("custMaterialCode", GetType(System.String))
        dt.Columns.Add("quantity", GetType(System.String))
        dt.Columns.Add("netPrice", GetType(System.String))

        Return dt
    End Function

    Private Sub BindRecordHeader(ByVal strRefDocNo As String)
        Dim strVanId As String = ""
        Dim strShipDate As String = ""
        Dim strCustomerGroup As String = ""
        Dim strCustomer As String = ""

        Dim Sql_Conn1 As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim SqlString1 As String = "select b.vanCode, h.custNo, c.name1 as c_Name1, h.ship_date, g.custGroup, g.name1 as g_name1 from rush_order_header h inner join customer_master c on c.custNo = h.custNo and h.refDocNo = '" & strRefDocNo & "' inner join customer_group_master g on g.custGroup = c.custGroup inner join business_unit b on right(b.vanCode,3) = h.van_id "

        Dim Sql_Command1 As New SqlCommand(SqlString1, Sql_Conn1)
        Sql_Conn1.Open()

        Dim Sql_Reader1 As SqlDataReader = Sql_Command1.ExecuteReader()
        If Sql_Reader1.Read() Then
            strVanId = Sql_Reader1("vanCode").ToString
            strShipDate = Sql_Reader1("ship_date").ToString
            strCustomerGroup = Sql_Reader1("custGroup").ToString
            strCustomer = Sql_Reader1("custNo").ToString & " " & Sql_Reader1("c_Name1").ToString
        End If
        Sql_Reader1.Close()
        Sql_Conn1.Close()

        txtShippingDate.Text = CDate(strShipDate).ToString("yyyy/MM/dd")

        ddlVan.Text = strVanId
        dsCustomerGroup.SelectCommand = String.Format("SELECT g.name1, g.custGroup FROM customer_group_master g inner join customer_master c on g.custGroup = c.custGroup WHERE right(c.shippingPoint,3) = '{0}' union select '','' ORDER BY [name1]", Right(strVanId, 3))
        ddlCustomerGroup.DataBind()

        ddlCustomerGroup.Text = strCustomerGroup
        dsCustomerMaster.SelectCommand = String.Format("SELECT [custNo]+' '+ [name1] as custNo,name1 FROM [customer_master] WHERE custGroup = '{0}' union select '','' ORDER BY [custNo]", strCustomerGroup)
        ddlCustomerCode.DataBind()

        ddlCustomerCode.Text = strCustomer
        dsItemGroup.SelectCommand = "SELECT DISTINCT g.chiDesc " & strCommonSql & " where c.custNo = '" & strCustomer.Substring(0, 10) & "' union select '' ORDER BY [chiDesc]"
        ddlMaterialGroup.DataBind()

    End Sub

    Private Sub BindRecordDetail(ByVal strRefDocNo As String)
        Dim strVanId As String = ""
        Dim strShipDate As String = ""
        Dim strCustomerGroup As String = ""
        Dim strCustomer As String = ""

        Dim Sql_Conn1 As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim SqlString1 As String = "select materialCode,custMaterialCode,quantity,netPrice from rush_order_detail where refDocNo = '" & strRefDocNo & "'"
        Dim Sql_Command1 As New SqlCommand(SqlString1, Sql_Conn1)
        Dim dt As New DataTable
        Dim sqlDa As New SqlDataAdapter(Sql_Command1)
        sqlDa.Fill(dt)

        Sql_Command1.Dispose()
        Session("IN") = dt
        gv_products.DataSourceID = Nothing
        gv_products.DataSource = dt
        gv_products.DataBind()

    End Sub

    Private Sub SetInterface(ByVal strMode As String)
        If strMode = "New" Then
            rdbEdit.Checked = False
            lblAutoGen.Visible = True
            ddlRecord.Visible = False
            btnDelete.Visible = False
            btnClear.Visible = True
            ClearAll()
            ddlVan.DataBind()
            ddlRecord.DataBind()
            btnDelete.Enabled = False
            btnAdd.Enabled = True
            btnSave.Enabled = True
            ddlVan.Enabled = True
            ddlCustomerGroup.Enabled = True
            ddlCustomerCode.Enabled = True
            txtShippingDate.Enabled = True

            cbeSave.Enabled = False
        End If

        If strMode = "Edit" Then
            rdbNew.Checked = False
            lblAutoGen.Visible = False
            ddlRecord.Visible = True
            btnDelete.Visible = True
            btnClear.Visible = False
            ClearAll()
            ddlVan.DataBind()
            ddlRecord.DataBind()
            btnDelete.Enabled = False
            btnAdd.Enabled = False
            btnSave.Enabled = False

            ddlVan.Enabled = False
            ddlCustomerGroup.Enabled = False
            ddlCustomerCode.Enabled = False
            txtShippingDate.Enabled = False
            cbeSave.Enabled = True
        End If

    End Sub

    Private Function RetrieveRunningPreOrderNo(ByVal strVanCode As String) As String
        Dim Sql_Conn1 As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim SqlString1 As String = "select b.last_pre_order_no from business_unit b where right(vanCode,3) = '" & Right(strVanCode, 3) & "'"

        Dim Sql_Command1 As New SqlCommand(SqlString1, Sql_Conn1)
        Sql_Conn1.Open()

        Dim strPO_no As String = ""

        Dim Sql_Reader1 As SqlDataReader = Sql_Command1.ExecuteReader()
        If Sql_Reader1.Read() Then
            strPO_no = Sql_Reader1("last_pre_order_no").ToString
        End If
        Sql_Reader1.Close()
        Sql_Conn1.Close()
        Dim intRunning As Integer = CInt(Right(strPO_no, 9)) + 1
        strPO_no = "SO" & strPO_no.Substring(0, 4) & Right(("0000000000" & intRunning), 9)

        Return strPO_no
    End Function

    Private Function RetrieveTotalQuantity(ByVal dt As DataTable) As Integer
        Dim intResult As Integer = 0
        For i = 0 To dt.Rows.Count - 1
            intResult += CInt(dt.Rows.Item(i)("quantity"))
        Next
        Return intResult
    End Function

    Private Function RetrieveTotalPrice(ByVal dt As DataTable) As Double
        Dim intResult As Double = 0
        For i = 0 To dt.Rows.Count - 1
            intResult += CDbl(dt.Rows.Item(i)("netPrice")) * CInt(dt.Rows.Item(i)("quantity"))
        Next
        Return intResult
    End Function

    Private Sub InsertToDB(ByRef strMsg As String, ByVal strPreOrderNo As String)
        Dim isSucceed As Boolean = False
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim tran As SqlClient.SqlTransaction
        Dim da As New SqlDataAdapter
        Dim cmd As New SqlCommand()

        Try
            cmd.Connection = conn
            cmd.Connection.Open()
            tran = conn.BeginTransaction
            cmd.Transaction = tran

            Dim dt As DataTable = Session("IN")

            Dim strRefDocNo As String = strPreOrderNo
            Dim strPO_no As String = ""
            Dim strCustNo As String = ddlCustomerCode.SelectedValue.Substring(0, 10)
            Dim strVan_id As String = Right(ddlVan.Text, 3)
            Dim strUser_id As String = Session("mg_name")
            Dim dtmCr_date As DateTime = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID")))
            Dim intTotalQuantity As Integer = RetrieveTotalQuantity(dt)
            Dim dblTotalPrice As Double = RetrieveTotalPrice(dt)
            Dim intDetailCount As Integer = dt.Rows.Count
            Dim dtmShipDate As DateTime = CDate(txtShippingDate.Text)

            Dim intSeqNo As Integer = 0
            Dim strMaterialCode As String = ""
            Dim strCustMaterialCode As String = ""
            Dim intQuantity As Integer = 0
            Dim dblNetPrice As Double = 0
            Dim dblGrossPrice As Double = 0



            isSucceed = Me.InsertHeader(cmd, conn, tran, strMsg, strRefDocNo, strPO_no, strCustNo, strVan_id, strUser_id, dtmCr_date, intTotalQuantity, dblTotalPrice, intDetailCount, dtmShipDate)



            If (isSucceed) Then
                For i = 0 To dt.Rows.Count - 1
                    intSeqNo += 10
                    strMaterialCode = dt.Rows.Item(i)("materialCode")
                    strCustMaterialCode = dt.Rows.Item(i)("custMaterialCode")
                    intQuantity = dt.Rows.Item(i)("quantity")
                    dblNetPrice = dt.Rows.Item(i)("netPrice")
                    dblGrossPrice = dt.Rows.Item(i)("netPrice")

                    isSucceed = Me.InsertDetail(cmd, conn, tran, strRefDocNo, strPO_no, strCustNo, intSeqNo, strMaterialCode, strCustMaterialCode, intQuantity, dblNetPrice, dblGrossPrice, strMsg)
                    If isSucceed = False Then
                        Exit For
                    End If
                Next

            End If

            If (isSucceed) Then
                isSucceed = UpdateRunningNo(cmd, conn, tran, strMsg, strVan_id, strRefDocNo)
            End If


            If (isSucceed) Then
                tran.Commit()
                isSucceed = True
            Else
                tran.Rollback()
                isSucceed = False
            End If
        Catch ex As Exception
            tran.Rollback()
            strMsg = ex.Message
        Finally
            cmd.Dispose()
            da.Dispose()
            conn.Dispose()
        End Try


    End Sub

    Private Function InsertHeader(ByVal cmd As SqlCommand, ByVal conn As SqlConnection, ByVal tran As SqlTransaction, ByRef strMsg As String, _
                                 ByVal strRefDocNo As String, ByVal strPO_no As String, ByVal strCustNo As String, ByVal strVan_id As String, _
                                 ByVal strUser_id As String, ByVal dtmCr_date As String, ByVal intTotalQuantity As Integer, _
                                 ByVal dblTotalPrice As Double, ByVal intDetailCount As Integer, ByVal dtmShipDate As DateTime) As Boolean



        Dim isSucceed As Boolean = False
        Dim strSql As String = "Insert into rush_order_header(refDocNo, PO_no,custNo,van_id,user_id,cr_date,total_quantity,total_price,detail_count,ship_date) "
        strSql &= "values(@refDocNo, @PO_no,@custNo,@van_id,@user_id,@cr_date,@total_quantity,@total_price,@detail_count,@shippingDate)"
        Try
            cmd = New SqlCommand(strSql, conn)
            cmd.Transaction = tran
            cmd.CommandType = CommandType.Text

            cmd.Parameters.Add("@refDocNo", SqlDbType.NVarChar, 100)
            cmd.Parameters("@refDocNo").Value = strRefDocNo

            cmd.Parameters.Add("@PO_no", SqlDbType.NVarChar, 100)
            cmd.Parameters("@PO_no").Value = strPO_no

            cmd.Parameters.Add("@custNo", SqlDbType.NVarChar, 100)
            cmd.Parameters("@custNo").Value = strCustNo

            cmd.Parameters.Add("@van_id", SqlDbType.NVarChar, 100)
            cmd.Parameters("@van_id").Value = strVan_id

            cmd.Parameters.Add("@user_id", SqlDbType.NVarChar, 100)
            cmd.Parameters("@user_id").Value = strUser_id

            cmd.Parameters.Add("@cr_date", SqlDbType.DateTime, 100)
            cmd.Parameters("@cr_date").Value = dtmCr_date

            cmd.Parameters.Add("@total_quantity", SqlDbType.Int, 100)
            cmd.Parameters("@total_quantity").Value = intTotalQuantity


            cmd.Parameters.Add("@total_price", SqlDbType.Float, 100)
            cmd.Parameters("@total_price").Value = dblTotalPrice

            cmd.Parameters.Add("@detail_count", SqlDbType.NVarChar, 100)
            cmd.Parameters("@detail_count").Value = intDetailCount

            cmd.Parameters.Add("@shippingDate", SqlDbType.DateTime, 100)
            cmd.Parameters("@shippingDate").Value = dtmShipDate

            cmd.CommandTimeout = 0
            cmd.ExecuteNonQuery()
            isSucceed = True
        Catch ex As Exception
            strMsg = ex.Message
            isSucceed = False
        End Try

        Return isSucceed
    End Function

    Private Function InsertDetail(ByVal cmd As SqlCommand, ByVal conn As SqlConnection, ByVal tran As SqlTransaction, ByVal strRefDocNo As String, _
                                  ByVal strPO_no As String, ByVal strCustNo As String, ByVal intSeqNo As Integer, ByVal strMaterialCode As String, _
                                  ByVal strCustMaterialCode As String, ByVal intQuantity As Integer, ByVal dblNetPrice As Double, ByVal dblGrossPrice As Double, ByRef strMsg As String) As Boolean
        Dim isSucceed As Boolean = False

        Dim da As New SqlDataAdapter
        Dim strSql As String = "Insert into rush_order_detail(refDocNo, PO_no,custNo,SeqNo,materialCode,custMaterialCode,quantity,netPrice,grossPrice)"
        strSql &= " values(@refDocNo, @PO_no,@custNo,@SeqNo,@materialCode,@custMaterialCode,@quantity,@netPrice,@grossPrice)"

        Try
            cmd = New SqlCommand(strSql, conn)
            cmd.Transaction = tran
            cmd.CommandType = CommandType.Text

            cmd.Parameters.Add("@refDocNo", SqlDbType.NVarChar, 100)
            cmd.Parameters("@refDocNo").Value = strRefDocNo

            cmd.Parameters.Add("@PO_no", SqlDbType.NVarChar, 100)
            cmd.Parameters("@PO_no").Value = strPO_no

            cmd.Parameters.Add("@custNo", SqlDbType.NVarChar, 100)
            cmd.Parameters("@custNo").Value = strCustNo

            cmd.Parameters.Add("@SeqNo", SqlDbType.Int, 100)
            cmd.Parameters("@SeqNo").Value = intSeqNo

            cmd.Parameters.Add("@materialCode", SqlDbType.NVarChar, 100)
            cmd.Parameters("@materialCode").Value = strMaterialCode

            cmd.Parameters.Add("@custMaterialCode", SqlDbType.NVarChar, 100)
            cmd.Parameters("@custMaterialCode").Value = strCustMaterialCode

            cmd.Parameters.Add("@quantity", SqlDbType.Int, 100)
            cmd.Parameters("@quantity").Value = intQuantity


            cmd.Parameters.Add("@netPrice", SqlDbType.Float, 100)
            cmd.Parameters("@netPrice").Value = dblNetPrice

            cmd.Parameters.Add("@grossPrice", SqlDbType.Float, 100)
            cmd.Parameters("@grossPrice").Value = dblGrossPrice



            cmd.CommandTimeout = 0
            cmd.ExecuteNonQuery()
            isSucceed = True
        Catch ex As Exception
            strMsg = ex.Message
            isSucceed = False
        End Try

        Return isSucceed
    End Function

    Private Sub UpdateToDB(ByRef strMsg As String, ByVal strPreOrderNo As String)
        Dim isSucceed As Boolean = False
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim tran As SqlClient.SqlTransaction
        Dim da As New SqlDataAdapter
        Dim cmd As New SqlCommand()

        Try
            cmd.Connection = conn
            cmd.Connection.Open()
            tran = conn.BeginTransaction
            cmd.Transaction = tran

            Dim dt As DataTable = Session("IN")

            Dim strRefDocNo As String = strPreOrderNo
            Dim strPO_no As String = ""
            Dim strCustNo As String = ddlCustomerCode.SelectedValue.Substring(0, 10)
            Dim strVan_id As String = Right(ddlVan.Text, 3)
            Dim strUser_id As String = Session("mg_name")
            Dim dtmCr_date As DateTime = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID")))
            Dim intTotalQuantity As Integer = RetrieveTotalQuantity(dt)
            Dim dblTotalPrice As Double = RetrieveTotalPrice(dt)
            Dim intDetailCount As Integer = dt.Rows.Count
            Dim dtmShipDate As DateTime = CDate(txtShippingDate.Text)

            Dim intSeqNo As Integer = 0
            Dim strMaterialCode As String = ""
            Dim strCustMaterialCode As String = ""
            Dim intQuantity As Integer = 0
            Dim dblNetPrice As Double = 0
            Dim dblGrossPrice As Double = 0

            isSucceed = Me.DeleteHeader(cmd, conn, tran, strMsg, strRefDocNo)
            isSucceed = Me.DeleteDetail(cmd, conn, tran, strMsg, strRefDocNo)
            isSucceed = Me.InsertHeader(cmd, conn, tran, strMsg, strRefDocNo, strPO_no, strCustNo, strVan_id, strUser_id, dtmCr_date, intTotalQuantity, dblTotalPrice, intDetailCount, dtmShipDate)

            If (isSucceed) Then
                For i = 0 To dt.Rows.Count - 1
                    intSeqNo += 10
                    strMaterialCode = dt.Rows.Item(i)("materialCode")
                    strCustMaterialCode = dt.Rows.Item(i)("custMaterialCode")
                    intQuantity = dt.Rows.Item(i)("quantity")
                    dblNetPrice = dt.Rows.Item(i)("netPrice")
                    dblGrossPrice = dt.Rows.Item(i)("netPrice")
                    isSucceed = Me.InsertDetail(cmd, conn, tran, strRefDocNo, strPO_no, strCustNo, intSeqNo, strMaterialCode, strCustMaterialCode, intQuantity, dblNetPrice, dblGrossPrice, strMsg)
                    If isSucceed = False Then
                        Exit For
                    End If
                Next
            End If

            If (isSucceed) Then
                tran.Commit()
                isSucceed = True
            Else
                tran.Rollback()
                isSucceed = False
            End If
        Catch ex As Exception
            tran.Rollback()
            strMsg = ex.Message
        Finally
            cmd.Dispose()
            da.Dispose()
            conn.Dispose()
        End Try

    End Sub

    Private Function UpdateRunningNo(ByVal cmd As SqlCommand, ByVal conn As SqlConnection, ByVal tran As SqlTransaction, ByRef strMsg As String, ByVal strVanId As String, ByVal strRefDocNo As String) As Boolean
        Dim isSucceed As Boolean = False
        strRefDocNo = Right(strRefDocNo, 13)
        Dim strSql As String = "Update business_unit set last_pre_order_no = '" & strRefDocNo & "' where right(vanCode,3) = '" & strVanId & "'"

        Try
            cmd = New SqlCommand(strSql, conn)
            cmd.Transaction = tran
            cmd.CommandType = CommandType.Text

            cmd.CommandTimeout = 0
            cmd.ExecuteNonQuery()
            isSucceed = True
        Catch ex As Exception
            strMsg = ex.Message
            isSucceed = False
        End Try

        Return isSucceed
    End Function

    Private Function DeleteHeader(ByVal cmd As SqlCommand, ByVal conn As SqlConnection, ByVal tran As SqlTransaction, _
                                                        ByRef strMsg As String, ByVal strRefDocNo As String) As Boolean
        Dim isSucceed As Boolean = False
        Dim strSql As String = "delete from rush_order_header where refDocNo = @refDocNo "
        Try
            cmd = New SqlCommand(strSql, conn)
            cmd.Transaction = tran
            cmd.CommandType = CommandType.Text

            cmd.Parameters.Add("@refDocNo", SqlDbType.NVarChar, 100)
            cmd.Parameters("@refDocNo").Value = strRefDocNo
            cmd.CommandTimeout = 0
            cmd.ExecuteNonQuery()
            isSucceed = True
        Catch ex As Exception
            strMsg = ex.Message
            isSucceed = False
        End Try

        Return isSucceed

    End Function

    Private Function DeleteDetail(ByVal cmd As SqlCommand, ByVal conn As SqlConnection, ByVal tran As SqlTransaction, _
                                                        ByRef strMsg As String, ByVal strRefDocNo As String) As Boolean
        Dim isSucceed As Boolean = False
        Dim strSql As String = "delete from rush_order_detail where refDocNo = @refDocNo "
        Try
            cmd = New SqlCommand(strSql, conn)
            cmd.Transaction = tran
            cmd.CommandType = CommandType.Text

            cmd.Parameters.Add("@refDocNo", SqlDbType.NVarChar, 100)
            cmd.Parameters("@refDocNo").Value = strRefDocNo
            cmd.CommandTimeout = 0
            cmd.ExecuteNonQuery()
            isSucceed = True
        Catch ex As Exception
            strMsg = ex.Message
            isSucceed = False
        End Try

        Return isSucceed

    End Function

    Private Function IsInfoCodeExist(ByVal strCustNo As String) As Boolean
        Dim Sql_Conn1 As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim SqlString1 As String = "select InfoCodeExist from customer_master where custNo = '" & strCustNo & "'"

        Dim Sql_Command1 As New SqlCommand(SqlString1, Sql_Conn1)
        Sql_Conn1.Open()

        Dim result As Boolean = False

        Dim Sql_Reader1 As SqlDataReader = Sql_Command1.ExecuteReader()
        If Sql_Reader1.Read() Then
            If Sql_Reader1("InfoCodeExist").ToString = "1" Then
                result = True
            Else
                result = False
            End If
        End If
        Sql_Reader1.Close()
        Sql_Conn1.Close()

        Return result
    End Function

End Class


Class RetrieveItemCustDetail

    Public strCustMaterialCode As String
    Public strNetPrice As String
    Public strGrossPrice As String
    Public strCustName As String

    Public Sub New(ByVal strItem As String, ByVal strCustNo As String)
        Dim Sql_Conn1 As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim SqlString1 As String = "select i.materialCode,p.netPrice,p.netPrice as grossPrice,c.custNo,c.name2,info.custMaterialCode from item_master i"
        SqlString1 &= " inner join item_group_master g on i.materialGroupCode = g.materialGroupCode "
        SqlString1 &= " inner join price_list p on i.materialCode = p.materialCode "
        SqlString1 &= " inner join customer_master c on p.custNo = c.custNo"
        SqlString1 &= " left outer join customer_material_info info on i.materialCode = info.materialCode and c.custNo = info.custNo"
        SqlString1 &= " where c.custNo ='" & strCustNo & "' and i.materialCode = '" & strItem & "'"

        Dim Sql_Command1 As New SqlCommand(SqlString1, Sql_Conn1)
        Sql_Conn1.Open()

        Using Sql_Reader1 As SqlDataReader = Sql_Command1.ExecuteReader()
            If Sql_Reader1.Read() Then
                strCustMaterialCode = Sql_Reader1("custMaterialCode").ToString
                strNetPrice = Sql_Reader1("netPrice").ToString
                strGrossPrice = Sql_Reader1("grossPrice").ToString
                strCustName = Sql_Reader1("name2").ToString
            End If
        End Using
        Sql_Conn1.Close()
    End Sub

End Class

