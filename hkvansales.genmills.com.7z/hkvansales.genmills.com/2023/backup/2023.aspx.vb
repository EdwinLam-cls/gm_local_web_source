﻿'---------------------------------------------------------------------------- 
'程式功能	Customer Manster Master Maintenance
'---------------------------------------------------------------------------- 
Imports System
Imports System.Collections.Generic
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Data
Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports System.IO

Partial Class _2023_2023
    Inherits System.Web.UI.Page
    Private s3 As String
    Private s4 As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()



            ' 檢查使用者權限並存入登入紀錄。 
            Check_Power("2023", True)

            '接受下一頁返回時的舊查詢條件" 
            If Request("pageid") IsNot Nothing Then

                If Integer.TryParse(Request("pageid"), ckint) Then
                    gv_delivery_schedule.PageIndex = ckint
                    lb_pageid.Text = gv_delivery_schedule.PageIndex
                Else
                    lb_pageid.Text = "0"
                End If

            End If



            'If Request("s1") IsNot Nothing Then
            '    txtCustNo.Text = Request("s1")
            'End If

            'If Request("s2") IsNot Nothing Then
            '    tb_customer_code.Text = Request("s2")
            'End If

            'If Request("s3") IsNot Nothing Then
            '    tb_company_code.DataSourceID = Nothing
            '    tb_company_code.DataSource = RetrieveDataTable("select [name1] from [customer_group_master] union select ''")
            '    tb_company_code.DataBind()
            '    Try
            '        tb_company_code.SelectedValue = Request("s3")
            '    Catch
            '    End Try
            'End If

            'If Request("s4") IsNot Nothing Then
            '    tb_district_name.DataSourceID = Nothing
            '    tb_district_name.DataSource = RetrieveDataTable("SELECT distinct UPPER([district_zone_eng]) as district_zone_eng FROM [district_master] union select ''")
            '    tb_district_name.DataBind()
            '    Try
            '        tb_district_name.SelectedValue = Request("s4")
            '    Catch
            '    End Try

            'End If

            'mgids.Text = Session("mg_sid")

            'Chk_Filter()
        End If


    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            'If cfc.Check_Power(Session("stk_code").ToString(), Session("stk_desc").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub gv_delivery_schedule_PageIndexChanged(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        'Chk_Filter()
        lb_pageid.Text = e.NewPageIndex()

    End Sub
    Protected Sub gv_sku_PageIndexChanged(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        'Chk_Filter()
        lb_pageid.Text = e.NewPageIndex()

    End Sub
    Protected Sub Btn_Set_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' 檢查查詢條件是否改變 
        ' Chk_Filter()
    End Sub

    ' 檢查查詢條件是否改變 
    'Private Sub Chk_Filter()
    '    Dim cfc As New Common_Func()

    '    Dim ckint As Integer = 0
    '    Dim tmpstr As String = ""

    '    Dim strSearchCustNo = cfc.CleanSQL(txtCustNo.Text.Trim)
    '    Dim strSearchName = cfc.CleanSQL(tb_customer_code.Text.Trim)
    '    Dim strSearchGroup = cfc.CleanSQL(tb_company_code.SelectedValue.Trim)
    '    Dim strSearchDistrict = cfc.CleanSQL(tb_district_name.SelectedValue.Trim)
    '    Dim strSearchActive = tb_active.SelectedValue.Trim

    '    Dim strSql As String = " select [storeNo],[storeName] ,[tel],[storeAddress] ,[van], [storeCluster] ,[mg1] from [delivery_schedule]"

    '    'strSql += " where 1=1 "
    '    'If strSearchCustNo <> "" Then strSql += " and c.custNo like '%" & strSearchCustNo & "%'"
    '    'If strSearchName <> "" Then strSql += " and c.name1 like '%" & strSearchName & "%'"
    '    'If strSearchGroup <> "" Then strSql += " and g.name1 = '" & strSearchGroup & "'"
    '    'If strSearchDistrict <> "" Then strSql += " and c.city = '" & strSearchDistrict & "'"
    '    'If strSearchActive = "1" Then
    '    '    strSql += " and b.is_active = '" & strSearchActive & "'"
    '    'ElseIf strSearchActive = "0" Then
    '    '    strSql += " and b.is_active = '' "
    '    'End If


    '    dsdelivery.SelectCommand = strSql
    '    gv_delivery_schedule.DataBind()
    '    If gv_delivery_schedule.PageCount - 1 < gv_delivery_schedule.PageIndex Then
    '        gv_delivery_schedule.PageIndex = gv_delivery_schedule.PageCount
    '        gv_delivery_schedule.DataBind()
    '    End If

    '    lb_pageid.Text = gv_delivery_schedule.PageIndex.ToString()
    'End Sub

    Protected Sub gv_delivery_schedule_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs) Handles gv_delivery_schedule.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim btnView As Button = DirectCast(e.Row.FindControl("btnView"), Button)
            Dim strCustNo As String = e.Row.Cells(0).Text
            'btnView.ToolTip = strCustNo
        End If

    End Sub

    Public Sub btnView_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim strCustNo As String = CType(sender, Button).ToolTip

        'Dim strCustSearch As String = txtCustNo.Text
        'Dim strCustName As String = tb_customer_code.Text
        'Dim strCustGroup As String = tb_company_code.Text
        'Dim strDistrict As String = tb_district_name.Text

        'Response.Redirect(String.Format("2004_view.aspx?pageid={0}&mg_sid={1}&s1={2}&s2={3}&s3={4}&s4={5}", lb_pageid.Text, strCustNo, strCustSearch, strCustName, strCustGroup, strDistrict), False)
    End Sub

    'Protected Sub tb_company_code_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tb_company_code.SelectedIndexChanged
    '    'Chk_Filter()
    'End Sub

    'Protected Sub tb_district_name_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tb_district_name.SelectedIndexChanged
    '    'Chk_Filter()
    'End Sub



    Private Function RetrieveDataTable(ByVal strSQL As String) As DataTable
        Dim Sql_Conn1 As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim SqlString1 As String = strSQL


        Dim Sql_Command1 As New SqlCommand(SqlString1, Sql_Conn1)
        Sql_Conn1.Open()

        Dim dt As New DataTable

        Dim Sql_Reader1 As SqlDataReader = Sql_Command1.ExecuteReader()

        dt.Load(Sql_Reader1)

        Sql_Reader1.Close()
        Sql_Conn1.Close()


        Return dt
    End Function


    Protected Sub btnExport_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnExport.Click
        Try
            Dim dtCurrentRecord As New DataTable
            Dim dtCurrentRecord2 As New DataTable
            Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)

            Dim strSql As String = " select [CUSTGROUP], [PRODUCT_ID],[MATERIAL_NO],[CATEGORY],[DESC_C],[product_name] as NAME, [DESC_B]," & _
            " [SIZE],  [MG1_OTHERS],[MG1_LOW],[MG1_HIGH],[MG1_COMM],[out_cls1] as [OUTLET_CLASS1] ,[out_cls2] as [OUTLET_CLASS2] ,[out_cls3] as [OUTLET_CLASS3] ,[out_cls4] as [OUTLET_CLASS4] ,[out_cls5] as [OUTLET_CLASS5]  FROM [planogram_sku] "
            Dim strSql2 As String = " select [STORENO], [STORENAME], [TEL], [STOREADDRESS],[VAN], [STORECLUSTER],[MG1],[CUSTOMERNO] from [delivery_schedule] "

            Dim cmd As New SqlCommand(strSql, conn)
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            Dim da As New SqlDataAdapter(cmd)

            cmd.Connection.Open()
            da.Fill(dtCurrentRecord)
            cmd.Connection.Close()
            cmd.Dispose()
            da.Dispose()


            dtCurrentRecord.TableName = "ProductItemMG1"
            Dim strFileName As String = "ExcelExport_" + "_" + Format(TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))), "yyyyMMddhhmmss") + ".xls"
            Dim strNewPath As String = HttpContext.Current.Server.MapPath("~/ExcelExport/" & strFileName)
            Dim strPhysicalPath As String = HttpContext.Current.Server.MapPath("~/ExcelExport/" & strFileName)

            If Not IO.Directory.Exists(HttpContext.Current.Server.MapPath("~/ExcelExport")) Then
                IO.Directory.CreateDirectory(HttpContext.Current.Server.MapPath("~/ExcelExport"))
            End If

            Dim connectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & strNewPath & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=2"""
            InsertDBtoExcel(dtCurrentRecord, connectionString)

            Dim cmd2 As New SqlCommand(strSql2, conn)
            Dim da2 As New SqlDataAdapter(cmd2)
            cmd2.Connection.Open()
            da2.Fill(dtCurrentRecord2)
            cmd2.Connection.Close()
            cmd2.Dispose()
            da2.Dispose()
            dtCurrentRecord2.TableName = "StoreCluster"
            InsertDBtoExcel(dtCurrentRecord2, connectionString)


            HttpContext.Current.Response.Clear()
            Response.WriteFile(strNewPath)
            Dim httpHeader As String = "attachment;filename=" + "Planogram" + ".xls"
            HttpContext.Current.Response.ContentType = "application/vnd.ms-excel"
            HttpContext.Current.Response.AppendHeader("Content-Disposition", httpHeader)
            HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.Unicode


            HttpContext.Current.Response.Flush()
            System.IO.File.Delete(strNewPath)
            HttpContext.Current.Response.End()
        Catch ex As Exception
            Dim sMsg As String
            sMsg = ex.Message

            'Response.Write(ex.Message)
            ' Finally

        End Try


    End Sub


    Private Sub InsertDBtoExcel(ByVal dt As DataTable, ByVal connectionString As String)
        Dim strTable As String = ""
        Dim tName As String = ""
        If dt.TableName.IndexOf("sku", 0) > 0 Then
            tName = "sku"
        Else
            tName = dt.TableName
        End If
        strTable = "CREATE TABLE [" & tName & "]("

        Dim j As Integer = 0
        For j = 0 To dt.Columns.Count - 1
            Dim dCol As DataColumn
            dCol = dt.Columns(j)

            strTable &= " [" & dCol.ColumnName & "] nvarchar(255) , "


        Next
        strTable = strTable.Substring(0, strTable.Length - 2)
        strTable &= ")"

        Dim conn As OleDbConnection = New OleDbConnection(connectionString)
        Dim cmd As New OleDbCommand(strTable, conn)
        conn.Open()
        cmd.ExecuteNonQuery()
        conn.Close()
        cmd.Dispose()


        Dim strInsert As String
        strInsert = "Insert Into " & tName & " Values ("
        For k As Integer = 0 To dt.Columns.Count - 1
            strInsert &= "@" & dt.Columns(k).ColumnName & " , "
        Next
        strInsert = strInsert.Substring(0, strInsert.Length - 2)
        strInsert &= ")"

        conn.Open()
        For j = 0 To dt.Rows.Count - 1
            Dim cmd2 As New OleDbCommand(strInsert, conn)
            For k As Integer = 0 To dt.Columns.Count - 1

                cmd2.Parameters.AddWithValue("@" & dt.Columns(k).ColumnName.ToString(), dt.Rows(j)(k).ToString())

            Next

            cmd2.ExecuteNonQuery()
            cmd2.Parameters.Clear()
            cmd2.Dispose()
        Next
        conn.Close()
    End Sub


    Protected Sub btnUpload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpload.Click
        Dim connectionString As String = ""
        If FileUpload1.HasFile Then



            Dim fileName As String = Path.GetFileName(FileUpload1.PostedFile.FileName)
            Dim fileExtension As String = Path.GetExtension(FileUpload1.PostedFile.FileName)
            Dim fileLocation As String = Server.MapPath("~/ExcelExport/" & fileName)
            FileUpload1.SaveAs(fileLocation)
            If fileExtension = ".xls" Then
                connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=2"""
            ElseIf fileExtension = ".xlsx" Then
                connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 12.0;HDR=Yes;IMEX=2"""
            Else
                ClientScript.RegisterStartupScript(Me.GetType(), "errorScript", "alert('" & "Please select MS Excel file" & "');", True)
                Exit Sub
            End If

            gv_delivery_schedule.DataSource = Nothing





            Dim con As New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand()
            cmd.CommandType = System.Data.CommandType.Text
            cmd.Connection = con
            Dim dAdapter As New OleDbDataAdapter(cmd)
            Dim dtExcelRecords As New DataTable()
            Dim dtExcelRecords2 As New DataTable()
            Try
                con.Open()

                Dim dtExcelSheetName As DataTable = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)

                Dim getExcelSheetName As String = ""
                'Dim al As ArrayList = New ArrayList()
                'Dim i As Integer
                'Dim name As String = ""

                'For Each dd As DataRow In dtExcelSheetName.Rows

                '    getExcelSheetName = dd("TABLE_NAME").ToString
                '    i = getExcelSheetName.IndexOf("$", 0)
                '    If i > 0 Then
                '        If name <> getExcelSheetName.Substring(0, i).Trim Then
                '            name = getExcelSheetName.Substring(0, i).Trim
                '            al.Add(name)
                '        End If
                '    Else
                '        If name <> getExcelSheetName Then
                '            name = getExcelSheetName
                '            al.Add(getExcelSheetName)
                '        End If

                '    End If

                'Next
                'getExcelSheetName = al(1).ToString
                getExcelSheetName = "StoreCluster"

                'If dtExcelSheetName.Rows.Count > 1 Then
                '    getExcelSheetName = dtExcelSheetName.Rows(0)("Table_Name").ToString()
                'Else
                '    getExcelSheetName = "Sheet1$"
                'End If
                cmd.CommandText = "SELECT [storeno], [storeName], [tel], [storeAddress],[van], [storecluster],[mg1], [customerNo]  FROM [" & getExcelSheetName & "] "
                dAdapter.SelectCommand = cmd
                dAdapter.Fill(dtExcelRecords)
                con.Close()

                dtExcelRecords.Columns(0).ColumnName = "storeno"
                dtExcelRecords.Columns(1).ColumnName = "storeName"
                dtExcelRecords.Columns(2).ColumnName = "tel"
                dtExcelRecords.Columns(3).ColumnName = "storeAddress"
                dtExcelRecords.Columns(4).ColumnName = "van"
                dtExcelRecords.Columns(5).ColumnName = "storecluster"
                dtExcelRecords.Columns(6).ColumnName = "mg1"
                dtExcelRecords.Columns(7).ColumnName = "customerNo"


                If InsertExceltoDB(dtExcelRecords) = True Then
                    con.Open()
                    'Dim i As Integer
                    'Dim name As String = ""
                    'Dim al As ArrayList = New ArrayList()


                    'For Each dd As DataRow In dtExcelSheetName.Rows

                    '    getExcelSheetName = dd("TABLE_NAME").ToString
                    '    i = getExcelSheetName.IndexOf("$", 0)
                    '    If i > 0 Then
                    '        If name <> getExcelSheetName.Substring(0, i).Trim Then
                    '            name = getExcelSheetName.Substring(0, i).Trim
                    '            al.Add(name)
                    '        End If
                    '    Else
                    '        If name <> getExcelSheetName Then
                    '            name = getExcelSheetName
                    '            al.Add(getExcelSheetName)
                    '        End If

                    '    End If

                    'Next
                    'getExcelSheetName = al(0).ToString
                    getExcelSheetName = "ProductItemMG1"

                    cmd.CommandText = "SELECT [custGroup] ,[product_id], [category],[desc_c],[name], [desc_b], [size], [mg1_others],[mg1_low],[mg1_high]," & _
                        " [mg1_comm],[material_No], [Outlet_Class1] as [out_cls1] ,[Outlet_Class2] as [out_cls2],[Outlet_Class3] as [out_cls3],[Outlet_Class4] as [out_cls4],[Outlet_Class5] as [out_cls5] FROM [" & getExcelSheetName & "] "
                    dAdapter.SelectCommand = cmd
                    dAdapter.Fill(dtExcelRecords2)
                    con.Close()

                    dtExcelRecords2.Columns(0).ColumnName = "custGroup"
                    dtExcelRecords2.Columns(1).ColumnName = "product_id"
                    dtExcelRecords2.Columns(2).ColumnName = "category"
                    dtExcelRecords2.Columns(3).ColumnName = "desc_c"
                    dtExcelRecords2.Columns(4).ColumnName = "product_name"
                    dtExcelRecords2.Columns(5).ColumnName = "desc_b"
                    dtExcelRecords2.Columns(6).ColumnName = "size"
                    dtExcelRecords2.Columns(7).ColumnName = "mg1_others"
                    dtExcelRecords2.Columns(8).ColumnName = "mg1_low"
                    dtExcelRecords2.Columns(9).ColumnName = "mg1_high"
                    dtExcelRecords2.Columns(10).ColumnName = "mg1_comm"
                    dtExcelRecords2.Columns(11).ColumnName = "materialNo"
                    dtExcelRecords2.Columns(12).ColumnName = "out_cls1"
                    dtExcelRecords2.Columns(13).ColumnName = "out_cls2"
                    dtExcelRecords2.Columns(14).ColumnName = "out_cls3"
                    dtExcelRecords2.Columns(15).ColumnName = "out_cls4"
                    dtExcelRecords2.Columns(16).ColumnName = "out_cls5"


                    If InsertExceltoDB2(dtExcelRecords2) = True Then
                        If 1 = 1 Then
                            'Dim CustGp As String = ""
                            'Dim rows() As DataRow = dtExcelRecords2.Select("cust_gp <> '' ")
                            'If rows.Length > 0 Then
                            '    CustGp = rows(0).Item("cust_gp")
                            'End If


                            ' ddlCode.DataBind()
                            UpdateShopPDA()
                        End If
                        gv_delivery_schedule.DataBind()
                        gv_sku.DataBind()
                        ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Upload Completed');", True)
                    Else
                        ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Upload Failed. Please choose the right file');", True)
                    End If
                Else
                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Upload Failed. Please choose the right file !');", True)

                End If

            Catch ex As Exception
                Dim smsg As String = ex.Message

                ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Upload Failed. Please choose the right file');", True)

            End Try

        Else
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Please select an excel file');", True)
        End If
    End Sub

    Private Function UpdateShopPDA() As Boolean

        Dim isSucceed As Boolean = False
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim tran As SqlTransaction
        Dim da As New SqlDataAdapter
        Dim cmd As New SqlCommand()
        cmd.Connection = conn
        cmd.Connection.Open()
        tran = conn.BeginTransaction
        cmd.Transaction = tran
        Dim strSql As String
        Try
            'strSql = " update [customer_material_info_pda] set is_active = 0 where custNo in (select distinct Right('0000'+ customerNo,10) from delivery_schedule  )"
            'cmd = New SqlCommand(strSql, conn)
            'cmd.Transaction = tran
            'cmd.ExecuteNonQuery()

            'strSql = "update customer_material_info_pda set is_active = 1 where " & _
            '             " materialCode + custNo in (select distinct d.MaterialCode+c.cust_no from planogram_sku a , delivery_schedule b , " & _
            '             " cust_map c , customer_material_info d where cust_gp = 'Z-WELLCOME' and a.cust_gp = c.shop_no and b.storeNo = c.storeno" & _
            '             " and a.product_id = d.custmaterialCode " & _
            '             " and (  charindex('high', storeCluster) > 0  and b.mg1 >= a.mg1_high " & _
            '             " or charindex('low', storeCluster) > 0  and b.mg1 >= a.mg1_low " & _
            '             " or charindex('other', storeCluster) > 0  and b.mg1 >= a.mg1_others " & _
            '             " or charindex('comm', storeCluster) > 0  and b.mg1 >= a.mg1_comm ) )   "

            strSql = "update customer_material_info_pda set is_active = 0 where " & _
                        " materialCode+custNo in (select distinct a.Material_no+Right('0000'+b.customerNo,10)  " & _
                        "  from planogram_sku a , delivery_schedule b, customer_master c ,  customer_master d  where  " & _
                        "  a.custGroup = c.custNo and d.custGroup = c.custGroup and d.custNo =  Right('0000'+b.customerNo,10) and " & _
                        "  ( charindex('high', storeCluster) > 0  and b.mg1 >= a.mg1_high " & _
                        " or charindex('low', storeCluster) > 0  and b.mg1 >= a.mg1_low " & _
                        " or charindex('other', storeCluster) > 0  and b.mg1 >= a.mg1_others " & _
                        " or charindex('tourist', storeCluster) > 0  and b.mg1 >= a.mg1_comm " & _
                        " or charindex('comm', storeCluster) > 0  and b.mg1 >= a.mg1_comm " ' )   ) "

            strSql &= " or charindex('cls1', storeCluster) > 0  and b.mg1 >= a.out_cls1 " & _
                    " or charindex('cls2', storeCluster) > 0  and b.mg1 >= a.out_cls2 " & _
                    " or charindex('cls3', storeCluster) > 0  and b.mg1 >= a.out_cls3 " & _
                    " or charindex('cls4', storeCluster) > 0  and b.mg1 >= a.out_cls4 " & _
                    " or charindex('cls5', storeCluster) > 0  and b.mg1 >= a.out_cls5 ) ) "

            cmd = New SqlCommand(strSql, conn)

            cmd.CommandType = CommandType.Text
            cmd.Transaction = tran
            cmd.ExecuteNonQuery()
            tran.Commit()
            isSucceed = True
        Catch ex As Exception
            Dim smsg As String = ex.Message

            'tran.Rollback()
            isSucceed = False
        End Try

        cmd.Dispose()
        da.Dispose()
        conn.Dispose()
        Return isSucceed
    End Function


    Private Function InsertExceltoDB(ByVal dt As DataTable) As Boolean



        Dim isSucceed As Boolean = False
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim tran As SqlTransaction
        Dim da As New SqlDataAdapter
        Dim cmd As New SqlCommand()
        cmd.Connection = conn
        cmd.Connection.Open()
        tran = conn.BeginTransaction
        cmd.Transaction = tran
        Dim strSql As String
        Try
            strSql = " delete from [delivery_schedule] "
            cmd = New SqlCommand(strSql, conn)
            cmd.Transaction = tran
            cmd.ExecuteNonQuery()

            strSql = "Insert Into [delivery_schedule] ([storeNo], [storeName], [tel], [storeAddress],[van], [storecluster],[mg1],[customerNo] ) " & _
                         " values(@storeno, @storeName, @tel, @storeAddress, @van, @storeCluster, @mg1, @customerNo) "
            cmd = New SqlCommand(strSql, conn)

            cmd.CommandType = CommandType.Text
            cmd.Transaction = tran

            cmd.Parameters.Add("@storeno", SqlDbType.NVarChar, 500, "storeno")
            cmd.Parameters.Add("@storeName", SqlDbType.NVarChar, 500, "storeName")
            cmd.Parameters.Add("@tel", SqlDbType.NVarChar, 500, "tel")
            cmd.Parameters.Add("@storeAddress", SqlDbType.NVarChar, 500, "storeAddress")
            cmd.Parameters.Add("@van", SqlDbType.NVarChar, 500, "van")
            cmd.Parameters.Add("@storeCluster", SqlDbType.NVarChar, 500, "storeCluster")
            cmd.Parameters.Add("@mg1", SqlDbType.NVarChar, 1, "mg1")
            cmd.Parameters.Add("@customerNo", SqlDbType.NVarChar, 500, "customerNo")

            For Each dr As DataRow In dt.Rows
                dr.SetAdded()
            Next

            da.InsertCommand = cmd
            da.Update(dt)

            tran.Commit()
            isSucceed = True
        Catch ex As Exception
            Dim smsg As String = ex.Message

            tran.Rollback()
            isSucceed = False
        End Try

        cmd.Dispose()
        da.Dispose()
        conn.Dispose()
        Return isSucceed
    End Function


    Private Function InsertExceltoDB2(ByVal dt As DataTable) As Boolean

        Dim isSucceed As Boolean = False
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim tran As SqlTransaction
        Dim da As New SqlDataAdapter
        Dim cmd As New SqlCommand()
        cmd.Connection = conn
        cmd.Connection.Open()
        tran = conn.BeginTransaction
        cmd.Transaction = tran
        Dim strSql As String
        Try
            strSql = " delete from [planogram_sku] "
            cmd = New SqlCommand(strSql, conn)
            cmd.Transaction = tran
            cmd.ExecuteNonQuery()

            strSql = "Insert Into [planogram_sku] ([product_id],[category],[desc_c],[product_name], [desc_b], [size], [mg1_others],[mg1_low],[mg1_high],[mg1_comm]," & _
                         " [out_cls1], [out_cls2], [out_cls3], [out_cls4], [out_cls5], [material_No],[custGroup]) " & _
                         " values(@product_id,@category,@desc_c,@product_name, @desc_b, @size, @mg1_others,@mg1_low,@mg1_high,@mg1_comm," & _
                         " @out_cls1, @out_cls2, @out_cls3, @out_cls4, @out_cls5, @materialNo,@custgroup) "
            cmd = New SqlCommand(strSql, conn)

            cmd.CommandType = CommandType.Text
            cmd.Transaction = tran
            cmd.Parameters.Add("@product_id", SqlDbType.NVarChar, 500, "product_id")
            cmd.Parameters.Add("@category", SqlDbType.NVarChar, 500, "category")
            cmd.Parameters.Add("@desc_c", SqlDbType.NVarChar, 500, "desc_c")
            cmd.Parameters.Add("@product_name", SqlDbType.NVarChar, 500, "product_name")
            cmd.Parameters.Add("@desc_b", SqlDbType.NVarChar, 500, "desc_b")
            cmd.Parameters.Add("@size", SqlDbType.NVarChar, 500, "size")
            cmd.Parameters.Add("@mg1_others", SqlDbType.NVarChar, 500, "mg1_others")
            cmd.Parameters.Add("@mg1_low", SqlDbType.NVarChar, 1, "mg1_low")
            cmd.Parameters.Add("@mg1_high", SqlDbType.NVarChar, 1, "mg1_high")
            cmd.Parameters.Add("@mg1_comm", SqlDbType.NVarChar, 1, "mg1_comm")
            cmd.Parameters.Add("@materialNo", SqlDbType.NVarChar, 20, "materialNo")
            cmd.Parameters.Add("@custgroup", SqlDbType.NVarChar, 20, "custGroup")
            cmd.Parameters.Add("@out_cls1", SqlDbType.NVarChar, 1, "out_cls1")
            cmd.Parameters.Add("@out_cls2", SqlDbType.NVarChar, 1, "out_cls2")
            cmd.Parameters.Add("@out_cls3", SqlDbType.NVarChar, 1, "out_cls3")
            cmd.Parameters.Add("@out_cls4", SqlDbType.NVarChar, 1, "out_cls4")
            cmd.Parameters.Add("@out_cls5", SqlDbType.NVarChar, 1, "out_cls5")


            For Each dr As DataRow In dt.Rows
                dr.SetAdded()
            Next
            da.InsertCommand = cmd
            da.Update(dt)

            tran.Commit()
            isSucceed = True
        Catch ex As Exception
            Dim smsg As String = ex.Message

            tran.Rollback()
            isSucceed = False
        End Try

        cmd.Dispose()
        da.Dispose()
        conn.Dispose()
        Return isSucceed
    End Function

End Class
