﻿'********************************************
' Program Name      : 6044.aspx.vb
' Function          : Customer EDI PO Report 
' Author  Name      : Edwin Lam
' Creation Date     : 10-08-2023
' Last Modify Date  : 
'********************************************

Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration
Imports System.Data.Common

Partial Class _6044_6044
    Inherits System.Web.UI.Page
    Dim gErr As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim tmpstr As String = ""

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("6044", True)
            mg_name.Value = Session("mg_name").ToString
            tb_fr_date.Text = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))).ToString("yyyy/MM/dd")
            tb_to_date.Text = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))).ToString("yyyy/MM/dd")
        End If

        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""
        showData()
    End Sub

    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub


    Private Sub showData()

        Dim strSql As String = ""

        strSql &= " SELECT   distinct van_id, d.PO_no,  h.ship_date, d.custNo, c.name1, d.seqno, d.materialCode, d.custMaterialCode, i.engDesc, d.quantity, "
        strSql &= " d.assignedPrice, d.netPrice, d.grossPrice, d.barcode, d.assignedPrice - d.netPrice as [Difference] "
        strSql &= " FROM  rush_order_header   h "
        strSql &= " inner JOIN rush_order_detail d ON h.refDocNo = d.refDocNo AND h.PO_no = d.PO_no"
        strSql &= " inner JOIN customer_master c ON c.custNo = h.custNo "
        strSql &= " inner JOIN item_master i ON i.materialCode = d.materialCode "
        strSql &= " WHERE d.assignedPrice <> d.netPrice "
        strSql &= " and convert(varchar(10),h.ship_date,111) >= '" & tb_fr_date.Text & "' and convert(varchar(10),h.ship_date,111)  <= '" & tb_to_date.Text & "'"
        If tb_show.SelectedValue = 1 Then
            strSql &= " and   d.assignedPrice <> d.netPrice "
        End If
        If txtCustNo.Text <> "" Then
            strSql &= " and d.custNo = '" & txtCustNo.Text & "'"
        End If
        If txtPoNo.Text <> "" Then
            strSql &= " and d.PO_no = '" & txtPoNo.Text & "'"
        End If
        SqlMainSource.SelectCommand = strSql
        gv_txn_detail.DataBind()
    End Sub
End Class
