﻿'*************************************************************************
' Program Name      : 6043.aspx.vb
' Function          : Return Transaction Report
'                   : IEP-SD-VA01_ZRET_Sales_Order Report
' Author  Name      : Edwin Lam
' Creation Date     : 09-08-2023
' Last Modify Date  : 
'*************************************************************************

Imports System.Data
Imports Common_Func
Imports System
Imports System.Collections.Generic
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports System.IO

Partial Class _6043_6043
    Inherits System.Web.UI.Page
    Dim gErr As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("6043", True)

        End If

        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""
    End Sub

    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        Dim cfc As New Common_Func()
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub btn_Search_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Search.Click
        Dim strSql As String = getStrSql()
        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()
    End Sub

    Protected Sub gv_custmaster_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gv_custmaster.PageIndexChanging
        Dim strSql As String = getStrSql()
        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()
    End Sub

    Protected Sub gv_custmaster_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gv_custmaster.Sorting
        Dim strSql As String = getStrSql()
        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()
    End Sub

    Private Function getStrSql() As String
        Dim strVanId As String = Me.ddlVanID.Text.Trim
        Dim strRefDocNo As String = Me.txtRefDocNo.Text.Trim
        Dim strDateFrom As String = Me.txtDateFrom.Text
        Dim strDateTo As String = Me.txtDateTo.Text
        Dim strCustGroup As String = Me.ddlCustomerGroup.Text.Trim
        Dim strCustomer As String = Me.ddlCustomer.Text.Trim
        Dim strMaterialGroup As String = ""
        Dim strSql As String = "select rh.txn_type, rh.refDocNo, rh.van_id, rh.cr_date, rh.custNo, c.name1, rd.materialCode, i.chiDesc, "
        strSql += "g.chiDesc as ItemGroup, rd.quantity, rh.remark, rm.engDesc as reasonEng, rm.chiDesc as reasonChi, rh.PO_no from txn_return_header rh with (nolock) "
        strSql += "inner join txn_return_detail rd on rh.refDocNo = rd.refDocNo "
        strSql += "inner join customer_master c on rh.custNo = c.custNo inner join item_master i on rd.materialCode = i.materialCode "
        strSql += "inner join item_group_master g on g.materialGroupCode = i.materialGroupCode inner join customer_group_master cg on c.custGroup = cg.custGroup "
        strSql += "Left join reason_master rm on rm.reasonCode = rh.remark "
        strSql += "where 1=1  "

        If strVanId <> "" Then
            strSql += " and right(rh.van_id,3) = '" & Right(strVanId, 3) & "'"
        End If

        If strRefDocNo <> "" Then
            strSql += " and rh.refDocNo like '%" & strRefDocNo & "%'"
        End If

        If strDateFrom <> "" Then
            strSql += " and convert(varchar(10),rh.cr_date,111) >= '" & strDateFrom & "'"
        End If

        If strDateTo <> "" Then
            strSql += " and convert(varchar(10),rh.cr_date,111) <= '" & strDateTo & "'"
        End If

        If strCustomer <> "" Then
            strSql += " and c.name1 = '" & strCustomer & "'"
        End If

        If strCustGroup <> "" Then
            strSql += " and cg.name1 = '" & strCustGroup & "'"
        End If

        strSql += " Order By rh.van_id, rh.refDocNo"
        Return strSql
    End Function

    Protected Sub ddlCustomerGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCustomerGroup.SelectedIndexChanged
        Dim strCustomerGroup As String = Me.ddlCustomerGroup.Text.Trim
        BindCustomer(strCustomerGroup)
    End Sub

    Private Sub BindCustomer(ByVal strCustomerGroup As String)

        Dim strSql As String = "select distinct c.name1 from customer_master c inner join customer_group_master g on g.custGroup = c.custGroup where 1=1"
        If (strCustomerGroup) <> "" Then
            strSql += " and g.Name1 = '" & strCustomerGroup.Replace("'", "''") & "'"
        End If
        strSql += " union select '' order by name1"
        dsCustomer.SelectCommand = strSql
        ddlCustomer.DataBind()

    End Sub


End Class
