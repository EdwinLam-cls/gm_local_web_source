﻿'********************************************************
' Program Name      : 6037.aspx.vb
' Function          : EDI Price Report 
' Author  Name      : Chris Ho
' Creation Date     : 
' Last Modify By    : Edwin Lam
' Last Modify Date  : 10-08-2023
'********************************************************

Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration
Imports System.Data.Common

Partial Class _6037_6037
    Inherits System.Web.UI.Page
    Dim gErr As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim tmpstr As String = ""

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("6037", True)
            mg_name.Value = Session("mg_name").ToString
            tb_fr_date.Text = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))).ToString("yyyy/MM/dd")
            tb_to_date.Text = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))).ToString("yyyy/MM/dd")
        End If

        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""
        showData()
    End Sub

    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub


    Private Sub showData()

        '20230718 Edwin Lam (included ship_date)
        Dim strSql As String = ""

        strSql &= " SELECT   distinct d.PO_no, h.ship_date, d.custNo, c.name1, d.materialCode, d.custMaterialCode, i.engDesc, d.quantity, "
        strSql &= " d.assignedPrice, d.netPrice, d.grossPrice, d.barcode, d.assignedPrice - d.netPrice as [Difference] "
        strSql &= " FROM  rush_order_header   h "
        strSql &= " Left JOIN rush_order_detail d ON h.refDocNo = d.refDocNo AND h.PO_no = d.PO_no"
        strSql &= " Left JOIN customer_master c ON c.custNo = h.custNo "
        strSql &= " Left JOIN item_master i ON i.materialCode = d.materialCode "
        strSql &= " WHERE convert(varchar(10),h.ship_date,111) >= '" & tb_fr_date.Text & "' and convert(varchar(10),h.ship_date,111)  <= '" & tb_to_date.Text & "'"
        SqlMainSource.SelectCommand = strSql
        gv_txn_detail.DataBind()
    End Sub
End Class
