﻿'---------------------------------------------------------------------------- 
'程式功能	Delivery Master Maintenance
'---------------------------------------------------------------------------- 
Imports System.Data.SqlClient
Imports System
Imports System.Collections.Generic
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO
Imports System.Data.OleDb
Imports System.Data
Imports System.Windows.Forms


Partial Class _2020_2020
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()

            ' 檢查使用者權限並存入登入紀錄。 
            Check_Power("2020", True)

            '接受下一頁返回時的舊查詢條件" 
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid"), ckint) Then
                    gv_delivery_master.PageIndex = ckint
                Else
                    lb_pageid.Text = "0"
                End If
            End If

            txtImportDate.Text = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))).ToString("yyyy/MM/dd")
            txtExportDate.Text = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))).ToString("yyyy/MM/dd")
        End If


    End Sub
    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            'If cfc.Check_Power(Session("stk_code").ToString(), Session("stk_desc").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub gv_txn_detail_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gv_delivery_master.PageIndexChanging
        gv_delivery_master.PageIndex = e.NewPageIndex
        gv_delivery_master.DataSource = ViewState("myDataTable")
        gv_delivery_master.DataBind()


    End Sub

    Protected Sub gv_txn_detail_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gv_delivery_master.Sorting
        Dim dt As DataTable = ViewState("myDataTable")
        Dim dv As DataView = dt.DefaultView
        dv.Sort = e.SortExpression + " " + ConvertSortDirectionToSql(e.SortDirection)
        gv_delivery_master.DataSource = dv
        ViewState("myDataTable") = dv.ToTable
        gv_delivery_master.DataBind()

    End Sub

    Private Function ConvertSortDirectionToSql(ByVal sortDirect As SortDirection) As String

        If ViewState("orderBy") = "ASC" Then
            ViewState("orderBy") = "DESC"
            Return "DESC"
        Else
            ViewState("orderBy") = "ASC"
            Return "ASC"
        End If
        Return 0
    End Function

    Protected Sub Btn_Set_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Btn_Set.Click
        ' 檢查查詢條件是否改變 

        Chk_Filter()
       
    End Sub

    Private Sub Chk_Filter()
        Dim cfc As New Common_Func()

        Dim ckint As Integer = 0
        Dim tmpstr As String = ""


        Dim strSql As String = "select workDate, i.materialCode, i.engDesc, k281,k282,k283,k284,k285,k286,k287,k288,k289,k290,k296,k297,update_date, update_by"
        strSql += " from replenishment r inner join item_master i on r.materialCode = i.materialCode where 1 =1"
        strSql += " and workDate = '" & txtExportDate.Text & "'"

        If ddlReplen.SelectedItem.Text.Trim <> "" Then
            strSql += " and NoOfReplenish = '" & ddlReplen.Text & "' "
        End If


        Dim dtCurrentRecord As New DataTable
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)

        Dim cmd As New SqlCommand(strSql, conn)
        cmd.Connection = conn
        cmd.CommandType = CommandType.Text
        Dim da As New SqlDataAdapter(cmd)
        cmd.Connection.Open()
        da.Fill(dtCurrentRecord)
        cmd.Connection.Close()
        cmd.Dispose()
        da.Dispose()

        gv_delivery_master.DataSource = dtCurrentRecord
        ViewState("myDataTable") = dtCurrentRecord

        gv_delivery_master.DataBind()

        If gv_delivery_master.PageCount - 1 < gv_delivery_master.PageIndex Then
            gv_delivery_master.PageIndex = gv_delivery_master.PageCount
            gv_delivery_master.DataBind()
        End If

        lb_pageid.Text = gv_delivery_master.PageIndex.ToString()
    End Sub

    Protected Sub btnUpload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpload.Click
        Dim connectionString As String = ""
        Dim errMsg As String = ""
        If FileUpload1.HasFile Then
            Try
                Dim dtm As DateTime = CDate(txtImportDate.Text)
            Catch
                errMsg = "Invalid Date Format!"
            End Try


            Dim dToday As Date = Today
            Dim iDiff As Integer = 0
            iDiff = DateDiff(DateInterval.Day, dToday, Convert.ToDateTime(txtImportDate.Text))
            If (iDiff > 0 And iDiff <= 7) Then

            Else
                ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Import Date can only within Future 7 days');", True)
                Exit Sub
            End If



            Dim fileName As String = Path.GetFileName(FileUpload1.PostedFile.FileName)
            Dim fileExtension As String = Path.GetExtension(FileUpload1.PostedFile.FileName)
            Dim fileLocation As String = Server.MapPath("~/ExcelExport/" & fileName)
            FileUpload1.SaveAs(fileLocation)
            If fileExtension = ".xls" Then
                connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text"""
                connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 12.0;HDR=Yes"""

            ElseIf fileExtension = ".xlsx" Then
                connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 12.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text"";"
                connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 12.0 xml;HDR=Yes"""

            Else
                ClientScript.RegisterStartupScript(Me.GetType(), "errorScript", "alert('" & "Please select MS Excel file" & "');", True)
                Exit Sub
            End If

            gv_delivery_master.DataSource = Nothing

            Dim con As New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand()
            cmd.CommandType = System.Data.CommandType.Text
            cmd.Connection = con
            Dim dAdapter As New OleDbDataAdapter(cmd)
            Dim dtExcelRecords As New DataTable()
            Try

                con.Open()
                Dim dtExcelSheetName As DataTable = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)
                Dim getExcelSheetName As String = ""
                If dtExcelSheetName.Rows.Count > 1 Then
                    getExcelSheetName = dtExcelSheetName.Rows(1)("Table_Name").ToString()
                Else
                    getExcelSheetName = "Sheet1$"
                End If

                cmd.CommandText = "SELECT * , ' ' as NoOfReplenish FROM [" & getExcelSheetName & "] where materialCode is not null and materialCode not like '%3rd Item%' "
                dAdapter.SelectCommand = cmd
                dAdapter.Fill(dtExcelRecords)
                con.Close()
                File.Delete(fileLocation)
                If InsertExceltoDB(dtExcelRecords) = True Then
                    'gv_delivery_master.DataBind()
                    SyncPda()
                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Upload Completed');", True)
                Else
                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Upload Failed. Please choose the right file');", True)
                End If

            Catch ex As Exception
                ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('" & ex.Message.Replace("'", "''") & "');", True)
            End Try

        Else
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Please select an excel file');", True)
        End If


    End Sub

    Private Function SyncPda()
        Try

            Using Sql_Conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                Using Sql_Command As New SqlCommand()



                    Sql_Command.Connection = Sql_Conn
                    Sql_Conn.Open()

                    Sql_Command.CommandType = CommandType.StoredProcedure
                    Sql_Command.CommandText = "rpt_Getrepl"
                    Sql_Command.Parameters.Add("@dateFrom", SqlDbType.VarChar, 100)
                    Sql_Command.Parameters.Add("@Replen", SqlDbType.VarChar, 1)
                    Sql_Command.Parameters("@dateFrom").Value = txtImportDate.Text
                    Sql_Command.Parameters("@Replen").Value = ddlUpReplen.SelectedItem.Text
                    Sql_Command.ExecuteNonQuery()
                End Using
            End Using

        Catch ex As Exception
            Dim smsg As String
            smsg = ex.Message
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('" & ex.Message.Replace("'", "''") & "');", True)
        End Try


       

    End Function


    Private Function InsertExceltoDB(ByVal dt As DataTable) As Boolean
        Dim iNoOfReplenish As Integer = ddlUpReplen.SelectedValue
        'dt.Columns(0).ColumnName = "materialCode"
        'dt.Columns(1).ColumnName = "engDesc"
        'dt.Columns(2).ColumnName = "k281"
        'dt.Columns(3).ColumnName = "k282"
        'dt.Columns(4).ColumnName = "k283"
        'dt.Columns(5).ColumnName = "k284"
        'dt.Columns(6).ColumnName = "k285"
        'dt.Columns(7).ColumnName = "k286"
        'dt.Columns(8).ColumnName = "k287"
        'dt.Columns(9).ColumnName = "k288"
        'dt.Columns(10).ColumnName = "k289"
        'dt.Columns(11).ColumnName = "k290"
        'dt.Columns(12).ColumnName = "k296"
        'dt.Columns(13).ColumnName = "k297"

        Dim isSucceed As Boolean = False
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim tran As SqlTransaction
        Dim da As New SqlDataAdapter
        Dim cmd As New SqlCommand()
        cmd.Connection = conn
        cmd.Connection.Open()
        tran = conn.BeginTransaction
        cmd.Transaction = tran
        Dim strSql As String
        Try
            'strSql = " update gm_route set is_active = 0"
            'cmd = New SqlCommand(strSql, conn)
            'cmd.Transaction = tran
            'cmd.ExecuteNonQuery()
            strSql = " declare @a int "
            strSql &= " set @a = (select count(workDate) from replenishment where workDate =@workDate and materialCode = @materialCode and NoOfReplenish = @NoOfReplenish ) "
            strSql &= " if @a = 0  insert into replenishment(workDate, materialCode, k281,k282,k283,k284,k285,k286,k287,k288,k289,k290,k296,k297,update_date, update_by, NoOfReplenish)"
            strSql &= " values(@workDate, @materialCode, @k281,@k282,@k283,@k284,@k285,@k286,@k287,@k288,@k289,@k290,@k296,@k297,@update_date, @update_by, @NoOfReplenish)"
            strSql &= " else       update replenishment set k281 = @k281, k282 = @k282, k283 = @k283,k284 = @k284,k285 = @k285,k286 = @k286,k287 = @k287 "
            strSql &= " ,k288 = @k288,k289 = @k289,k290 = @k290,k296 = @k296,k297 = @k297, update_date = @update_date, update_by = @update_by  where workDate =@workDate and materialCode = @materialCode and NoOfReplenish = @NoOfReplenish "

            cmd = New SqlCommand(strSql, conn)

            cmd.CommandType = CommandType.Text
            cmd.Transaction = tran
            cmd.Parameters.Add("@workDate", SqlDbType.NVarChar, 10)
            cmd.Parameters("@workDate").Value = txtImportDate.Text.Trim
            cmd.Parameters.Add("@materialCode", SqlDbType.NVarChar, 1000, "materialCode")
            cmd.Parameters.Add("@k281", SqlDbType.Int, 50, "k281")
            cmd.Parameters.Add("@k282", SqlDbType.Int, 50, "k282")
            cmd.Parameters.Add("@k283", SqlDbType.Int, 50, "k283")
            cmd.Parameters.Add("@k284", SqlDbType.Int, 50, "k284")
            cmd.Parameters.Add("@k285", SqlDbType.Int, 50, "k285")
            cmd.Parameters.Add("@k286", SqlDbType.Int, 50, "k286")
            cmd.Parameters.Add("@k287", SqlDbType.Int, 50, "k287")
            cmd.Parameters.Add("@k288", SqlDbType.Int, 50, "k288")
            cmd.Parameters.Add("@k289", SqlDbType.Int, 50, "k289")
            cmd.Parameters.Add("@k290", SqlDbType.Int, 50, "k290")
            cmd.Parameters.Add("@k296", SqlDbType.Int, 50, "k296")
            cmd.Parameters.Add("@k297", SqlDbType.Int, 50, "k297")



            cmd.Parameters.Add("@update_date", SqlDbType.DateTime, 1000)
            cmd.Parameters("@update_date").Value = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID")))

            cmd.Parameters.Add("@update_by", SqlDbType.NVarChar, 1000)
            cmd.Parameters("@update_by").Value = Session("mg_name")

            cmd.Parameters.Add("@NoOfReplenish", SqlDbType.Int, 50)
            cmd.Parameters("@NoOfReplenish").Value = iNoOfReplenish

            For Each dr As DataRow In dt.Rows
                dr.SetAdded()
            Next
            da.InsertCommand = cmd
            da.Update(dt)


            'strSql = " update gm_route set is_active = 1, update_date =getdate(), updated_by ='" & Session("mg_name") & "' where is_active is null"
            'cmd = New SqlCommand(strSql, conn)
            'cmd.Transaction = tran
            'cmd.ExecuteNonQuery()

            tran.Commit()
            isSucceed = True
        Catch ex As Exception
            tran.Rollback()
            isSucceed = False
        End Try

        cmd.Dispose()
        da.Dispose()
        conn.Dispose()
        Return isSucceed
    End Function

    Protected Sub btnExport_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnExport.Click
        If Not hasDataOnDate(txtExportDate.Text) Then
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('No data on selected date');", True)
            Exit Sub
        End If

        Dim dtCurrentRecord As New DataTable
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)

        Dim strSql As String = "select g.chiDesc,  i.materialCode, i.engDesc, cast(k281 as varchar) as k281,cast(k282 as varchar) as k282,"
        strSql &= " cast(k283 as varchar) as k283,cast(k284 as varchar) as k284,cast(k285 as varchar) as k285,cast(k286 as varchar) as k286,"
        strSql &= " cast(k287 as varchar) as k287,cast(k288 as varchar) as k288,cast(k289 as varchar) as k289,cast(k290 as varchar) as k290,cast(k296 as varchar) as k296,cast(k297 as varchar) as k297,  cast (NoofReplenish as varchar) as NoofReplenish   "
        strSql &= " from replenishment r inner join item_master i on r.materialCode = i.materialCode"
        strSql &= " inner join item_group_master g on g.materialGroupCode = i.materialGroupCode  where 1 =1 and workDate = '" & txtExportDate.Text & "'"
        strSql &= " and NoOfReplenish = " & ddlReplen.SelectedItem.Text
        strSql &= " union (select distinct chiDesc,'00' + chiDesc ,chiDesc,'Qty','Qty','Qty','Qty','Qty','Qty','Qty','Qty','Qty','Qty','Qty','Qty','' from item_group_master)"
        strSql &= " order by g.chiDesc, i.materialCode asc"

        Dim cmd As New SqlCommand(strSql, conn)
        cmd.Connection = conn
        cmd.CommandType = CommandType.Text
        Dim da As New SqlDataAdapter(cmd)
        cmd.Connection.Open()
        da.Fill(dtCurrentRecord)
        cmd.Connection.Close()
        cmd.Dispose()
        da.Dispose()
        dtCurrentRecord.TableName = "rep"
        Dim strFileName As String = "ExcelExport_" + "_" + Format(TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))), "yyyyMMddhhmmss") + ".xls"
        Dim strNewPath As String = HttpContext.Current.Server.MapPath("~/ExcelExport/" & strFileName)
        Dim strPhysicalPath As String = HttpContext.Current.Server.MapPath("~/ExcelExport/" & strFileName)

        If Not IO.Directory.Exists(HttpContext.Current.Server.MapPath("~/ExcelExport")) Then
            IO.Directory.CreateDirectory(HttpContext.Current.Server.MapPath("~/ExcelExport"))
        End If

        Dim connectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & strNewPath & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=2"""
        connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & strNewPath & ";Extended Properties=""Excel 12.0 xml;Mode=ReadWrite;HDR=Yes"""

        dtCurrentRecord.Columns.Remove("chiDesc")
        dtCurrentRecord.AcceptChanges()
        InsertDBtoExcel_Version2(dtCurrentRecord, connectionString)

        HttpContext.Current.Response.Clear()
        Response.WriteFile(strNewPath)
        Dim httpHeader As String = "attachment;filename=" + "replenishment_" & TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))).ToString("yyyyMMdd") + ".xls"
        HttpContext.Current.Response.ContentType = "application/vnd.ms-excel"
        HttpContext.Current.Response.AppendHeader("Content-Disposition", httpHeader)
        HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.Unicode


        HttpContext.Current.Response.Flush()
        System.IO.File.Delete(strNewPath)
        HttpContext.Current.Response.End()



    End Sub

    Private Sub InsertDBtoExcel(ByVal dt As DataTable, ByVal connectionString As String)
        Try
            Dim strTable As String = ""
            strTable = "CREATE TABLE [" & dt.TableName & "]("

            Dim j As Integer = 0
            For j = 0 To dt.Columns.Count - 1
                Dim dCol As DataColumn
                dCol = dt.Columns(j)

                Dim strColName As String = dCol.ColumnName
                If strColName.StartsWith("k") Then

                    strTable &= " [" & dCol.ColumnName & "] int , "
                Else
                    strTable &= " [" & dCol.ColumnName & "] nvarchar(255) , "
                End If




            Next
            strTable = strTable.Substring(0, strTable.Length - 2)
            strTable &= ")"

            Dim conn As OleDbConnection = New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand(strTable, conn)
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            cmd.Dispose()


            Dim strInsert As String
            strInsert = "Insert Into " & dt.TableName & " Values ("
            For k As Integer = 0 To dt.Columns.Count - 1
                strInsert &= "@" & dt.Columns(k).ColumnName & " , "
            Next
            strInsert = strInsert.Substring(0, strInsert.Length - 2)
            strInsert &= ")"

            conn.Open()
            For j = 0 To dt.Rows.Count - 1
                Dim cmd2 As New OleDbCommand(strInsert, conn)
                For k As Integer = 0 To dt.Columns.Count - 1
                    Dim strName As String = dt.Columns(k).ColumnName

                    If strName.StartsWith("k") Then
                        If dt.Rows(j)(k).ToString() = "" Then
                            cmd2.Parameters.AddWithValue("@" & dt.Columns(k).ColumnName.ToString(), System.DBNull.Value)
                        Else
                            cmd2.Parameters.AddWithValue("@" & dt.Columns(k).ColumnName.ToString(), dt.Rows(j)(k).ToString())
                        End If


                    Else
                        cmd2.Parameters.AddWithValue("@" & dt.Columns(k).ColumnName.ToString(), dt.Rows(j)(k).ToString())
                    End If


                Next

                cmd2.ExecuteNonQuery()
                cmd2.Parameters.Clear()
                cmd2.Dispose()
            Next
            conn.Close()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub InsertDBtoExcel_Version2(ByVal dt As DataTable, ByVal connectionString As String)
        Try
            Dim strTable As String = ""
            strTable = "CREATE TABLE [" & dt.TableName & "]("

            Dim j As Integer = 0
            For j = 0 To dt.Columns.Count - 1
                Dim dCol As DataColumn
                dCol = dt.Columns(j)

                Dim strColName As String = dCol.ColumnName
                If strColName.StartsWith("k") Then

                    'strTable &= " [" & dCol.ColumnName & "] int , "
                    strTable &= " [" & dCol.ColumnName & "] nvarchar(255) , "
                Else
                    strTable &= " [" & dCol.ColumnName & "] nvarchar(255) , "
                End If




            Next
            strTable = strTable.Substring(0, strTable.Length - 2)
            strTable &= ")"

            Dim conn As OleDbConnection = New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand(strTable, conn)
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            cmd.Dispose()


            Dim strInsert As String
            strInsert = "Insert Into " & dt.TableName & " Values ("
            For k As Integer = 0 To dt.Columns.Count - 1
                strInsert &= "@" & dt.Columns(k).ColumnName & " , "
            Next
            strInsert = strInsert.Substring(0, strInsert.Length - 2)
            strInsert &= ")"

            conn.Open()
            For j = 0 To dt.Rows.Count - 1
                Dim cmd2 As New OleDbCommand(strInsert, conn)
                For k As Integer = 0 To dt.Columns.Count - 1
                    Dim strName As String = dt.Columns(k).ColumnName
                    Dim str As String = dt.Rows(j)(k).ToString()

                    If strName.StartsWith("k") Then
                        If str = "" Then
                            cmd2.Parameters.AddWithValue("@" & strName, System.DBNull.Value)
                        Else
                            cmd2.Parameters.AddWithValue("@" & strName, str)
                        End If


                    ElseIf strName = "materialCode" Then

                        If str.StartsWith("00") Then str = "3rd Item"
                        cmd2.Parameters.AddWithValue("@" & strName, str)
                    Else
                        cmd2.Parameters.AddWithValue("@" & strName, str)
                    End If


                Next

                cmd2.ExecuteNonQuery()
                cmd2.Parameters.Clear()
                cmd2.Dispose()
            Next
            conn.Close()
        Catch ex As Exception
        End Try
    End Sub

    Protected Sub btnTempExport_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnTempExport.Click

        Dim dtCurrentRecord As DataTable = RetrieveReplenishDT()


        dtCurrentRecord.TableName = "Replenishment"
        Dim strFileName As String = "ExcelExport_" + "_" + Format(TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))), "yyyyMMddhhmmss") + ".xls"
        Dim strNewPath As String = HttpContext.Current.Server.MapPath("~/ExcelExport/" & strFileName)
        Dim strPhysicalPath As String = HttpContext.Current.Server.MapPath("~/ExcelExport/" & strFileName)

        If Not IO.Directory.Exists(HttpContext.Current.Server.MapPath("~/ExcelExport")) Then
            IO.Directory.CreateDirectory(HttpContext.Current.Server.MapPath("~/ExcelExport"))
        End If

        Dim connectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & strNewPath & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=2"""
        connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & strNewPath & ";Extended Properties=""Excel 12.0 xml;Mode=ReadWrite;HDR=Yes"""

        InsertDBtoExcel_Version2(dtCurrentRecord, connectionString)

        HttpContext.Current.Response.Clear()
        Response.WriteFile(strNewPath)
        Dim httpHeader As String = "attachment;filename=" + "replenishment" + ".xlsx"
        HttpContext.Current.Response.ContentType = "application/vnd.ms-excel"
        HttpContext.Current.Response.AppendHeader("Content-Disposition", httpHeader)
        HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.Unicode


        HttpContext.Current.Response.Flush()
        System.IO.File.Delete(strNewPath)
        HttpContext.Current.Response.End()


    End Sub

    Private Function RetrieveVanCount(ByRef intStart As Integer) As Integer
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim result As Integer = 0
        Dim Sql_Command As New SqlCommand("select count(*) as cnt, min(vanCode) as intMin from business_unit", conn)
        conn.Open()
        Dim dr As SqlDataReader
        dr = Sql_Command.ExecuteReader
        Do While dr.Read()
            result = dr("cnt")
            intStart = CInt(Right(dr("intMin"), 3))
        Loop
        dr.Close()
        Sql_Command.Dispose()
        Return result
    End Function

    Private Function RetrieveVanCount_shippingpoint(ByRef intStart As Integer) As String
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim result As String = ""
        Dim Sql_Command As New SqlCommand("select shippingPoint from business_unit order by shippingPoint", conn)
        conn.Open()
        Dim dr As SqlDataReader
        dr = Sql_Command.ExecuteReader
        Do While dr.Read()
            result = result + dr("shippingpoint").ToString + ","
        Loop
        dr.Close()
        Sql_Command.Dispose()
        Return result
    End Function

    Private Function RetrieveDtByGroup(ByVal strGroupDesc As String) As DataTable
        Dim dtCurrentRecord As New DataTable
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)

        Dim strSql As String = "Select materialCode, i.engDesc "
        Dim intVanStart As Integer = 0
        Dim vanstring As String = RetrieveVanCount_shippingpoint(intVanStart)
        Dim strarr() As String
        strarr = vanstring.Split(",")
        For Each s As String In strarr
            If s <> "" Then
                strSql &= String.Format(" ,'Qty' as '{0}' ", s)
            End If
        Next
  

        'Dim intVanCnt As Integer = RetrieveVanCount(intVanStart)
        'For i = 0 To intVanCnt - 1
        ' strSql &= String.Format(" ,'Qty' as '{0}' ", "k" & intVanStart + i)
        ' Next

        strSql &= " from item_master i inner join item_group_master g on i.materialGroupCode = g.materialGroupCode where g.chiDesc ='" & strGroupDesc & "'"
        strSql = strSql.Replace("Qty", "") & " union " & strSql.Replace("materialCode", "'" & "00 3rd Item" & "'").Replace("i.engDesc", "'" & strGroupDesc & "' ")
        strSql &= " order by materialCode asc"

        Dim cmd As New SqlCommand(strSql, conn)
        cmd.Connection = conn
        cmd.CommandType = CommandType.Text
        Dim da As New SqlDataAdapter(cmd)
        cmd.Connection.Open()
        da.Fill(dtCurrentRecord)
        cmd.Connection.Close()
        cmd.Dispose()
        da.Dispose()

        Return dtCurrentRecord
    End Function

    Private Function RetrieveReplenishDT() As DataTable
        Dim dtGroup As DataTable = RetrieveDtGroup()
        Dim dtResult As New DataTable


        For i = 0 To dtGroup.Rows.Count - 1
            Dim strGroupDesc As String = dtGroup.Rows.Item(i)("chidesc")
            dtResult.Merge(RetrieveDtByGroup(strGroupDesc))
        Next


        Return dtResult
    End Function

    Private Function RetrieveDtGroup() As DataTable
        Dim dt As New DataTable
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim strSql As String = "Select distinct chiDesc from item_group_master order by chiDesc "
        Dim cmd As New SqlCommand(strSql, conn)
        cmd.Connection = conn
        cmd.CommandType = CommandType.Text
        Dim da As New SqlDataAdapter(cmd)
        cmd.Connection.Open()
        da.Fill(dt)
        cmd.Connection.Close()
        cmd.Dispose()
        da.Dispose()
        Return dt
    End Function

    Private Function hasDataOnDate(ByVal strDate As String) As Boolean
        Dim dtCurrentRecord As New DataTable
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)

        Dim strSql As String = "select workDate from replenishment where 1 =1 and workDate = '" & strDate & "'"


        Dim cmd As New SqlCommand(strSql, conn)
        cmd.Connection = conn
        cmd.CommandType = CommandType.Text
        cmd.Connection.Open()
        Dim dr As SqlDataReader
        dr = cmd.ExecuteReader()

        Dim result As Boolean = False

        If dr.Read() Then
            result = True
        End If


        Return result
    End Function


End Class
