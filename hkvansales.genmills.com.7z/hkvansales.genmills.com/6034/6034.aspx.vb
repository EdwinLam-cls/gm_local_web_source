﻿Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration
Imports System.Data.Common


Partial Class _6034_6034

    Inherits System.Web.UI.Page

    Dim gErr As String = ""


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim tmpstr As String = ""

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("6034", True)
            mg_name.Value = Session("mg_name").ToString
            tb_fr_date.Text = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))).AddDays(-30).ToString("yyyy/MM/dd")
            tb_to_date.Text = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))).AddDays(-1).ToString("yyyy/MM/dd")

        End If

        'Dim xVal() As String = {"1", "2", "3"}
        'Dim yval() As Double = {12, 34, 45}

        'Chart1.Series("Series1").Points.DataBindXY(xVal, yval)

        'System.Diagnostics.Debug.WriteLine(SqlMainSource.SelectCommand)

        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""

    End Sub


    ' Check_Power() 檢查使用者權限並存入登入紀錄
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub
    Protected Sub btn_search_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Chk_Filter()
    End Sub

    Private Sub Chk_Filter()



        Dim myDataTable As DataTable = New DataTable()
        'Dim myDataSet As New DataSet

        Dim Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Sql_conn.Open()

        Dim SqlString As String = "rpt_WriteOff"



        Dim Sql_Command As New SqlCommand(SqlString, Sql_conn)
        Sql_Command.CommandType = CommandType.StoredProcedure
        Sql_Command.Parameters.Add("@date", SqlDbType.DateTime, 100)
        Sql_Command.Parameters.Add("@txn_type", SqlDbType.NVarChar, 100)

        Sql_Command.Parameters("@date").Value = CDate(tb_fr_date.Text & "/01")
        Sql_Command.Parameters("@txn_type").Value = "Exchange"

        Dim reader As SqlDataReader = Sql_Command.ExecuteReader()

        myDataTable.Load(reader)
        myDataTable.TableName = "t"
        reader.Close()

        Sql_Command.Parameters("@txn_type").Value = "Sales"
        reader = Sql_Command.ExecuteReader()
        Dim dt As New DataTable
        dt.Load(reader)
        dt.TableName = "t2"
        myDataTable.Merge(dt)
        Sql_Command.Dispose()
        Sql_conn.Close()




        If myDataTable.Rows.Count = 2 And myDataTable.Columns.Count > 2 Then
            Dim dr As DataRow = dt.Rows(0)
            myDataTable.ImportRow(dr)
            myDataTable.Columns(0).ReadOnly = False
            myDataTable.Rows.Item(2)(0) = "Write-off %"

            For j = 2 To myDataTable.Columns.Count - 1
                myDataTable.Columns(j).ReadOnly = False
                Dim intUpper As Integer = myDataTable.Rows.Item(0)(j)
                Dim intLower As Integer = myDataTable.Rows.Item(1)(j)

                If intLower = 0 Then
                    myDataTable.Rows.Item(2)(j) = "0.00"
                Else
                    myDataTable.Rows.Item(2)(j) = Math.Round(intUpper * 100 / intLower, 2)
                End If

            Next
        End If
        myDataTable.AcceptChanges()

        Dim dtNew As DataTable = myDataTable.Clone
        For j = 0 To dtNew.Columns.Count - 1
            dtNew.Columns(j).DataType = GetType(String)
        Next

        For i = 0 To myDataTable.Rows.Count - 1
            Dim dtRow As DataRow = myDataTable.Rows(i)
            dtNew.ImportRow(dtRow)
        Next

        For j = 2 To myDataTable.Columns.Count - 1
            dtNew.Rows.Item(2)(j) = dtNew.Rows.Item(2)(j) & "%"
        Next



        ViewState("myDataTable") = dtNew

        gv_txn_detail.DataSource = dtNew
        gv_txn_detail.DataBind()
        If gv_txn_detail.PageCount - 1 < gv_txn_detail.PageIndex Then
            gv_txn_detail.PageIndex = gv_txn_detail.PageCount
            gv_txn_detail.DataBind()
        End If





    End Sub

    Protected Sub gv_txn_detail_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gv_txn_detail.Sorting
        Dim dt As DataTable = ViewState("myDataTable")
        Dim dv As DataView = dt.DefaultView
        dv.Sort = e.SortExpression + " " + ConvertSortDirectionToSql(e.SortDirection)
        gv_txn_detail.DataSource = dv
        ViewState("myDataTable") = dv.ToTable
        gv_txn_detail.DataBind()

    End Sub

    Private Function ConvertSortDirectionToSql(ByVal sortDirect As SortDirection) As String

        If ViewState("orderBy") = "ASC" Then
            ViewState("orderBy") = "DESC"
            Return "DESC"
        Else
            ViewState("orderBy") = "ASC"
            Return "ASC"
        End If
        Return 0
    End Function




    Protected Sub gv_txn_detail_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gv_txn_detail.PageIndexChanging
        gv_txn_detail.PageIndex = e.NewPageIndex
        gv_txn_detail.DataSource = ViewState("myDataTable")
        gv_txn_detail.DataBind()


    End Sub



End Class
