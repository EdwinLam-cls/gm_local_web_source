﻿'---------------------------------------------------------------------------- 
'程式功能	使用者登入紀錄查詢 
'備註說明	ObjectDataSource 傳參數的方式處理條件 
'---------------------------------------------------------------------------- 
Imports System
Imports System.Data
Imports System.Data.SqlClient

Partial Public Class _4001
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            ' 檢查使用者權限並存入登入紀錄 
            Check_Power("4001", True)
            tb_date.Text = Format(Date.Now, "yyyy/MM/dd")

            Try
                dsSale.SelectCommand = "select van_id,h.refDocNo,h.custNo,name2,d.materialCode,engDesc,chiDesc,Quantity from txn_header h left outer join txn_detail d on h.refDocNo = d.refDocNo inner join item_master i on i.materialCode = d.materialCode inner join customer_master c on h.custNo = c.custNo" & _
                   " WHERE isVoid <>1 "

                gv_txn_detail.DataBind()
            Catch
                lt_show.Text = "<script language=javascript>alert('「日期」輸入錯誤\n')</script>"
                Return
            End Try
         
        End If

    

        'Chk_Filter()

    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    ' 檢查查詢條件是否改變 
    Private Function getCriteriaSQL() As String

        Dim sqlQuery As String = ""

        'If tb_employee_name.Text.Trim <> "" Then
        '    sqlQuery &= " And h.user_id = '" & tb_employee_name.Text.Trim & "'"
        'End If

        'If tb_stk_code.Text.Trim <> "" Then
        '    sqlQuery &= " And  d.stk_code = '" & tb_stk_code.Text.Trim & "'"
        'End If

        'If ls_new.Text.ToUpper = "Y" Then
        '    sqlQuery &= " And isnull(d.cust_code,'') = ''"
        'ElseIf ls_new.Text.ToUpper = "N" Then
        '    sqlQuery &= " And isnull(d.cust_code,'') <> ''"
        'End If

        If (tb_date.Text <> "" AndAlso DateTime.Parse(tb_date.Text).Year <> 1900) Then
            sqlQuery &= " and convert(nvarchar, h.cr_date, 112) = convert(nvarchar, cast('" & tb_date.Text & "' as smalldatetime), 112) "
        End If

        Return sqlQuery
    End Function

    Protected Sub gv_txn_detail_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gv_txn_detail.PageIndexChanging
        Try
            'SqlMainSource.SelectCommand = SqlMainSource.SelectCommand & getCriteriaSQL()
            gv_txn_detail.DataBind()
        Catch
            lt_show.Text = "<script language=javascript>alert('「日期」輸入錯誤\n')</script>"
            Return
        End Try
    End Sub

    Protected Sub gv_txn_detail_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gv_txn_detail.Sorting
        Try
            ' SqlMainSource.SelectCommand = SqlMainSource.SelectCommand & getCriteriaSQL()
            gv_txn_detail.DataBind()
        Catch
            lt_show.Text = "<script language=javascript>alert('「日期」輸入錯誤\n')</script>"
            Return
        End Try
    End Sub

    Protected Sub btn_search_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_search.Click
        Try
            ' SqlMainSource.SelectCommand = SqlMainSource.SelectCommand & getCriteriaSQL()
            gv_txn_detail.DataBind()
        Catch
            lt_show.Text = "<script language=javascript>alert('「日期」輸入錯誤\n')</script>"
            Return
        End Try
    End Sub

    Public Function getTotalPrice() As String
        Return String.Empty
    End Function

    Public Function getTotalQty() As String
        Return String.Empty
    End Function

    Public Function getCust() As String
        Return String.Empty
    End Function

    Public Sub Chk_FILTER()
        Dim cfc As New Common_Func()
        Dim strMaterial = cfc.CleanSQL(ddlMaterial.Text.Trim)
        Dim strRefDocNo = cfc.CleanSQL(ddlRefDocNo.Text.Trim)
        Dim strVan = cfc.CleanSQL(ddlVan.Text.Trim)

        Dim strSql As String = "select van_id,h.refDocNo,h.custNo,name2,d.materialCode,engDesc,chiDesc,Quantity from txn_header h left outer join txn_detail d on h.refDocNo = d.refDocNo inner join item_master i on i.materialCode = d.materialCode inner join customer_master c on h.custNo = c.custNo"
        strSql += " WHERE isVoid <>1 "

        If strMaterial <> "" Then
            strSql += " and i.materialCode = '" & strMaterial & "'"
        End If
        If strRefDocNo <> "" Then
            strSql += " and h.refDocNo = '" & strRefDocNo & "'"
        End If
        If strVan <> "" Then
            strSql += " and van_id = '" & strVan & "'"
        End If
  


        dsSale.SelectCommand = strSql
        gv_txn_detail.DataBind()
    End Sub

    'Protected Sub ddlMaterialGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlMaterialGroup.SelectedIndexChanged
    '    Dim strGroup As String = ddlMaterialGroup.SelectedValue.Trim
    '    ddlMaterial.Items.Clear()
    '    If strGroup <> "" Then
    '        BindMaterial(strGroup)
    '    End If
    'End Sub

    'Private Sub BindMaterial(ByVal strGroup As String)
    '    ddlMaterial.DataSource = RetreiveMaterailDT(strGroup)
    '    Me.ddlMaterial.DataValueField = "chiDesc" 'Me.SessionDataTable.sidColumn.ColumnName
    '    Me.ddlMaterial.DataTextField = "chiDesc" 'Me.SessionDataTable.sidColumn.ColumnName
    '    Me.ddlMaterial.DataBind()
    'End Sub

    'Private Function RetreiveMaterailDT(ByVal strGroup As String) As DataTable
    '    'Dim dt As DataTable

    '    Dim dtSystem As New DataTable
    '    Dim conn As New SqlConnection(System.Web.Configuration.DBConnUtil.GetConnectionString().ConnectionString)
    '    Dim da As New SqlDataAdapter
    '    Dim cmd As New SqlCommand()
    '    cmd.Connection = conn
    '    cmd.Connection.Open()
    '    cmd = New SqlCommand("select a.chiDesc from item_group_master g left outer join item_master i on g.materialGroup = i.materialGroup where b.materialDescChi = '" & strGroup & "'", conn)
    '    cmd.CommandType = CommandType.Text
    '    da.SelectCommand = cmd
    '    da.Fill(dtSystem)


    '    Return dtSystem
    'End Function

    Protected Sub ddlVan_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlVan.SelectedIndexChanged
        Chk_FILTER()
    End Sub

    Protected Sub ddlMaterial_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlMaterial.SelectedIndexChanged
        Chk_FILTER()
    End Sub

    Protected Sub ddlRefDocNo_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlRefDocNo.SelectedIndexChanged
        Chk_FILTER()
    End Sub
End Class