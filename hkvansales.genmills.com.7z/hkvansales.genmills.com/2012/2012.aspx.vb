﻿'---------------------------------------------------------------------------- 
'程式功能	message > 修改資料 
'程式名稱	/2002/2011_edit.aspx.vb
'設計人員	
'修改人員 
'備註說明 
'---------------------------------------------------------------------------- 

Imports System
Imports System.Data.SqlClient
Imports System.Web.Configuration
Partial Class _2012_2012
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0, ab_sid As Integer = -1
            Dim mErr As String = "", SqlString As String = ""
            '            Dim stk_code As String
            ' 檢查使用者權限但不存入登入紀錄 
            Check_Power("2012", False)

            ' 承接上一頁的查詢條件設定
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid").ToString(), ckint) Then
                    lb_page.Text = "?pageid=" & ckint.ToString()
                Else
                    lb_page.Text = "?pageid=0"
                End If
            End If

            If mErr <> "" Then
                lt_show.Text = "<script language=javascript>alert(""" & mErr & """);history.go(-1);</script>"
            End If
        End If
    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub GV_deleting(ByVal sender As Object, ByVal e As GridViewDeleteEventArgs)
        Dim r As GridViewRow = gvMessage.Rows(e.RowIndex)
        Dim strMaterialCode As String = CType(r.FindControl("lblMaterialCode"), Label).Text

        dsListing.DeleteCommand = " delete from listing where materialCode = '" & strMaterialCode & "'"
        dsListing.Delete()
        dsListing.DataBind()
        Using Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
            Dim SqlString As String = ""
            SqlString = "  update customer_material_info_pda set is_active = 1 "
            SqlString += " update customer_material_info_pda set is_active = 0 from customer_group_master g inner join customer_material_info_pda p on g.custGroup = p.custGroup where block = 1 "
            SqlString += " update customer_material_info_pda set is_active = 0 where materialCode in(select distinct materialCode from listing)"
            SqlString += " update customer_material_info_pda set is_active = 1 from customer_material_info_pda p inner join listing l on l.custGroup =p.custGroup and l.materialCode = p.materialCode"

            Using Sql_Command As New SqlCommand()
                Sql_Command.Connection = Sql_conn
                Sql_Command.CommandText = SqlString
                Sql_conn.Open()
                Sql_Command.ExecuteNonQuery()
                Sql_conn.Close()
                Sql_Command.Dispose()
            End Using
        End Using


    End Sub



    Protected Sub btn_Search_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Search.Click
        Dim cfc As New Common_Func()

        Dim strMaterialCode As String = cfc.CleanSQL(txtMaterialCode.Text.Trim)
        Dim strChiDesc As String = cfc.CleanSQL(txtChiDesc.Text.Trim)
        Dim strCustGroupNo As String = cfc.CleanSQL(txtCustGroupNo.Text.Trim)
       

        Dim strSql As String = "select * from listing "
        strSql += " where 1=1 "
        If strMaterialCode <> "" Then strSql += " and materialCode like '%" & strMaterialCode & "%'"
        If strChiDesc <> "" Then strSql += " and chiDesc like '%" & strChiDesc & "%'"
        If strCustGroupNo <> "" Then strSql += " and custGroup like '%" & strCustGroupNo & "%'"


        dsListing.SelectCommand = strSql
        gvMessage.DataBind()




    End Sub



    Protected Sub gvMes_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs) Handles gvMessage.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim lb As LinkButton = DirectCast(e.Row.Cells(6).Controls(0), LinkButton)
            lb.OnClientClick = "return confirm('Confirm to delete record (Include all customer groups with this material)?')"
        End If

    End Sub
End Class
