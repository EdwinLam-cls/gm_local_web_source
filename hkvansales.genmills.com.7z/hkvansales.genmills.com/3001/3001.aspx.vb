﻿'---------------------------------------------------------------------------- 
'程式功能	message > 修改資料 
'程式名稱	/2002/2011_edit.aspx.vb
'設計人員	
'修改人員 
'備註說明 
'---------------------------------------------------------------------------- 

Imports System
Imports System.Data.SqlClient
Imports System.Web.Configuration
Partial Class _3001_3001
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0, ab_sid As Integer = -1
            Dim mErr As String = "", SqlString As String = ""
            '            Dim stk_code As String
            ' 檢查使用者權限但不存入登入紀錄 
            Check_Power("3001", False)

            ' 承接上一頁的查詢條件設定
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid").ToString(), ckint) Then
                    lb_page.Text = "?pageid=" & ckint.ToString()
                Else
                    lb_page.Text = "?pageid=0"
                End If
            End If

            If mErr <> "" Then
                lt_show.Text = "<script language=javascript>alert(""" & mErr & """);history.go(-1);</script>"
            End If
        End If
    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub GV_deleting(ByVal sender As Object, ByVal e As EventArgs)

        Dim strMsgid As String = CType(CType(sender, Button).Parent.FindControl("lblmsg_id"), Label).Text

        dsMessage.UpdateCommand = " update message_master set expired ='1' where msg_id = '" & strMsgid & "'"
        dsMessage.Update()

        gvMessage.DataBind()
    End Sub

    Protected Sub GV_deleting2(ByVal sender As Object, ByVal e As EventArgs)

        Dim strMsgid As String = CType(CType(sender, Button).Parent.FindControl("lblmsg_id2"), Label).Text

        dsVanMessage.UpdateCommand = " update message_master set expired ='1' where msg_id = '" & strMsgid & "'"
        dsVanMessage.Update()

        gvVanMessage.DataBind()
    End Sub

    Protected Sub btn_Search_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Search.Click
        Dim cfc As New Common_Func()

        Dim strSearchTo As String = ""
        Dim strSearchFrom As String = ""
        Try
            If tb_valid_from.Text.Trim = "" Then
                strSearchFrom = "1990-01-01"
            Else
                strSearchFrom = (CDate(tb_valid_from.Text.Trim).ToString("yyyy-MM-dd"))
            End If

        Catch
            ClientScript.RegisterStartupScript(Me.GetType(), "recScript", "alert('" & "Wrong Date!" & "');", True)
            Exit Sub
        End Try

        Try
            If tb_valid_from.Text.Trim = "" Then
                strSearchTo = "2099-12-31"
            Else
                strSearchTo = (CDate(tb_valid_to.Text.Trim).ToString("yyyy-MM-dd"))
            End If
        Catch
            ClientScript.RegisterStartupScript(Me.GetType(), "recScript", "alert('" & "Wrong Date!" & "');", True)
            Exit Sub
        End Try

        Dim strSql As String = "select * from message_master "
        strSql += " where type='m' and expired = 0 "
        strSql += " and convert(varchar(10),[creation_date],120) >= '" & strSearchFrom & "'"
        strSql += " and convert(varchar(10),[creation_date],120) <= '" & strSearchTo & "'"


        dsMessage.SelectCommand = strSql
        gvMessage.DataBind()
   


        strSql = "select * from message_master "
        strSql += " where type='v' and expired = 0 "
        strSql += " and convert(varchar(10),[creation_date],120) >= '" & strSearchFrom & "'"
        strSql += " and convert(varchar(10),[creation_date],120) <= '" & strSearchTo & "'"


        dsVanMessage.SelectCommand = strSql
        gvVanMessage.DataBind()



    End Sub

    Protected Sub gvVan_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs) Handles gvVanMessage.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim lb As Button = DirectCast(e.Row.Cells(6).Controls(1), Button)
            lb.OnClientClick = "return confirm('Confirm to delete record?')"
        End If

    End Sub

    Protected Sub gvMes_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs) Handles gvMessage.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim lb As Button = DirectCast(e.Row.Cells(6).Controls(1), Button)
            lb.OnClientClick = "return confirm('Confirm to delete record?')"
        End If

    End Sub
End Class
