﻿'---------------------------------------------------------------------------- 
'程式功能	District Master > 明細內容 > 新增資料
'---------------------------------------------------------------------------- 

Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration

Partial Class _3001_3001_add
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0

            ' 檢查使用者權限但不存入登入紀錄 
            Check_Power("2012", False)

            ' 承接上一頁的查詢條件設定
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid").ToString(), ckint) Then
                    lb_page.Text = "?pageid=" & ckint.ToString()
                Else
                    lb_page.Text = "?pageid=0"
                End If
            End If

            If Request("district_id") IsNot Nothing Then
                lb_page.Text &= "&district_id=" & Request("district_id")
            End If

        End If
    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub lb_ok_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim mErr As String = ""
        Dim mg_sid As Integer = -1

        ' 載入字串函數 
        Dim sfc As New String_Func()

        ' 載入公用函數 
        Dim cfc As New Common_Func()

        If Me.txtMessage.Text.Trim() = "" Then
            mErr &= "Please enter [Message]!\n"
        ElseIf cfc.CheckSQL(Me.txtMessage.Text.Trim()) Then
            mErr &= "[Message] should not contain special characters\n"
        End If

        Dim bolCheckVan As String = ""
        For Each item As ListItem In cblVan.Items
            If item.Selected = True Then
                bolCheckVan &= item.Value & ", "
            End If
        Next

        If bolCheckVan = "" Then
            mErr &= "Select at least one van\n"
        Else
            bolCheckVan = bolCheckVan.Substring(0, bolCheckVan.Length - 2)
        End If

        Dim strValidFrom As String = ""

        If Me.txtValidFrom.Text.Trim() = "" Then
            mErr &= "Please enter [Valid Period From] \n"
        Else
            Try
                strValidFrom = CDate(Me.txtValidFrom.Text).ToString("yyyy-MM-dd")
            Catch ex As Exception
                ClientScript.RegisterStartupScript(Me.GetType(), "recScript", "alert('" & "Wrong Date!" & "');", True)
                Exit Sub
            End Try
        End If

        Dim strValidTo As String = ""

        If Me.txtValidTo.Text.Trim() = "" Then
            mErr &= "Please enter [Valid Period To]\n"
        Else
            Try
                strValidTo = CDate(Me.txtValidTo.Text).ToString("yyyy-MM-dd")
            Catch ex As Exception
                ClientScript.RegisterStartupScript(Me.GetType(), "recScript", "alert('" & "Wrong Date!" & "');", True)
                Exit Sub
            End Try
        End If

        If DateDiff(DateInterval.Day, Convert.ToDateTime(strValidFrom), Convert.ToDateTime(strValidTo)) < 0 Then
            mErr &= "Valid Period To Date cannot earlier than Period From Date !\n"
        End If



        If mErr = "" Then
            Using Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                Dim SqlString As String = ""


                ' 建立 SQL 的語法 
                SqlString = "Insert Into message_master (message,vanCode, creation_date, valid_from, valid_to, type, expired, user_name)"
                SqlString &= " Values  (@message,@vanCode, @creation_date, @valid_from, @valid_to, @type, @expired, @user_name);"

                Dim strMessage As String = Me.txtMessage.Text.Trim
                Dim strMessageType As String = Me.ddlMessageType.SelectedValue.Substring(0, 1)
                If strMessageType = "m" Then
                    bolCheckVan = "All"
                End If
                Dim strVanIds As String = bolCheckVan
                Dim dtmCreateDate As DateTime = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID")))
                Dim dtmFrom As DateTime = CDate(strValidFrom)
                Dim dtmTo As DateTime = CDate(strValidTo)
                Dim intExpired As Integer = 0
                Dim strUserName As String = Session("mg_name")





                Using Sql_Command As New SqlCommand()
                    Sql_Command.Connection = Sql_conn
                    Sql_Command.CommandText = SqlString

                    ' 擷取字串到資料庫所規範的大小 sfc.Left(string mdata, int leng) 
                    Sql_Command.Parameters.AddWithValue("@message", strMessage)
                    Sql_Command.Parameters.AddWithValue("@VanCode", strVanIds)
                    Sql_Command.Parameters.AddWithValue("@creation_date", dtmCreateDate)
                    Sql_Command.Parameters.AddWithValue("@valid_from", dtmFrom)
                    Sql_Command.Parameters.AddWithValue("@valid_to", dtmTo)
                    Sql_Command.Parameters.AddWithValue("@type", strMessageType)
                    Sql_Command.Parameters.AddWithValue("@expired", intExpired)
                    Sql_Command.Parameters.AddWithValue("@user_name", strUserName)

                    Sql_conn.Open()

                    Sql_Command.ExecuteNonQuery()
                    Sql_Command.Dispose()

                    ' 取得新增資料的主鍵值 
                    mg_sid = 0
                End Using
            End Using
        End If


        If mErr = "" Then
            mErr = ("alert('Record saved successfully!\n');location.replace('3001.aspx" & lb_page.Text & "&sid=") + mg_sid.ToString() & "');"
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", mErr, True)
        Else
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('" & mErr & "')", True)
        End If


    End Sub


    Protected Sub ddlMessageType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlMessageType.SelectedIndexChanged
        If ddlMessageType.SelectedIndex = 0 Then
            For Each Items As ListItem In cblVan.Items
                Items.Selected = True
                Items.Enabled = False
            Next
        Else
            For Each Items As ListItem In cblVan.Items
                Items.Selected = False
                Items.Enabled = True
            Next
        End If
    End Sub
End Class
