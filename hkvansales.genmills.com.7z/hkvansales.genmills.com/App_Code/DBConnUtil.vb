﻿Imports System.Data.SqlClient
Imports System.Web
Imports System.Web.Configuration

Public Class DBConnUtil

    Public Shared Function GetSQLConn() As SQLConnection
        Return New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
    End Function

    Public Shared Function GetConnectionString() As System.Configuration.ConnectionStringSettings
        Dim conStrSetting As System.Configuration.ConnectionStringSettings

        Select Case Server.CurrentEnvironment.ToUpper()
            Case "DEVELOPER"
                conStrSetting = WebConfigurationManager.ConnectionStrings("Developer")
            Case "DEVELOPMENT"
                conStrSetting = WebConfigurationManager.ConnectionStrings("Development")
            Case "QA"
                conStrSetting = WebConfigurationManager.ConnectionStrings("QA")
            Case "PRODUCTION"
                conStrSetting = WebConfigurationManager.ConnectionStrings("Production")
            Case Else
                'This should ever happen, but just in case default to developer
                conStrSetting = WebConfigurationManager.ConnectionStrings("Developer")
        End Select

        Return conStrSetting

    End Function


    Public Shared ReadOnly Property ConnectionStringNotDefinedExceptionMessage As String
        Get
            Return String.Format("Web.Config 的 <connectionStrings> 區段中，要有一個名稱為 {0} 資料庫連接字串。", Server.CurrentEnvironment.ToUpper())
        End Get
    End Property
End Class
