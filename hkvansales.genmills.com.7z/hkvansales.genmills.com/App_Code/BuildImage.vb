﻿'---------------------------------------------------------------------------- 
'專案名稱	公用函數 
'程式功能	產生驗證圖形 
'設計人員	 
'修改人員 
'備註說明 
'---------------------------------------------------------------------------- 
Imports System
Imports System.Collections.Generic
Imports System.Web
Imports System.Drawing
Imports System.IO

Public Class BuildImage
	' GenerateImage 以圖檔產生驗證字圖形
	'函數功能: GenerateImage 以圖檔產生驗證文字圖形 
	'傳入參數: 
	' img_width 圖形寬度 
	' img_height 圖形高度 
	' confirm_str 驗證字串 
	'傳回數值: 
	' MemoryStream 圖形資料 
	'備註說明: 本範例僅有 0 ~ 9 的數字圖檔，故驗證字串僅可輸入 0 ~ 9 的數字 
	Public Function GenerateImage(ByVal img_width As Integer, ByVal img_height As Integer, ByVal confirm_str As String) As MemoryStream
		Dim wlen As Integer = 0, cnt As Integer = 0, tmpwidth As Integer, tmpheight As Integer
		Dim tmpfile As String = ""

		' 取得網站存放圖檔的位置 
		Dim gpath As String = HttpContext.Current.Request.MapPath("~/images/confirm/")
        If Now.Second > 30 Then
            gpath = HttpContext.Current.Request.MapPath("~/images/confirm/")
        Else
            gpath = HttpContext.Current.Request.MapPath("~/images/confirm1/")
        End If
		' 取得字串長度 
		wlen = confirm_str.Length

		' 建立圖片元件 
		Dim img_work As Bitmap = New System.Drawing.Bitmap(img_width, img_height)

		' 建立繪圖元件 
		Dim gh_work As Graphics = Graphics.FromImage(img_work)

		' 擷取字串內容對映的圖檔，並填入 img_work 圖形物件 
		For cnt = 0 To wlen - 1
			' 取得對映圖檔的名稱 
			tmpfile = gpath & confirm_str.Substring(cnt, 1) & ".gif"

			' 從檔案取得圖片物件 
			Using img_tmp As System.Drawing.Image = System.Drawing.Image.FromFile(tmpfile, True)
				tmpwidth = img_tmp.Width
				tmpheight = img_tmp.Height

				' 將圖形填入繪圖元件 
				gh_work.DrawImage(img_tmp, New Rectangle(cnt * tmpwidth, 0, tmpwidth, tmpheight), 0, 0, tmpwidth, tmpheight, _
				GraphicsUnit.Pixel)
			End Using
		Next

		' 建立繪圖輸出串流 
		Dim ms_work As New MemoryStream()

		'將圖片儲存到輸出串流 
		img_work.Save(ms_work, System.Drawing.Imaging.ImageFormat.Png)

		gh_work.Dispose()
		img_work.Dispose()

		Return ms_work
	End Function

	' GenerateWord 以系統字型產生驗證圖形
	'函數功能: GenerateWord 以系統字型產生驗證圖形 
	'傳入參數: 
	' img_width 圖形寬度 
	' img_height 圖形高度 
	' confirm_str 驗證字串 
	'傳回數值: 
	' MemoryStream 圖形資料 
	'備註說明: 
	Public Function GenerateWord(ByVal img_width As Integer, ByVal img_height As Integer, ByVal confirm_str As String) As MemoryStream
		Dim wlen As Integer = 0, cnt As Integer = 0, fcnt As Integer = 0, tmpwidth As Integer = 0, tmpheight1 As Integer = 0, tmpheight2 As Integer = 0
		Dim ft_work As Font
		Dim pn_work As Pen
		Dim cr_work As Color
		Dim bh_work As Brush
		Dim rnd As New Random()

		' 取得字串長度 
		wlen = confirm_str.Length

		' 分配每個字的寬度 
		tmpwidth = img_width / wlen

		' 建立圖片元件 
		Dim img_work As Bitmap = New System.Drawing.Bitmap(img_width, img_height)

		' 建立繪圖元件 
		Dim gh_work As Graphics = Graphics.FromImage(img_work)

		' 設定繪圖元件背景顏色 
		gh_work.Clear(Color.DarkGreen)

		' 以系統字體於 img_work 圖形物件繪製字型 
		For cnt = 0 To wlen - 1
			' 隨機取得顏色 
			Select Case rnd.Next(5)
				Case 0
					cr_work = Color.Yellow
					Exit Select
				Case 1
					cr_work = Color.White
					Exit Select
				Case 2
					cr_work = Color.Tomato
					Exit Select
				Case 3
					cr_work = Color.LightBlue
					Exit Select
				Case Else
					cr_work = Color.Lime
					Exit Select
			End Select

			' 設定字型筆刷的顏色 
			bh_work = New SolidBrush(cr_work)

			' 隨機設定 16 ~ 40 之間的字型大小 
			fcnt = rnd.Next(16, 41)

			ft_work = New Font("Arial", fcnt, FontStyle.Bold)

			gh_work.DrawString(confirm_str.Substring(cnt, 1), ft_work, bh_work, cnt * tmpwidth, 3)
		Next

		' 背景隨機畫6條線 
		For cnt = 0 To 5
			' 隨機取得顏色 
			Select Case rnd.Next(5)
				Case 0
					cr_work = Color.Blue
					Exit Select
				Case 1
					cr_work = Color.Orange
					Exit Select
				Case 2
					cr_work = Color.Red
					Exit Select
				Case 3
					cr_work = Color.Sienna
					Exit Select
				Case Else
					cr_work = Color.Pink
					Exit Select
			End Select

			' 隨機設定筆刷粗細 
			fcnt = rnd.Next(3)

			' 設定筆刷元件 
			pn_work = New Pen(cr_work, fcnt)

			tmpheight1 = rnd.Next(img_height)
			tmpheight2 = rnd.Next(img_height)
			gh_work.DrawLine(pn_work, 0, tmpheight1, img_width, tmpheight2)
		Next

		' 建立繪圖輸出串流 
		Dim ms_work As New MemoryStream()

		'將圖片儲存到輸出串流 
		img_work.Save(ms_work, System.Drawing.Imaging.ImageFormat.Png)

		gh_work.Dispose()
		img_work.Dispose()

		Return ms_work
	End Function
End Class
