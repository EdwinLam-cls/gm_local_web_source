﻿'---------------------------------------------------------------------------- 
'專案名稱	公用函數 
'程式功能	證件相關檢查 
'程式名稱	/App_Code/Check_ID.vb
'設計人員	
'修改人員	
'備註說明 
'---------------------------------------------------------------------------- 
Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Web

Public Class Check_ID
    Public Function Check_TW_ID(ByVal strID As String) As Integer
        Dim nFirst As String = ""
        Dim nTol As Integer = 0, nCount As Integer = 0, chk_value As Integer = 9, ckint As Integer = -1

        strID = strID.Trim()

        ' 確定台灣身分證號碼有10碼，最後一碼為檢查碼 
        If strID.Length = 10 Then
            nFirst = strID.Substring(2, 1)
            If nFirst = "1" OrElse nFirst = "2" Then
                If Integer.TryParse(strID.Substring(1, 9), ckint) Then
                    nFirst = strID.Substring(0, 1).ToUpper()
                    Select Case nFirst
                        Case "B", "N", "Z"
                            nTol = 0
                            Exit Select
                        Case "A", "M", "W"
                            nTol = 1
                            Exit Select
                        Case "K", "L", "Y"
                            nTol = 2
                            Exit Select
                        Case "J", "V", "X"
                            nTol = 3
                            Exit Select
                        Case "H", "U"
                            nTol = 4
                            Exit Select
                        Case "G", "T"
                            nTol = 5
                            Exit Select
                        Case "F", "S"
                            nTol = 6
                            Exit Select
                        Case "E", "R"
                            nTol = 7
                            Exit Select
                        Case "D", "O", "Q"
                            nTol = 8
                            Exit Select
                        Case "C", "I", "P"
                            nTol = 9
                            Exit Select
                        Case Else
                            nTol = 99
                            Exit Select
                    End Select

                    If nTol <> 99 Then
                        For nCount = 1 To 9
                            nTol += Integer.Parse(strID.Substring(nCount, 1)) * (9 - nCount)
                        Next

                        nTol += Integer.Parse(strID.Substring(9, 1))

                        If (nTol Mod 10) = 0 Then
                            chk_value = 0
                        Else
                            chk_value = 1
                        End If
                    Else
                        chk_value = 2
                    End If
                Else
                    chk_value = 4
                End If
            Else
                chk_value = 5
            End If
        Else
            chk_value = 3
        End If

        Return chk_value
    End Function

    Public Function Check_CN_ID(ByVal strID As String) As Integer
        Dim intIndex As Integer = 0, intSum As Integer = 0
        Dim ckint As Int64 = -1
        Dim ckdt As DateTime
        Dim intTotal As Integer() = New Integer(16) {}              ' 乘積 
        Dim intNumber As Integer() = New Integer(17) {}             ' 編碼 

        ' 權數 
        Dim intWeight As Integer() = New Integer(17) {7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2, 1}

        ' 相對值 
        Dim strTable As String() = New String(10) {"1", "0", "X", "9", "8", "7", "6", "5", "4", "3", "2"}

        Dim strCheck_Src As String = ""             ' 來自 strID 之檢驗碼 
        Dim strCheck_Dst As String = ""             ' 來算計算後之檢驗碼 
        Dim chk_value As Integer = 0

        chk_value = 9
        strID = strID.Trim().ToUpper()
        If strID.Length = 18 Then
            ' 確定第 1-17碼是數字。 
            If Int64.TryParse(strID.Substring(0, 16), ckint) Then
                strCheck_Src = strID.Substring(17, 1)

                intSum = 0

                ' Sum(Ai×Wi) 
                For intIndex = 0 To 16
                    intSum = intSum + Integer.Parse(strID.Substring(intIndex, 1)) * intWeight(intIndex)
                Next

                ' Sum(Ai×Wi) Mod 11 
                intSum = intSum Mod 11

                ' 查表，尋找其相對值 
                strCheck_Dst = strTable(intSum)

                ' 比較檢查碼與相對值是否相同。 
                If strCheck_Dst = strCheck_Src Then
                    chk_value = 0
                Else
                    chk_value = 1
                End If
            Else
                chk_value = 2
            End If
        Else
            If strID.Length = 15 Then
                ' 確定1-15碼均是數字。 
                If Int64.TryParse(strID, ckint) Then
                    '檢查生日(7~12碼) 格式是否正確 
                    strCheck_Src = "19" & strID.Substring(6, 2) & "/" & strID.Substring(8, 2) & "/" & strID.Substring(10, 2)
                    If DateTime.TryParse(strCheck_Src, ckdt) Then
                        chk_value = 0
                    Else
                        chk_value = 4
                    End If
                Else
                    chk_value = 2
                End If
            Else
                chk_value = 3
            End If
        End If

        Return chk_value
    End Function

    Public Function Check_HK_ID(ByVal strID As String) As Integer
        Dim chk_value As Integer = 0, ckint As Integer = -1
        Dim intCheckSum As Integer = 0              ' 檢核碼變數 
        Dim intCount As Integer = 0                 ' 計數變數 
        Dim ckcode As Integer = 0                   ' 檢查碼 
        Dim strAreaCode As Char()                   ' 區域碼變數 
        strID = strID.Trim().ToUpper().Replace("(", "").Replace(")", "")

        ' 確定香港身份證號碼有8碼，最後一碼為檢查碼 
        If strID.Length = 8 Then

            ' 取得首碼字母。 
            strAreaCode = strID.Substring(0, 1).ToCharArray()

            ' 確定首碼在A-Z之間 
            If AscW(strAreaCode(0)) < 65 OrElse AscW(strAreaCode(0)) > 90 Then
                chk_value = 2
            End If

            ' 確定2-7碼是數字 
            If chk_value = 0 Then
                If Not Integer.TryParse(strID.Substring(1, 6), ckint) Then
                    chk_value = 3

                End If
            End If

            ' 取得檢查碼 
            If chk_value = 0 Then
                If strID.Substring(7, 1) = "A" Then
                    ckcode = 10
                ElseIf Not Integer.TryParse(strID.Substring(7, 1), ckcode) Then
                    chk_value = 4
                End If
            End If

            ' 計算檢查碼 
            If chk_value = 0 Then
                ' 取得首碼之積 
                intCheckSum = (AscW(strAreaCode(0)) - 64) * 8

                ' 計算第二碼至第七碼之積。 
                For intCount = 1 To 6
                    intCheckSum += Integer.Parse(strID.Substring(intCount, 1)) * (8 - intCount)
                Next

                ' 加上檢查碼 
                intCheckSum += ckcode

                ' 檢查是否為11整除。 
                If (intCheckSum Mod 11 = 0) Then
                    chk_value = 0
                Else
                    chk_value = 4
                End If
            End If
        Else
            chk_value = 1
        End If

        Return chk_value
    End Function

    Public Function Check_TW_INV(ByVal strID As String) As Integer
        Dim chk_value As Integer = 0, ckint As Integer = 0
        Dim intX As Integer() = New Integer(7) {}
        Dim intY As Integer() = New Integer(7) {}
        Dim intMod As Integer = 0
        ' 餘數變數 
        Dim intSum As Integer = 0
        ' 合計數變數 
        chk_value = 9

        ' 營利事業統一編號 
        If strID.Length = 8 Then
            If Integer.TryParse(strID, ckint) Then
                intX(0) = Integer.Parse(strID.Substring(0, 1)) * 1          ' 第 1位數 * 1 
                intX(1) = Integer.Parse(strID.Substring(1, 1)) * 2          ' 第 2位數 * 2 
                intX(2) = Integer.Parse(strID.Substring(2, 1)) * 1          ' 第 3位數 * 1 
                intX(3) = Integer.Parse(strID.Substring(3, 1)) * 2          ' 第 4位數 * 2 
                intX(4) = Integer.Parse(strID.Substring(4, 1)) * 1          ' 第 5位數 * 1 
                intX(5) = Integer.Parse(strID.Substring(5, 1)) * 2          ' 第 6位數 * 2 
                intX(6) = Integer.Parse(strID.Substring(6, 1)) * 4          ' 第 7位數 * 4 
                intX(7) = Integer.Parse(strID.Substring(7, 1)) * 1          ' 第 8位數 * 1 
                intY(0) = Int(intX(1) / 10)                                 ' 第 2位數的乘積可能大於10, 除以10, 取其整數 
                intY(1) = intX(1) Mod 10                                    ' 第 2位數的乘積可能大於10, 除以10, 取其餘數 
                intY(2) = Int(intX(3) / 10)                                 ' 第 4位數的乘積可能大於10, 除以10, 取其整數 
                intY(3) = intX(3) Mod 10                                    ' 第 4位數的乘積可能大於10, 除以10, 取其餘數 
                intY(4) = Int(intX(5) / 10)                                 ' 第 6位數的乘積可能大於10, 除以10, 取其整數 
                intY(5) = intX(5) Mod 10                                    ' 第 6位數的乘積可能大於10, 除以10, 取其餘數 
                intY(6) = Int(intX(6) / 10)                                 ' 第 7位數的乘積可能大於10, 除以10, 取其整數 
                intY(7) = intX(6) Mod 10                                    ' 第 7位數的乘積可能大於10, 除以10, 取其餘數 
                intSum = intX(0) + intX(2) + intX(4) + intX(7) + intY(0) + intY(1) + intY(2) + intY(3) + intY(4) + intY(5) + intY(6) + intY(7)
                intMod = intSum Mod 10

                ' 判斷 1: 第 7 位數是否為 7 時 
                If strID.Substring(6, 1) = "7" Then
                    ' 判斷 2: 餘數是否為 0 
                    If intMod = 0 Then
                        chk_value = 0
                    Else
                        intSum = intSum + 1

                        ' 再行計算 1999/11/19 修正 
                        intMod = intSum Mod 10
                        If intMod = 0 Then
                            chk_value = 0
                        Else
                            chk_value = 1
                        End If
                    End If
                Else
                    If intMod = 0 Then
                        chk_value = 0
                    Else
                        chk_value = 1
                    End If
                End If
            Else
                chk_value = 2
            End If
        Else
            chk_value = 3
        End If

        Return chk_value
    End Function

    Public Function Check_ISSN(ByVal strISSN As String) As Integer
        Return Check_EAN13(strISSN.Replace("-", ""))
    End Function

    Public Function Check_ISSN8(ByVal strISSN As String) As Integer
        Return Check_EAN8(strISSN.Replace("-", ""))
    End Function

    Public Function Check_ISBN(ByVal strISBN As String) As Integer
        Return Check_EAN13(strISBN.Replace("-", ""))
    End Function

    Public Function Check_ISMN(ByVal strISMN As String) As Integer
        Return Check_EAN13(strISMN.Replace("-", ""))
    End Function

    Public Function Check_EAN13(ByVal eancode As String) As Integer
        Dim chk_value As Integer = 9, icnt As Integer = 0, cksum As Integer = 0
        Dim ckint As Int64 = 0

        If eancode.Length = 13 Then
            If Int64.TryParse(eancode.Substring(0, 13), ckint) Then
                For icnt = 1 To 11 Step 2
                    cksum += Integer.Parse(eancode.Substring(icnt, 1))
                Next

                cksum *= 3

                For icnt = 0 To 11 Step 2
                    cksum += Integer.Parse(eancode.Substring(icnt, 1))
                Next

                cksum = 10 - cksum Mod 10
                If cksum = 10 Then
                    cksum = 0
                End If

                If cksum = Integer.Parse(eancode.Substring(12, 1)) Then
                    chk_value = 0
                Else
                    chk_value = 3
                End If
            Else
                chk_value = 2
            End If
        Else
            chk_value = 1
        End If

        Return chk_value
    End Function

    Public Function Check_EAN8(ByVal eancode As String) As Integer
        Dim chk_value As Integer = 9, icnt As Integer = 0, cksum As Integer = 0
        Dim ckint As Int64 = 0

        If eancode.Length = 8 Then
            If Int64.TryParse(eancode.Substring(0, 8), ckint) Then
                For icnt = 0 To 6 Step 2
                    cksum += Integer.Parse(eancode.Substring(icnt, 1))
                Next

                cksum *= 3

                For icnt = 1 To 6 Step 2
                    cksum += Integer.Parse(eancode.Substring(icnt, 1))
                Next

                cksum = 10 - cksum Mod 10
                If cksum = 10 Then
                    cksum = 0
                End If

                If cksum = Integer.Parse(eancode.Substring(7, 1)) Then
                    chk_value = 0
                Else
                    chk_value = 3
                End If
            Else
                chk_value = 2
            End If
        Else
            chk_value = 1
        End If

        Return chk_value
    End Function
End Class