Imports System.Web.Services
Imports System.Data.Sql
Imports System.Data
Imports Microsoft.VisualBasic
Imports System.IO
Imports System.Data.SqlClient


Namespace xmlService

    <System.Web.Services.WebService(Namespace:="http://tempuri.org/xmlService/Service1")> _
    Public Class Service1
        Inherits System.Web.Services.WebService

#Region " Web Services Designer Generated Code "

        Public Sub New()
            MyBase.New()

            'This call is required by the Web Services Designer.
            InitializeComponent()

            'Add your own initialization code after the InitializeComponent() call

        End Sub

        'Required by the Web Services Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Web Services Designer
        'It can be modified using the Web Services Designer.  
        'Do not modify it using the code editor.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
            components = New System.ComponentModel.Container()
        End Sub

        Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
            'CODEGEN: This procedure is required by the Web Services Designer
            'Do not modify it using the code editor.
            If disposing Then
                If Not (components Is Nothing) Then
                    components.Dispose()
                End If
            End If
            MyBase.Dispose(disposing)
        End Sub

#End Region
        ' Protected Friend Const databaseCategory As String = ";Database=GM"
        ' Protected Friend Const databaseConnString As String = "Data Source=10.25.0.52; Initial Catalog=GM; Integrated Security=True;"

        ' Protected Friend Const databaseConnString = "Data Source=WIN2008STD001; Initial Catalog=GM;Integrated Security=True;"
        Protected Friend Const databaseConnString As String = "Data Source=WIN2008STD001;Initial Catalog=GM;Persist Security Info=True;User ID=sa;Password=clsg@2011;"

        <WebMethod()> _
        Public Function t_GeneralMills(ByVal Parm1 As String, ByVal Parm2 As String, _
                                       ByVal Parm3 As String, ByVal Parm4 As String, _
                                       ByVal Parm5 As String, ByVal Parm6 As String, _
                                       ByVal Parm7 As String, ByVal Parm8 As String, _
                                       ByVal Parm9 As String, ByVal Parm10 As String, _
                                       ByVal Parm11 As String, ByVal Parm12 As String, _
                                       ByVal strVanNo As String, ByVal Parm14 As String, _
                                       ByVal Form_name As String, ByVal T_Action As String, _
                                       ByVal SQLUser As String, ByVal SQLPWD As String, _
                                       ByVal ServIP As String, ByVal TimeZoneID As String) As DataTable
            ' SQL String
            Dim strSql As String = String.Empty
            Dim cn As SqlClient.SqlConnection
            Dim da As SqlClient.SqlDataAdapter
            Dim dt As DataTable
            Dim clientDate As DateTime
            Dim weekday As String

            ' Init data
            cn = New SqlClient.SqlConnection
            da = New SqlClient.SqlDataAdapter
            dt = New DataTable
            dt.TableName = "G"

            If Parm14 = CalculateCheckCode(TimeZoneID) Then
                cn = New SqlClient.SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)

                ' download business_unit
                If Form_name = "down_business_unit" And T_Action = "Download File" Then
                    Try
                        clientDate = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(TimeZoneID))

                        Dim myconnection As New SqlClient.SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                        Dim My_command As New SqlClient.SqlCommand(strSql, myconnection)
                        myconnection.Open()
                        My_command.CommandText = "insert into sync_rec values(@req_date,@vanCode,@req_time,@req_type)"

                        My_command.Parameters.Add("@req_date", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@req_date").Value = clientDate.ToString("yyyy-MM-dd")

                        My_command.Parameters.Add("@vanCode", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@vanCode").Value = strVanNo

                        My_command.Parameters.Add("@req_time", SqlDbType.DateTime, 100)
                        My_command.Parameters("@req_time").Value = clientDate


                        My_command.Parameters.Add("@req_type", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@req_type").Value = "D"

                        My_command.ExecuteNonQuery()

                        myconnection.Close()
                    Catch ex As Exception
                    End Try


                    strSql = "SELECT * FROM business_unit "
                    strSql &= "where SUBSTRING(vancode,8,3) = '" & strVanNo & "'"
                    da = New SqlClient.SqlDataAdapter(strSql, cn)
                    da.Fill(dt)
                    Return dt
                End If

                ' download customer_group_master
                If Form_name = "down_customer_group_master" And T_Action = "Download File" Then
                    strSql = "SELECT distinct g.custNo as cn, g.name1 as n1, "
                    strSql &= "g.name2 as n2, g.custGroup as cg "
                    strSql &= "FROM customer_group_master g, customer_master c "
                    strSql &= "WHERE g.custGroup = c.custGroup AND (block is null or block ='') "
                    strSql &= "AND g.knvv_custOrderBlock = '' and g.custDeliveryBlock ='' and g.salesBlock ='' "
                    strSql &= "AND  g.is_active = '1' and Right(c.shippingPoint,3) = '" & strVanNo & "'"
                    da = New SqlClient.SqlDataAdapter(strSql, cn)
                    da.Fill(dt)
                    Return dt
                End If

                ' download cusotmer_master
                If Form_name = "down_customer_master" And T_Action = "Download File" Then
                    strSql = "SELECT distinct c.custNo as cn, c.name1 as n1, c.name2 as n2, "
                    strSql &= "c.houseAddr as a, c.adrc_telNo as t, c.city as c, "
                    strSql &= "c.custGroup as cg, c.infoCodeExist as e, c.supplierCode as s "
                    strSql &= "FROM customer_master c, customer_group_master g "
                    strSql &= "WHERE c.custGroup = g.custGroup AND (g.block is null or g.block ='') "
                    strSql &= "AND c.knvv_custOrderBlock = '' and c.custDeliveryBlock ='' and c.salesBlock ='' "
                    strSql &= "AND c.is_active = '1' and Right(c.shippingPoint,3) = '" & strVanNo & "'"
                    da = New SqlClient.SqlDataAdapter(strSql, cn)
                    da.Fill(dt)
                    Return dt
                End If

                ' download customer_material_info
                If Form_name = "down_customer_material_info" And T_Action = "Download File" Then
                    strSql = "SELECT distinct i.custNo as n,i.materialCode as m, "
                    strSql &= "i.custMaterialCode as j "
                    strSql &= "FROM customer_material_info_pda i, customer_master c, item_master im "
                    strSql &= "WHERE i.custNo = c.custno AND im.materialCode = i.materialCode "
                    strSql &= "AND im.is_active = '1' and (im.block is null or im.block ='') "
                    strSql &= "AND c.knvv_custOrderBlock = '' and c.custDeliveryBlock ='' and c.salesBlock ='' "
                    strSql &= "AND i.is_active = '1' and right(c.shippingPoint,3)= '" & strVanNo & "'"
                    da = New SqlClient.SqlDataAdapter(strSql, cn)
                    da.Fill(dt)
                    Return dt
                End If

                ' download item_balance
                If Form_name = "down_item_balance" And T_Action = "Download File" Then
                    strSql = "SELECT distinct b.materialCode as m, b.vanCode as v, "
                    strSql &= "b.SAP_open_bal as s, b.act_open_bal as a, b.reason_open as o, "
                    strSql &= "b.closing_diff as d, b.reason_close as c, b.closing_bal as b "
                    strSql &= "FROM item_balance b, item_master i "
                    strSql &= "WHERE b.materialCode = i.materialCode and i.is_active = '1' "
                    strSql &= "AND (i.block is null or i.block ='') "
                    strSql &= "AND SUBSTRING(vancode,8,3) = '" & strVanNo & "'"
                    da = New SqlClient.SqlDataAdapter(strSql, cn)
                    da.Fill(dt)
                    Return dt
                End If

                ' download item_group_master
                If Form_name = "down_item_group_master" And T_Action = "Download File" Then
                    strSql = "SELECT distinct g.* "
                    strSql &= "FROM item_group_master g, item_master i "
                    strSql &= "WHERE g.materialGroupCode = g.materialGroupCode "
                    strSql &= "AND g.is_active = '1' and (i.block is null or i.block ='')"
                    da = New SqlClient.SqlDataAdapter(strSql, cn)
                    da.Fill(dt)
                    Return dt
                End If

                ' download item_master
                If Form_name = "down_item_master" And T_Action = "Download File" Then
                    strSql = "SELECT * FROM item_master "
                    strSql &= "WHERE is_active = '1' and  (block is null or block ='') "
                    da = New SqlClient.SqlDataAdapter(strSql, cn)
                    da.Fill(dt)
                    Return dt
                End If

                ' download kotg901
                If Form_name = "down_kotg901" And T_Action = "Download File" Then
                    strSql = "SELECT * FROM kotg901"
                    da = New SqlClient.SqlDataAdapter(strSql, cn)
                    da.Fill(dt)
                    Return dt
                End If

                ' download kotg902
                If Form_name = "down_kotg902" And T_Action = "Download File" Then
                    strSql = "SELECT * FROM kotg902"
                    da = New SqlClient.SqlDataAdapter(strSql, cn)
                    da.Fill(dt)
                    Return dt
                End If

                ' download message_master
                If Form_name = "down_message_master" And T_Action = "Download File" Then
                    clientDate = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(TimeZoneID))
                    strSql = "SELECT * FROM message_master "
                    strSql &= "WHERE expired <> 1 and (vanCode like '%" & strVanNo & "%' or vanCode ='All') "
                    strSql &= "AND @date >= valid_from and @date <=valid_to "
                    da = New SqlClient.SqlDataAdapter(strSql, cn)
                    da.SelectCommand.Parameters.Add("@date", SqlDbType.DateTime, 100)
                    da.SelectCommand.Parameters("@date").Value = clientDate
                    da.Fill(dt)
                    Return dt
                End If

                ' download price_list
                If Form_name = "down_price_list" And T_Action = "Download File" Then
                    strSql = "SELECT  p.custNo as c, p.materialCode as m, "
                    strSql &= "p.netPrice as n, p.grossPrice as g "
                    strSql &= "FROM price_list p, customer_master c "
                    strSql &= "WHERE p.custNo = c.custno "
                    strSql &= "AND right(c.shippingPoint,3) ='" & strVanNo & "'"
                    da = New SqlClient.SqlDataAdapter(strSql, cn)
                    da.Fill(dt)
                    Return dt
                End If

                ' download reason_master
                If Form_name = "down_reason_master" And T_Action = "Download File" Then
                    strSql = "SELECT reasonCode as r, engDesc as e, chiDesc as c "
                    strSql &= "FROM reason_master where is_active ='x'"
                    da = New SqlClient.SqlDataAdapter(strSql, cn)
                    da.Fill(dt)
                    Return dt
                End If

                ' download reason_master
                If Form_name = "down_reason_master_stock" And T_Action = "Download File" Then
                    strSql = "SELECT reasonCode as r, engDesc as e, chiDesc as c "
                    strSql &= "FROM reason_master_stock where is_active ='x'"
                    da = New SqlClient.SqlDataAdapter(strSql, cn)
                    da.Fill(dt)
                    Return dt
                End If

                ' download reason_master
                If Form_name = "down_reason_master_visit" And T_Action = "Download File" Then
                    strSql = "SELECT reasonCode as r, engDesc as e, chiDesc as c "
                    strSql &= "FROM reason_master_visit where is_active ='x'"
                    da = New SqlClient.SqlDataAdapter(strSql, cn)
                    da.Fill(dt)
                    Return dt
                End If

                ' download uom_convert
                If Form_name = "down_uom_convert" And T_Action = "Download File" Then
                    strSql = "SELECT * FROM uom_convert"
                    da = New SqlClient.SqlDataAdapter(strSql, cn)
                    da.Fill(dt)
                    Return dt
                End If

                ' download user
                If Form_name = "down_user" And T_Action = "Download File" Then
                    strSql = "SELECT mg_id as userid, mg_pass as userpass, "
                    strSql &= "mg_name as fullname, mg_unit as userright "
                    strSql &= "FROM [Manager] where is_pda_user ='1' and is_active ='1' "
                    da = New SqlClient.SqlDataAdapter(strSql, cn)
                    da.Fill(dt)
                    Return dt
                End If

                ' download gm_route
                If Form_name = "down_gm_route" And T_Action = "Download File" Then
                    clientDate = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(TimeZoneID))
                    weekday = clientDate.DayOfWeek.ToString
                    strSql = "SELECT g.vanCode, g.custNo, g.custName "
                    strSql &= "FROM gm_route g, customer_master c "
                    strSql &= "WHERE c.custNo = g.custNo and c.is_active= '1' "
                    strSql &= "and g.is_active = '1' and right(vanCode,3) = '" & Right(strVanNo, 3) & "' "
                    strSql &= String.Format(" and ({0} = 'x' or {0} = '1') ", weekday)
                    strSql &= " union SELECT c.shippingPoint as vanCode, c.custNo, c.name1 as custName "
                    strSql &= "FROM rush_order_header h, customer_master c "
                    strSql &= "WHERE h.custNo = c.custNo "
                    strSql &= "AND convert(varchar(10),ship_date,111) = '" & clientDate.ToString("yyyy/MM/dd") & "' "
                    strSql &= "and right(c.shippingPoint,3) = '" & Right(strVanNo, 3) & "'"
                    da = New SqlClient.SqlDataAdapter(strSql, cn)
                    da.Fill(dt)
                    Return dt
                End If

                ' download rush_order_header
                If Form_name = "down_rush_order_header" And T_Action = "Download File" Then
                    clientDate = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(TimeZoneID))
                    strSql = "SELECT * FROM rush_order_header "
                    strSql &= "where right(van_id,3) = '" & Right(strVanNo, 3) & "' "
                    strSql &= "and isnull(isException,'') ='' and ship_date =@ship_date "
                    da = New SqlClient.SqlDataAdapter(strSql, cn)
                    da.SelectCommand.Parameters.Add("@ship_date", SqlDbType.Date, 100)
                    da.SelectCommand.Parameters("@ship_date").Value = clientDate.Date
                    da.Fill(dt)
                    Return dt
                End If

                ' download rush_order_detail
                If Form_name = "down_rush_order_detail" And T_Action = "Download File" Then
                    ' Build a table with empty roll.
                    clientDate = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(TimeZoneID))
                    strSql = "SELECT d.* FROM rush_order_header h, rush_order_detail d "
                    strSql &= "WHERE h.refDocNo = d.refDocNo and right(h.van_id,3) = '" & Right(strVanNo, 3) & "' "
                    strSql &= "and h.ship_date = @ship_date and h.refDocNo <>'' and isnull(d.isException,'') ='' "
                    ' If need to download detail, download the table with rows.
                    If Parm12 = "1" Then
                        strSql &= " union "
                        strSql &= " SELECT d.* FROM rush_order_header h, rush_order_detail d "
                        strSql &= "WHERE h.PO_no = d.PO_no and h.custNo = d.custNo "
                        strSql &= "AND right(h.van_id,3) = '" & Right(strVanNo, 3) & "' "
                        strSql &= "and h.PO_no <>'' and h.ship_date = @ship_date "
                        strSql &= "and isnull(d.isException,'') ='' "
                    End If
                    da = New SqlClient.SqlDataAdapter(strSql, cn)
                    da.SelectCommand.Parameters.Add("@ship_date", SqlDbType.Date, 100)
                    da.SelectCommand.Parameters("@ship_date").Value = clientDate.Date
                    da.Fill(dt)
                    Return dt
                End If

                cn.Close()
            End If
            da.Dispose()
            cn.Dispose()
            Return dt
        End Function

        <WebMethod()> _
        Public Function t_GeneralMills_s(ByVal Parm1 As String, ByVal Parm2 As String, ByVal Parm3 As String, _
                                        ByVal Parm4 As String, ByVal Parm5 As String, ByVal Parm6 As String, _
                                        ByVal Parm7 As String, ByVal Parm8 As String, ByVal Parm9 As String, _
                                        ByVal Parm10 As String, ByVal Parm11 As String, ByVal Parm12 As String, _
                                        ByVal Parm13 As String, ByVal Parm14 As String, _
                                        ByVal Form_name As String, ByVal T_Action As String, _
                                        ByVal SQLUser As String, ByVal SQLPWD As String, ByVal ServIP As String, _
                                        ByVal TimeZoneID As String) As String

            ' SQL String
            Dim return_string As String
            Dim strsql As String
            Dim clientDate As DateTime
            ' Set return
            return_string = "Not found"

            Try

                If Parm13 = CalculateCheckCode(TimeZoneID) Then
                    If Form_name = "Transaction Detail Upload 2" And T_Action = "Upload File" Then
                        'ds = ws.t_GeneralMills_s(strrefDocNo, strSeqNo, strmaterialCode, strPO_no, strcustMaterialCode, strquantity, strnetPrice, strgrossPrice, "", "", "", "", ck_code, "", "Transaction Detail Upload 2", "Upload File", Class1.g_sql_logon, Class1.g_sql_pass, Class1.g_sql_server, Class1.g_local_time_zone)

                        Dim cn As New SqlClient.SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                        strsql = " declare @a int "
                        strsql &= " set @a = (select count(refDocNo) from txn_detail where refDocNo =@refDocNo and SeqNo =@SeqNo ) "
                        strsql &= " if @a = 0 "
                        strsql &= "  INSERT INTO [txn_detail]([SeqNo],[refDocNo],[materialCode],[PO_no],[custMaterialCode],[quantity],[netPrice],[grossPrice]) "
                        strsql &= " values (@SeqNo,@refDocNo, @materialCode, @PO_no, @custMaterialCode, @quantity, @netPrice, @grossPrice)"

                        cn.Open()
                        Dim My_command As SqlClient.SqlCommand
                        My_command = New SqlClient.SqlCommand(strsql, cn)

                        My_command.Parameters.Add("@refDocNo", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@refDocNo").Value = Parm1

                        My_command.Parameters.Add("@SeqNo", SqlDbType.Int, 100)
                        My_command.Parameters("@SeqNo").Value = Parm2

                        My_command.Parameters.Add("@materialCode", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@materialCode").Value = Parm3

                        My_command.Parameters.Add("@PO_no", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@PO_no").Value = Parm4

                        My_command.Parameters.Add("@custMaterialCode", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@custMaterialCode").Value = Parm5

                        My_command.Parameters.Add("@quantity", SqlDbType.Int, 100)
                        My_command.Parameters("@quantity").Value = Parm6

                        My_command.Parameters.Add("@netPrice", SqlDbType.Decimal, 100)
                        My_command.Parameters("@netPrice").Value = Parm7

                        My_command.Parameters.Add("@grossPrice", SqlDbType.Decimal, 100)
                        My_command.Parameters("@grossPrice").Value = Parm8

                        My_command.ExecuteNonQuery()
                        cn.Close()



                        Dim cn1 As New SqlClient.SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                        strsql = " declare @a int "
                        strsql &= " set @a = (select count(refDocNo) from txn_detail where refDocNo =@refDocNo and SeqNo =@SeqNo ) "
                        strsql &= " if @a = 0 "
                        strsql &= "  INSERT INTO [txn_detail]([SeqNo],[refDocNo],[materialCode],[PO_no],[custMaterialCode],[quantity],[netPrice],[grossPrice]) "
                        strsql &= " values (@SeqNo,@refDocNo, @materialCode, @PO_no, @custMaterialCode, @quantity, @netPrice, @grossPrice)"

                        cn1.Open()
                        Dim My_command1 As SqlClient.SqlCommand
                        My_command1 = New SqlClient.SqlCommand(strsql, cn1)

                        My_command1.Parameters.Add("@refDocNo", SqlDbType.NVarChar, 100)
                        My_command1.Parameters("@refDocNo").Value = Parm1

                        My_command1.Parameters.Add("@SeqNo", SqlDbType.Int, 100)
                        My_command1.Parameters("@SeqNo").Value = Parm2

                        My_command1.Parameters.Add("@materialCode", SqlDbType.NVarChar, 100)
                        My_command1.Parameters("@materialCode").Value = Parm3

                        My_command1.Parameters.Add("@PO_no", SqlDbType.NVarChar, 100)
                        My_command1.Parameters("@PO_no").Value = Parm4

                        My_command1.Parameters.Add("@custMaterialCode", SqlDbType.NVarChar, 100)
                        My_command1.Parameters("@custMaterialCode").Value = Parm5

                        My_command1.Parameters.Add("@quantity", SqlDbType.Int, 100)
                        My_command1.Parameters("@quantity").Value = Parm6

                        My_command1.Parameters.Add("@netPrice", SqlDbType.Decimal, 100)
                        My_command1.Parameters("@netPrice").Value = Parm7

                        My_command1.Parameters.Add("@grossPrice", SqlDbType.Decimal, 100)
                        My_command1.Parameters("@grossPrice").Value = Parm8

                        My_command1.ExecuteNonQuery()
                        cn1.Close()


                        return_string = "OK"
                    End If

                    If Form_name = "Transaction Header Upload 2" And T_Action = "Upload File" Then
                        'ds = ws.t_GeneralMills_s(refDocNo, PO_no, txn_type, user_id, cr_date, van_id, cust_no, total_quantity, total_price, detail_count, IsVoid, strremark, ck_code, "", "Transaction Header Upload 2", "Upload File", Class1.g_sql_logon, Class1.g_sql_pass, Class1.g_sql_server, Class1.g_local_time_zone)
                        strsql = " declare @a int "
                        strsql &= " set @a = (select count(refDocNo) from txn_header where refDocNo =@refDocNo) "
                        strsql &= " if @a = 0 "
                        strsql &= " insert txn_header (refDocNo, PO_no,txn_type,user_id,cr_date,van_id,custNo,total_quantity,total_price,detail_count,IsVoid,remark) "
                        strsql &= " values (@refDocNo, @PO_no, @txn_type, @user_id, @cr_date, @van_id, @custNo, @total_quantity, @total_price, @detail_count, @IsVoid, @remark)"

                        Dim cn As SqlClient.SqlConnection
                        cn = New SqlClient.SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)

                        cn.Open()
                        Dim My_command As SqlClient.SqlCommand
                        My_command = New SqlClient.SqlCommand(strsql, cn)
                        My_command.Parameters.Add("@refDocNo", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@refDocNo").Value = Parm1

                        My_command.Parameters.Add("@PO_no", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@PO_no").Value = Parm2

                        My_command.Parameters.Add("@txn_type", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@txn_type").Value = Parm3

                        My_command.Parameters.Add("@user_id", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@user_id").Value = Parm4

                        My_command.Parameters.Add("@cr_date", SqlDbType.DateTime, 100)
                        My_command.Parameters("@cr_date").Value = CDate(Parm5)

                        My_command.Parameters.Add("@van_id", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@van_id").Value = Parm6

                        My_command.Parameters.Add("@custNo", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@custNo").Value = Parm7

                        My_command.Parameters.Add("@total_quantity", SqlDbType.Int, 100)
                        My_command.Parameters("@total_quantity").Value = Parm8

                        My_command.Parameters.Add("@total_price", SqlDbType.Decimal, 100)
                        My_command.Parameters("@total_price").Value = Parm9

                        My_command.Parameters.Add("@detail_count", SqlDbType.Int, 100)
                        My_command.Parameters("@detail_count").Value = Parm10

                        My_command.Parameters.Add("@IsVoid", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@IsVoid").Value = Parm11

                        My_command.Parameters.Add("@remark", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@remark").Value = Parm12
                        My_command.ExecuteNonQuery()
                        cn.Close()


                        Dim cn1 As SqlClient.SqlConnection
                        cn1 = New SqlClient.SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)

                        cn1.Open()
                        Dim My_command1 As SqlClient.SqlCommand
                        My_command1 = New SqlClient.SqlCommand(strsql, cn1)
                        My_command1.Parameters.Add("@refDocNo", SqlDbType.NVarChar, 100)
                        My_command1.Parameters("@refDocNo").Value = Parm1

                        My_command1.Parameters.Add("@PO_no", SqlDbType.NVarChar, 100)
                        My_command1.Parameters("@PO_no").Value = Parm2

                        My_command1.Parameters.Add("@txn_type", SqlDbType.NVarChar, 100)
                        My_command1.Parameters("@txn_type").Value = Parm3

                        My_command1.Parameters.Add("@user_id", SqlDbType.NVarChar, 100)
                        My_command1.Parameters("@user_id").Value = Parm4

                        My_command1.Parameters.Add("@cr_date", SqlDbType.DateTime, 100)
                        My_command1.Parameters("@cr_date").Value = CDate(Parm5)

                        My_command1.Parameters.Add("@van_id", SqlDbType.NVarChar, 100)
                        My_command1.Parameters("@van_id").Value = Parm6

                        My_command1.Parameters.Add("@custNo", SqlDbType.NVarChar, 100)
                        My_command1.Parameters("@custNo").Value = Parm7

                        My_command1.Parameters.Add("@total_quantity", SqlDbType.Int, 100)
                        My_command1.Parameters("@total_quantity").Value = Parm8

                        My_command1.Parameters.Add("@total_price", SqlDbType.Decimal, 100)
                        My_command1.Parameters("@total_price").Value = Parm9

                        My_command1.Parameters.Add("@detail_count", SqlDbType.Int, 100)
                        My_command1.Parameters("@detail_count").Value = Parm10

                        My_command1.Parameters.Add("@IsVoid", SqlDbType.NVarChar, 100)
                        My_command1.Parameters("@IsVoid").Value = Parm11

                        My_command1.Parameters.Add("@remark", SqlDbType.NVarChar, 100)
                        My_command1.Parameters("@remark").Value = Parm12
                        My_command1.ExecuteNonQuery()
                        cn1.Close()

                        return_string = "OK"
                    End If



                    If Form_name = "Check Header Transaction" And T_Action = "Check File" Then
                        strsql = "select * from txn_header where refDocNo ='" + Parm1 + "'"
                        Dim myconnection As New SqlClient.SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)


                        Dim My_command1 As New SqlClient.SqlCommand(strsql, myconnection)
                        myconnection.Open()
                        Dim myreader As SqlClient.SqlDataReader
                        myreader = My_command1.ExecuteReader()

                        If myreader.Read Then
                            return_string = "Found"
                        End If

                        myreader.Close()
                        myconnection.Close()

                    End If


                    If Form_name = "Check Detail Transaction" And T_Action = "Check File" Then
                        strsql = "select * from txn_detail where refDocNo ='" + Parm1 + "' and SeqNo ='" + Parm2 + "'"
                        Dim myconnection As New SqlClient.SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)


                        Dim My_command1 As New SqlClient.SqlCommand(strsql, myconnection)
                        myconnection.Open()
                        Dim myreader As SqlClient.SqlDataReader
                        myreader = My_command1.ExecuteReader()

                        If myreader.Read Then
                            return_string = "Found"
                        End If

                        myreader.Close()
                        myconnection.Close()

                    End If





                    If Form_name = "Check Ref Picture" And T_Action = "Check File" Then
                        strsql = "select * from photo where photo_name ='" + Parm1 + "'"
                        Dim myconnection As New SqlClient.SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)

                        Dim My_command1 As New SqlClient.SqlCommand(strsql, myconnection)
                        myconnection.Open()
                        Dim myreader As SqlClient.SqlDataReader
                        myreader = My_command1.ExecuteReader()

                        If myreader.Read Then
                            return_string = "Found"
                        End If

                        myreader.Close()
                        myconnection.Close()

                    End If

                    If Form_name = "Transaction Header Upload" And T_Action = "Upload File" Then

                        strsql = "insert txn_header (refDocNo, PO_no,txn_type,user_id,cr_date,van_id,custNo,total_quantity,total_price,detail_count,IsVoid,remark) values ("
                        strsql = strsql + Parm1 + ")"
                        Dim cn As SqlClient.SqlConnection
                        cn = New SqlClient.SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)

                        cn.Open()
                        Dim My_command As SqlClient.SqlCommand
                        My_command = New SqlClient.SqlCommand(strsql, cn)
                        My_command.ExecuteNonQuery()
                        cn.Close()
                        return_string = "OK"
                    End If

                    If Form_name = "Transaction Detail Upload" And T_Action = "Upload File" Then

                        Dim cn As New SqlClient.SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                        strsql = "INSERT INTO [txn_detail]([SeqNo],[refDocNo],[materialCode],[PO_no],[custMaterialCode],[quantity],[netPrice],[grossPrice])  values ("
                        strsql = strsql + Parm1 + ")"

                        cn.Open()
                        Dim My_command As SqlClient.SqlCommand
                        My_command = New SqlClient.SqlCommand(strsql, cn)
                        My_command.ExecuteNonQuery()
                        cn.Close()
                        return_string = "OK"
                    End If



                    If Form_name = "Item Balance Upload" And T_Action = "Upload File" Then
                        clientDate = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(TimeZoneID))


                        Dim cn As New SqlClient.SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                        strsql = " declare @a int "
                        strsql &= " set @a = (select count(vancode) from item_balance_history where vancode =@vanCode and workDate = @workDate and materialCode = @materialCode ) "
                        strsql &= " if @a = 0  insert into item_balance_history values(@workDate, @materialCode, @vanCode, @SAP_open_bal, @SAP_close_bal,@act_close_bal,@closing_diff,@reason_close,@sync_date)"
                        strsql &= " else       update item_balance_history set SAP_open_bal = @SAP_open_bal, SAP_close_bal = @SAP_close_bal"
                        strsql &= " ,act_close_bal = @act_close_bal, closing_diff = @closing_diff, reason_close = @reason_close, sync_date = @sync_date where vancode =@vanCode and workDate = @workDate and materialCode = @materialCode "
                        cn.Open()
                        Dim My_command As SqlClient.SqlCommand

                        My_command = New SqlClient.SqlCommand(strsql, cn)

                        My_command.Parameters.Add("@workDate", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@workDate").Value = clientDate.ToString("yyyy-MM-dd")

                        My_command.Parameters.Add("@vanCode", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@vanCode").Value = Parm1

                        My_command.Parameters.Add("@materialCode", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@materialCode").Value = Parm2

                        My_command.Parameters.Add("@SAP_open_bal", SqlDbType.Int, 100)
                        My_command.Parameters("@SAP_open_bal").Value = Parm3

                        My_command.Parameters.Add("@SAP_close_bal", SqlDbType.Int, 100)
                        My_command.Parameters("@SAP_close_bal").Value = Parm4

                        My_command.Parameters.Add("@act_close_bal", SqlDbType.Int, 100)
                        My_command.Parameters("@act_close_bal").Value = Parm5

                        My_command.Parameters.Add("@closing_diff", SqlDbType.Int, 100)
                        My_command.Parameters("@closing_diff").Value = Parm6


                        My_command.Parameters.Add("@reason_close", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@reason_close").Value = Parm7

                        My_command.Parameters.Add("@sync_date", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@sync_date").Value = clientDate.ToString("yyyy-MM-dd")





                        My_command.ExecuteNonQuery()
                        cn.Close()
                        return_string = "OK"
                    End If


                    If Form_name = "Running No Upload" And T_Action = "Upload File" Then
                        clientDate = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(TimeZoneID))

                        Dim cn As New SqlClient.SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                        strsql = Parm1

                        cn.Open()
                        Dim My_command As SqlClient.SqlCommand
                        My_command = New SqlClient.SqlCommand(strsql, cn)
                        My_command.ExecuteNonQuery()

                        My_command.CommandText = "insert into sync_rec values(@req_date,@vanCode,@req_time,@req_type)"


                        My_command.Parameters.Add("@req_date", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@req_date").Value = clientDate.ToString("yyyy-MM-dd")

                        My_command.Parameters.Add("@vanCode", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@vanCode").Value = Parm3

                        My_command.Parameters.Add("@req_time", SqlDbType.DateTime, 100)
                        My_command.Parameters("@req_time").Value = clientDate


                        My_command.Parameters.Add("@req_type", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@req_type").Value = "U"

                        My_command.ExecuteNonQuery()


                        cn.Close()
                        return_string = "OK"
                    End If

                    If Form_name = "Visit Report Upload" And T_Action = "Upload File" Then
                        clientDate = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(TimeZoneID))


                        Dim cn As New SqlClient.SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                        strsql = " declare @a int "
                        strsql &= " set @a = (select count(vancode) from visit_report where vancode =@vanCode and workDate = @workDate and custNo = @custNo ) "
                        strsql &= " if @a = 0  insert into visit_report values(@workDate,@vanCode, @custNo, @IsVisit, @reason,@update_date,@updated_by)"
                        strsql &= " else       update visit_report set isVisit = @isVisit, reason = @reason, update_date = @update_date, updated_by = @updated_by where vancode =@vanCode and workDate = @workDate and custNo = @custNo "

                        cn.Open()
                        Dim My_command As SqlClient.SqlCommand

                        My_command = New SqlClient.SqlCommand(strsql, cn)

                        My_command.Parameters.Add("@workDate", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@workDate").Value = Parm2

                        My_command.Parameters.Add("@vanCode", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@vanCode").Value = Parm3

                        My_command.Parameters.Add("@custNo", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@custNo").Value = Right("000000000" & Parm4, 10)

                        My_command.Parameters.Add("@IsVisit", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@IsVisit").Value = Parm5

                        My_command.Parameters.Add("@reason", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@reason").Value = Parm6



                        My_command.Parameters.Add("@updated_by", SqlDbType.NVarChar, 100)
                        My_command.Parameters("@updated_by").Value = Parm7

                        My_command.Parameters.Add("@update_date", SqlDbType.DateTime, 100)
                        My_command.Parameters("@update_date").Value = clientDate





                        My_command.ExecuteNonQuery()
                        cn.Close()
                        return_string = "OK"
                    End If



                End If

                Return return_string
                Exit Function


            Catch ex As Exception
                return_string = "Error"
                Return "Error for donwload,please try again" + ex.Message
                Exit Function
              End Try


        End Function

        <WebMethod()> _
        Public Function t_GeneralMills_b(ByVal Parm1 As String, ByVal Parm2 As Byte(), ByVal Parm3 As String, _
                                        ByVal Parm4 As String, ByVal Parm5 As String, ByVal Parm6 As String, _
                                        ByVal Parm7 As String, ByVal Parm8 As String, ByVal Parm9 As String, _
                                        ByVal Parm10 As String, ByVal Parm11 As String, ByVal Parm12 As String, _
                                        ByVal Parm13 As String, ByVal photo_path As String, _
                                        ByVal Form_name As String, ByVal T_Action As String, _
                                        ByVal SQLUser As String, ByVal SQLPWD As String, ByVal ServIP As String, ByVal TimeZoneID As String) As String

            ' SQL String
            Dim return_string As String = String.Empty
            Dim strsql As String = String.Empty

            ' SQL Connection
            Dim sqlConnect As SqlClient.SqlConnection
            Dim sqlInsertCmd As SqlClient.SqlCommand
            ' Write to file
            Dim save_path As String = String.Empty
            Dim bw As System.IO.BinaryWriter
            Dim fs As System.IO.FileStream


            strsql = "  insert into photo (photo_name,photo) values (@name,@image)"

            return_string = "fail"
            If Parm12 = CalculateCheckCode(TimeZoneID) And Form_name = "JPG" And T_Action = "Upload File" Then

                sqlConnect = New SqlClient.SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                'sqlConnect = New SqlClient.SqlConnection("Server=" & ServIP & ";UID=" & SQLUser & ";PWD=" & SQLPWD & databaseCategory)
                sqlInsertCmd = New SqlClient.SqlCommand(strsql, sqlConnect)
                sqlConnect.Open()
                sqlInsertCmd.CommandType = Data.CommandType.Text
                sqlInsertCmd.Parameters.Add("@name", SqlDbType.VarChar).Value = Parm1
                sqlInsertCmd.Parameters.Add("@image", SqlDbType.Image).Value = Parm2

                sqlInsertCmd.ExecuteNonQuery()
                sqlConnect.Close()
                return_string = "OK"
            Else
                return_string = "fail" + Form_name + ";" + T_Action
            End If

            save_path = photo_path + Parm1 + ".jpg"
            fs = New System.IO.FileStream(save_path, FileMode.Create)
            bw = New System.IO.BinaryWriter(fs)
            bw.Write(Parm2)
            bw.Close()



            Return return_string

        End Function

        <WebMethod()> _
        Public Function t_GeneralMills_q(ByVal Parm1 As String, ByVal Parm2 As String, _
                               ByVal Parm3 As String, ByVal Parm4 As String, _
                               ByVal Parm5 As String, ByVal Parm6 As String, _
                               ByVal Parm7 As String, ByVal Parm8 As String, _
                               ByVal Parm9 As String, ByVal Parm10 As String, _
                               ByVal Parm11 As String, ByVal Parm12 As String, _
                               ByVal strVanNo As String, ByVal Parm14 As String, _
                               ByVal Form_name As String, ByVal T_Action As String, _
                               ByVal SQLUser As String, ByVal SQLPWD As String, _
                               ByVal ServIP As String, ByVal TimeZoneID As String) As String
            ' SQL String
            Dim strsql As String = String.Empty
            Dim cn As New SqlClient.SqlConnection
            Dim da As New SqlClient.SqlDataAdapter
            Dim dt As DataTable = New DataTable
            dt.TableName = "G"


            If Parm14 = CalculateCheckCode(TimeZoneID) Then
                cn = New SqlClient.SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                cn.Open()
                ' download price_list
                If Form_name = "down_price_list" And T_Action = "Download File" Then
                    strsql = "SELECT  p.custNo as c, p.materialCode as m, p.netPrice as n,p.unknown1 as g FROM price_list p inner join customer_master c on p.custNo = c.custno where right(c.shippingPoint,3) ='" & strVanNo & "'"
                    Dim result As String = ""
                    Dim Sql_Command1 As New SqlCommand(strsql, cn)


                    Dim Sql_Reader1 As SqlDataReader = Sql_Command1.ExecuteReader()

                    Do While Sql_Reader1.Read()

                        result += Sql_Reader1("c").ToString & "," & Sql_Reader1("m").ToString & "," & Sql_Reader1("n").ToString & "," & Sql_Reader1("g").ToString & ","
                    Loop

                    Sql_Reader1.Close()
                    cn.Close()

                    Return result

                End If

                If Form_name = "down_customer_material_info" And T_Action = "Download File" Then
                    strsql = "SELECT i.custNo as n ,i.materialCode as m ,i.custMaterialCode as j FROM customer_material_info_pda i inner join customer_master c on i.custNo = c.custno where i.is_active = '1' and right(c.shippingPoint,3)= '" & strVanNo & "'"
                    Dim result As String = ""
                    Dim Sql_Command1 As New SqlCommand(strsql, cn)


                    Dim Sql_Reader1 As SqlDataReader = Sql_Command1.ExecuteReader()

                    Do While Sql_Reader1.Read()

                        result += Sql_Reader1("n").ToString & "," & Sql_Reader1("m").ToString & "," & Sql_Reader1("j").ToString & ","
                    Loop

                    Sql_Reader1.Close()
                    cn.Close()

                    Return result

                End If



                cn.Close()
            End If
            da.Dispose()
            cn.Dispose()
            Return 0
        End Function

        Protected Function CalculateCheckCode(ByVal tzID As String) As String
            Return CalculateCheckCode(TimeZoneInfo.FindSystemTimeZoneById(tzID))
        End Function

        Protected Function CalculateCheckCode(ByVal tzi As TimeZoneInfo) As String
            ' Check code
            Dim ck_code As String = String.Empty
            Dim dight As Integer
            Dim check_month As String = String.Empty
            Dim check_day As String = String.Empty
            Dim r1 As String = String.Empty
            Dim r2 As String = String.Empty
            Dim r3 As Integer = 0
            Dim clientDate As Date = TimeZoneInfo.ConvertTime(Now, tzi)

            r3 = Month(clientDate) + Day(clientDate) + Year(clientDate)
            dight = Int(r3 / 3)
            check_month = Month(clientDate)
            If check_month > 6 Then
                r1 = "@:"
            Else
                r1 = "#@"
            End If
            check_day = Day(clientDate)
            If check_day > 15 Then
                r2 = "^!"
            Else
                r2 = "$@"
            End If

            ' Generate Check code
            ck_code = CStr(Month(clientDate)) + r1 + CStr(Day(clientDate)) + r2 + CStr(Year(clientDate)) + CStr(dight)
            Return ck_code
        End Function


    End Class

End Namespace
