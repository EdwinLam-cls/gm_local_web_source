﻿'---------------------------------------------------------------------------- 
'專案名稱	公用函數 
'程式功能	Internet 相關驗證 
'設計人員	 
'修改人員 
'備註說明 
'---------------------------------------------------------------------------- 

Public Class Check_Internet
	' TopLevelDomain 最高層網域 (Top Level Domain) 名稱定義
	' 此處共計251個資料，如有變更時，請自行增減 
	' 資料可由 Internet Assigned Numbers Authority (IANA，http://www.iana.org) 取得 

	Public TopLevelDomain As String() = New String(26) { _
	".com.org.net.edu.gov.mil.int", _
	".ac.ad.ae.af.ag.ai.al.am.an.ao.aq.ar.as.at.au.aw.az", _
	".ba.bd.bb.be.bf.bg.bh.bi.bj.bm.bn.bo.br.bs.bt.bv.bw.by.bz", _
	".ca.cc.cd.cf.cg.ch.ci.ck.cl.cm.cn.co.cr.cu.cv.cx.cy.cz", _
	".de.dj.dk.dm.do.dz", _
	".ec.ee.eg.eh.er.es.et", _
	".fi.fj.fk.fm.fo.fr", _
	".ga.gb.gd.gf.gg.gq.ge.gh.gi.gl.gm.gn.gp.gr.gs.gt.gu.gw.gy", _
	".hk.hm.hn.hr.ht.hu", _
	".id.ie.il.im.in.io.iq.ir.is.it", _
	".je.jm.jo.jp", ".ke.kg.kh.ki.km.kn.kp.kr.kw.ky.kz", _
	".la.lc.lb.li.lk.lr.ls.lt.lu.lv.ly", _
	".ma.mc.md.mg.mh.mk.ml.mm.mn.mo.mp.mq.mr.ms.mt.mu.mv.mw.mx.my.mz", _
	".na.nc.ne.nf.ng.ni.nl.no.np.nr.nu.nz", _
	".om", _
	".pa.pe.pf.pg.ph.pk.pl.pm.pn.pt.pr.pw.py", _
	".qa", _
	".re.ro.ru.rw", _
	".sa.sb.sc.sd.se.sg.sh.si.sj.sk.sl.sm.sn.so.sr.st.sv.sy.sz", _
	".tc.td.tf.tg.th.tj.tk.tm.tn.to.tp.tr.tt.tv.tw.tz", _
	".ua.ug.uk.um.us.uy.uz", _
	".va.vc.ve.vg.vi.vn.vu", _
	".ws.wf", _
	".", _
	".ye.yt.yu", _
	".za.zm.zr.zw" _
	}

    Public Function Check_Email(ByVal strEmail As String) As Integer
        Dim intPos As Integer = 0, rtn_value As Integer = 0, sCnt As Integer = 0
        Dim strHost As String = ""
        Dim strInvalidChars As String = ""

        strEmail = strEmail.Trim()

        ' 1 字串的長度是否小於 5 碼 (Email 最少要有 A@B.C，五個字所組成) 
        sCnt = strEmail.Length

        ' 字串長度 
        If sCnt < 5 Then
            rtn_value = 1
        End If

        ' 2 檢查字串中含有不合法的字元。 
        If rtn_value = 0 Then
            strInvalidChars = "!#$%^&*()=+{}[]|\;:'/?>,< "

            For intPos = 0 To sCnt - 1
                If strInvalidChars.Contains(strEmail.Substring(intPos, 1)) Then
                    rtn_value = 2

                    ' 結束迴圈 
                    intPos = sCnt
                End If
            Next
        End If

        ' 3 檢查字串的首字或尾字是否含有"@"字元。 
        If rtn_value = 0 Then
            intPos = strEmail.IndexOf("@") + 1
            If intPos = 1 OrElse intPos = sCnt OrElse intPos = 0 Then
                rtn_value = 3
            End If
        End If

        ' 4 檢查字串中含有第二個"@"字元。 
        If rtn_value = 0 Then
            ' 取出郵件伺服器位址，即如一般 "hinet.net" 
            strHost = strEmail.Substring(intPos, sCnt - intPos)

            If strHost.IndexOf("@") > -1 Then
                rtn_value = 4
            End If
        End If

        ' 5 郵件伺服器位位址驗證。 
        If rtn_value = 0 Then
            rtn_value = Check_Host(strHost.ToLower())
        End If

        Return rtn_value
    End Function

    Public Function Check_Host(ByVal strHost As String) As Integer
        Dim rtn_value As Integer = 0, ckint As Integer = 0, intCnt As Integer = 0, addtype As Integer = 0
        Dim strSplit As String() = Nothing

        ' 11 檢查字串中是否含有"."字元。 
        If Not strHost.Contains(".") Then
            rtn_value = 11
        End If

        ' 確認位址的二種型態 
        ' a. ＩＰ型態，如 "212.212.212.212" 
        ' b. 網名型態，如 "hinet.net" 
        If rtn_value = 0 Then
            strSplit = strHost.Split("."c)

            ' 判斷陣列是否分成四個字串 
            If strSplit.Length = 4 Then
                ' 若為四個字串，則先預定為ＩＰ型態。 
                addtype = 1

                ' 檢查四個字串之中，是否為數字。 
                For intCnt = 0 To 3
                    If Not Integer.TryParse(strSplit(intCnt), ckint) Then
                        addtype = 2
                        ' 有非數字存在，設成網名型態 
                        ' 結束迴圈 
                        intCnt = 4
                    End If
                Next

                ' ＩＰ型態： 
                ' 第一組ＩＰ要在 0~239 之間，二、三、四組ＩＰ要在 0~255 之間 
                If addtype = 1 Then
                    For intCnt = 0 To 3
                        If intCnt = 0 Then
                            ckint = Integer.Parse(strSplit(intCnt))
                            If ckint > 239 OrElse ckint < 0 Then
                                rtn_value = 12
                                ' 結束迴圈 
                                intCnt = 4
                            End If
                        Else
                            ckint = Integer.Parse(strSplit(intCnt))
                            If ckint > 255 OrElse ckint < 0 Then
                                rtn_value = 13
                                ' 結束迴圈 
                                intCnt = 4
                            End If
                        End If
                    Next
                End If
            Else
                addtype = 2
            End If

            If addtype = 2 AndAlso rtn_value = 0 Then
                ' 網名型態： 
                ' 檢查最高級層網域，即檢查最後一字串是否符合www.iana.org規字的字串。 
                ' 如 "seed.net.tw" 的最後一字串為 "tw"。 
                ' 如 "lsc.lu@msa.hinet.net"的最後一字串為 "net"。 
                rtn_value = Check_TopLevelDomain(strSplit(strSplit.Length - 1))
            End If
        End If

        Return rtn_value
    End Function

    Public Function Check_TopLevelDomain(ByVal strDomain As String) As Integer
        Dim rtn_value As Integer = 21
        Dim iCnt As Integer = 0

        strDomain = strDomain.ToLower()

        If strDomain <> "" Then
            ' 檢查輸入字串是否存在於規定字串裡 
            For iCnt = 0 To 26
                If TopLevelDomain(iCnt).Contains(strDomain) Then
                    rtn_value = 0
                    ' 停止迴圈 
                    iCnt = 27
                End If
            Next
        End If
        Return rtn_value
    End Function
End Class