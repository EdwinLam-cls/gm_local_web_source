﻿Imports AjaxControlToolkit
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.Collections.Generic
Imports System.Data.SqlClient
Imports System.Web.Configuration


' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()> _
<WebService(Namespace:="http://tempuri.org/")> _
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Public Class ItemsService
    Inherits System.Web.Services.WebService

    <WebMethod()> _
    Public Function GetUOM(ByVal knownCategoryValues As String, ByVal category As String) As CascadingDropDownNameValue()
        Dim l As New List(Of CascadingDropDownNameValue)
        Dim kv As StringDictionary = CascadingDropDown.ParseKnownCategoryValuesString(knownCategoryValues)
        If kv.Count <= 0 Then
            Return l.ToArray
        End If

        Dim item As String = knownCategoryValues.Substring(10, knownCategoryValues.Length - 11)
        Using sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
            sql_conn.Open()

            ' 取得人員基本資料
            Dim SqlString As String = "select to_uom_name uom from stkuom where stk_desc = N'" & item & "' union select stk_uom from stkmas where stk_desc = N'" & item & "'"

            Using Sql_Command As New SqlCommand(SqlString, sql_conn)
                Using Sql_Reader As SqlDataReader = Sql_Command.ExecuteReader()
                    Dim i As Integer = 1
                    While Sql_Reader.Read()
                        l.Add(New CascadingDropDownNameValue(Sql_Reader("uom"), i))
                        i = i + 1
                    End While

                End Using
            End Using
        End Using

        Return l.ToArray()
    End Function

End Class
