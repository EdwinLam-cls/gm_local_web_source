﻿'---------------------------------------------------------------------------- 
'程式功能	曆法函數 
'備註說明	需配合 String_Func.vb 使用 
'設計人員	 
'修改人員 
'備註說明 
'---------------------------------------------------------------------------- 
Imports System
Imports System.Globalization

Public Class Calendar_Func
    Public Function GetHeavenlyStem(ByVal iStem As Integer) As String
        Dim HeavenlyStem As String = "甲乙丙丁戊己庚辛壬癸"
        ' 10 天干 
        Dim cStem As String = ""

        If iStem < 1 OrElse iStem > 10 Then
            cStem = "？"
        Else
            cStem = HeavenlyStem.Substring(iStem - 1, 1)
        End If

        Return cStem
    End Function

    Public Function GetEarthlyBranch(ByVal iBranch As Integer) As String
        Dim EarthlyBranch As String = "子丑寅卯辰巳午未申酉戌亥"
        ' 12 地支 
        Dim cBranch As String = ""

        If iBranch < 1 OrElse iBranch > 12 Then
            cBranch = "？"
        Else
            cBranch = EarthlyBranch.Substring(iBranch - 1, 1)
        End If

        Return cBranch
    End Function

    Public Function GetLunarZodiac(ByVal iNum As Integer) As String
        Dim LunarZodiac As String = "鼠牛虎兔龍蛇馬羊猴雞狗豬"
        Dim cZodiac As String = ""

        If iNum < 1 OrElse iNum > 12 Then
            cZodiac = "？"
        Else
            cZodiac = LunarZodiac.Substring(iNum - 1, 1)
        End If

        Return cZodiac
    End Function

    Public Function GetChMonth(ByVal iMonth As Integer) As String
        Dim sfc As New String_Func()

        Dim cMonth As String = ""

        If iMonth < 1 OrElse iMonth > 12 Then
            cMonth = "？"
        Else
            If iMonth = 1 Then
                cMonth = "正"
            Else
                cMonth = sfc.GetChNumber(iMonth)

                If iMonth < 11 Then
                    cMonth = sfc.Right(cMonth, 1)
                Else
                    cMonth = sfc.Right(cMonth, 2)
                End If
            End If
        End If

        Return cMonth
    End Function

    Public Function GetChDay(ByVal iDay As Integer) As String
        Dim sfc As New String_Func()

        Dim cDay As String = ""

        If iDay < 1 OrElse iDay > 31 Then
            cDay = "不明"
        Else
            cDay = sfc.GetChNumber(CULng(iDay))

            If iDay < 10 Then
                cDay = "初" & sfc.Left(cDay, 1)
            ElseIf iDay = 10 Then
                cDay = "初十"
            ElseIf iDay > 10 AndAlso iDay < 20 Then
                cDay = cDay.Replace("一十", "十")
            ElseIf iDay > 20 AndAlso iDay < 30 Then
                cDay = cDay.Replace("二十", "廿")
            ElseIf iDay > 30 Then
                cDay = cDay.Replace("三十", "卅")
            End If
        End If

        Return cDay
    End Function

    Public Function GetChHour(ByVal iHour As Integer) As String
        Dim cHour As String = ""

        If iHour < 0 OrElse iHour > 23 Then
            cHour = "不明"
        Else
            If iHour >= 23 Then
                iHour = 1
            Else
                iHour = Int((iHour + 1) / 2) + 1
            End If

            cHour = GetEarthlyBranch(iHour)
        End If

        Return cHour
    End Function

    Public Function GetChNHour(ByVal iHour As Integer) As String
        Dim sfc As New String_Func()

        Dim cHour As String = ""

        If iHour < 0 OrElse iHour > 23 Then
            cHour = "？"
        Else
            cHour = sfc.GetChNumber(iHour).Replace("一十", "十")
        End If

        Return cHour
    End Function

    Public Function GetLunarDate() As String
        Return GetLunarDate(DateTime.Now, "yMdhms")
    End Function

	Public Function GetLunarDate(ByVal mtype As String) As String
		Return GetLunarDate(DateTime.Now, mtype)
	End Function

	Public Function GetLunarDate(ByVal mdate As DateTime) As String
		Return GetLunarDate(mdate, "yMdhms")
	End Function

	Public Function GetLunarDate(ByVal mdate As DateTime, ByVal mtype As String) As String
		Dim sfc As New String_Func()
		Dim tlc As New TaiwanLunisolarCalendar()

		Dim ldate As String = ""
		Dim LunarYear As Integer = 0				' 農曆年 
		Dim LunarMonth As Integer = 0				' 月份 
		Dim LunarDay As Integer = 0					' 日期 
		Dim LunarHour As Integer = 0				' 時 
		Dim LunarMin As Integer = 0					' 分 
		Dim LunarSec As Integer = 0					' 秒 
		Dim LeapMonth As Integer = 0				' 潤月 
		LunarYear = tlc.GetSexagenaryYear(mdate)

		' 取得西元年 
		' 農曆年
		If mtype.Contains("y") Then
			ldate = GetHeavenlyStem(tlc.GetCelestialStem(LunarYear))
			' 年 - 天干 
			' 年 - 地支 
			ldate &= GetEarthlyBranch(tlc.GetTerrestrialBranch(LunarYear)) & "年"
		End If

		' 農曆月
		If mtype.Contains("M") Then
			LunarMonth = tlc.GetMonth(mdate)
			' 取得月份 
			LeapMonth = tlc.GetLeapMonth(tlc.GetYear(mdate))
			' 取得潤月 
			If LeapMonth > 0 Then
				' 當年有潤月，月份會出現13個月，在潤月之後的月分要減一。 
				If LeapMonth = LunarMonth Then
					ldate &= "閏" & GetChMonth(LeapMonth - 1) & "月"
				ElseIf LunarMonth > LeapMonth Then
					ldate &= GetChMonth(LunarMonth - 1) & "月"
				Else
					ldate &= GetChMonth(LunarMonth) & "月"
				End If
			Else
				ldate &= GetChMonth(LunarMonth) & "月"
			End If
		End If

		' 農曆日
		If mtype.Contains("d") Then
			LunarDay = tlc.GetDayOfMonth(mdate)

			ldate &= GetChDay(LunarDay) & "日"
		End If

		' 農曆時 (子、丑...)
		If mtype.Contains("H") Then
			LunarHour = tlc.GetHour(mdate)
			ldate &= GetChHour(LunarHour) & "時"
		End If

		' 中文數字時 (五、十一...)
		If mtype.Contains("h") Then
			LunarHour = tlc.GetHour(mdate)
			ldate &= GetChNHour(LunarHour) & "時"
		End If

		' 農曆分
		If mtype.Contains("m") Then
			LunarMin = tlc.GetMinute(mdate)
			ldate &= sfc.GetChNumber(CULng(LunarMin)).Replace("一十", "十") & "分"
		End If

		' 農曆秒
		If mtype.Contains("s") Then
			LunarSec = tlc.GetSecond(mdate)
			If LunarSec = 0 Then
				ldate &= "整"
			Else
				ldate &= sfc.GetChNumber(CULng(LunarSec)).Replace("一十", "十") & "秒"
			End If
		End If

		Return ldate
	End Function

    Public Function GetDateLunarZodiac() As String
        Return GetDateLunarZodiac(DateTime.Now)
    End Function

	Public Function GetDateLunarZodiac(ByVal mdate As DateTime) As String
		Dim tlc As New TaiwanLunisolarCalendar()

		Return GetLunarZodiac(tlc.GetTerrestrialBranch(tlc.GetSexagenaryYear(mdate)))
	End Function

    Public Function GetConstellation() As String
        Return GetConstellation(DateTime.Now)
    End Function

	Public Function GetConstellation(ByVal mDate As DateTime) As String
		Dim cConstellation As String = ""
		Dim Constellation As String() = {"牡羊座", "金牛座", "雙子座", "巨蟹座", "獅子座", "處女座", _
		"天秤座", "天蠍座", "射手座", "魔羯座", "寶瓶座", "雙魚座", _
		"不明"}
		Dim mCnt As Integer = 0

		mCnt = mDate.Month * 100 + mDate.Day
		If mCnt > 320 AndAlso mCnt < 421 Then
			cConstellation = Constellation(0)
		ElseIf mCnt > 420 AndAlso mCnt < 522 Then
			cConstellation = Constellation(1)
		ElseIf mCnt > 521 AndAlso mCnt < 622 Then
			cConstellation = Constellation(2)
		ElseIf mCnt > 621 AndAlso mCnt < 724 Then
			cConstellation = Constellation(3)
		ElseIf mCnt > 723 AndAlso mCnt < 824 Then
			cConstellation = Constellation(4)
		ElseIf mCnt > 823 AndAlso mCnt < 924 Then
			cConstellation = Constellation(5)
		ElseIf mCnt > 923 AndAlso mCnt < 1024 Then
			cConstellation = Constellation(6)
		ElseIf mCnt > 1023 AndAlso mCnt < 1123 Then
			cConstellation = Constellation(7)
		ElseIf mCnt > 1123 AndAlso mCnt < 1223 Then
			cConstellation = Constellation(8)
		ElseIf mCnt > 1222 OrElse mCnt < 121 Then
			cConstellation = Constellation(9)
		ElseIf mCnt > 120 AndAlso mCnt < 220 Then
			cConstellation = Constellation(10)
		ElseIf mCnt > 219 AndAlso mCnt < 321 Then
			cConstellation = Constellation(11)
		Else
			cConstellation = Constellation(12)
		End If

		Return cConstellation
	End Function
End Class