﻿'---------------------------------------------------------------------------- 
'專案名稱 公用函數 
'程式功能 字串加密解密處理 
'設計人員	 
'修改人員 
'備註說明 
'---------------------------------------------------------------------------- 
Imports System

Public Class Decoder

#Region "原始對應字串"
	Private std_str As String = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ!@$^*()_+-/|`:{}[]"
#End Region

#Region "密碼查表字串"
	Private en_str As String() = New String(9) { _
	 "{}[]16Z!@$7CDY^*ESJKTU)_+-V(W8F2GHIL345MNOPQR90ABX/|`:", _
	 "$7GHIL3{QR9BX/|}[16Z!@CDTU(Y^*ESJ:K)_+-VW8F2]45MNOP`0A", _
	 "FGP`0A2]45M$7HIL3{QR916^*ESJ:K)_+-VWBX/|}[8NOZ!@CDTU(Y", _
	 "8F2]HI45MN`0$7DT/|}[16Z!XCU(Y^@L3{QR9B*EGASJ:K)_+-VWOP", _
	 "XCWU(Y^6Z!EGA5MS8F2]HIB*OP4N`0$7DT/|}[1J:K)_+-V@L3{QR9", _
	 "`0$7DT/|}[1XCW8QR9U(Y^F2]HIB*OP45MNJ:K)_+-V@L3{6Z!EGAS", _
	 "NJ:K)_+-V@L3`0$8QR]HIB*O9U(Y^F245M{6Z!EGAPS7DT/|}[1XCW", _
	 "^F24NR]HIB*OJ:K)_+-V@L3`0$8Q9U(S7D1XCWT/|}[Y5M{6Z!EGAP", _
	 "CWT/|}[Y5M{6Z24N$8Q9U(S7D1XA!EG^FPR]HIB*OJ:K)_+-V@L3`0", _
	 "T3`09U(S7|}[Y5M8QG^FPR]HIB*OJ:K)_2/LCW{6Z4N$+-V@D1XA!E"}
#End Region

#Region "補英數字16位元的字元（英數字轉成16位元時，只有兩位，不足之處以此補足）、由起始用字串"
	Private st_str As String = "acdhjklmnopqrstuvwxy"
#End Region

#Region "每7字插入的字元"
	Private in_str As String = "befgiz"
#End Region

#Region "密碼表順序字元"
	Private dc_sort As String = "LXQPAZDBCH"
#End Region

#Region "EnCode() 字串加密"
	'函數功能 EnCode() 字串加密 
	'傳入參數 scode string 原始字串 
	'傳回數值 ecode string 加密字串 
	'備註說明 
	Public Function EnCode(ByVal scode As String) As String
		Dim ecode As String = "", tmpstr As String = ""
		Dim rnd As New Random()
		Dim hcnt As Integer = 0, encnt As Integer = 0, cnt As Integer = 0, incnt As Integer = 0, zcnt As Integer = 0

		'取得起始要加入的字串數( 1 ~ 3 個) 
		hcnt = rnd.Next(1, 4)

		'隨機由起始字串中取得字元 
		For cnt = 0 To hcnt - 1
			encnt = rnd.Next(0, 20)
			ecode &= st_str.Substring(encnt, 1)
		Next

		'隨機決定要用那一個密碼表 
		encnt = rnd.Next(0, 10)
		ecode &= dc_sort.Substring(encnt, 1)

		'轉換原始字串成為16進位字元 
		cnt = 0
		For Each cdata As Char In scode
			zcnt = cnt Mod 54
			cnt += 1

			'每7字插入字元 
			If cnt Mod 7 = 0 Then
				hcnt = rnd.Next(0, 6)
				ecode &= in_str.Substring(hcnt, 1)

				If rnd.Next(0, 10) > 4 Then
					'決定是否要加第二個字元 
					hcnt = rnd.Next(0, 6)
					ecode &= in_str.Substring(hcnt, 1)
				End If
			End If

			tmpstr = String.Format("{0:X2}", AscW(cdata))
			' 不足4個字元，補2個字元 
			If tmpstr.Length < 4 Then
				hcnt = rnd.Next(0, 20)
				ecode &= st_str.Substring(hcnt, 1)

				hcnt = rnd.Next(0, 20)
				ecode &= st_str.Substring(hcnt, 1)
			End If

			For Each mchar As Char In tmpstr
				incnt = std_str.IndexOf(mchar)
				incnt = (incnt + zcnt) Mod 54

				ecode &= en_str(encnt).Substring(incnt, 1)
			Next
		Next
		Return ecode
	End Function
#End Region

#Region "DeCode() 字串解密"
	'函數功能 DeCode() 字串解密 
	'傳入參數 ecode string 加密字串 
	'傳回數值 scode string 原始字串 
	'備註說明 
	Public Function DeCode(ByVal ecode As String) As String
		Dim scode As String = "", tmpstr As String = "", workstr As String = "", codestr As String = ""
		Dim hcnt As Integer = 0, cnt As Integer = 0, encnt As Integer = 0, xcnt As Integer = 0, ycnt As Integer = 0, zcnt As Integer = 0

		'判斷起始字元位置 
		If ecode.Length > 3 Then
			tmpstr = ecode.Substring(0, 4)
			For Each mchar As Char In tmpstr
				cnt += 1
				If st_str.IndexOf(mchar) < 0 AndAlso hcnt = 0 Then
					hcnt = cnt
					'取得資料起始位置 
					'取得使用那一組密碼表 
					encnt = dc_sort.IndexOf(mchar)
				End If
			Next

			If hcnt <> 0 AndAlso encnt > -1 AndAlso encnt < 10 Then
				'確定有找到正確的密碼表 

				'取得去除起始字位的加密資料 
				tmpstr = ecode.Substring(hcnt)

				For Each mchar As Char In in_str
					tmpstr = tmpstr.Replace(mchar.ToString(), "")
				Next

				'每個字為4個字元組成，故取4的整數，以預防解碼錯誤 
				hcnt = Convert.ToInt32(tmpstr.Length / 4) * 4

				ycnt = 0

				For cnt = 0 To hcnt - 1 Step 4
					zcnt = ycnt Mod 54
					codestr = ""
					workstr = tmpstr.Substring(cnt, 4)

					For Each mchar As Char In workstr
						If st_str.IndexOf(mchar) < 0 Then
							xcnt = en_str(encnt).IndexOf(mchar)
							If xcnt > -1 Then
								If xcnt >= zcnt Then
									xcnt = xcnt - zcnt
								Else
									xcnt = 54 + xcnt - zcnt
								End If
								codestr &= std_str.Substring(xcnt, 1)
							End If
						End If
					Next

					'解碼後不為正確的16進位數字，代表加密字串有誤，中斷解碼，以空白字串回應 
					Try
						scode &= Convert.ToChar(Convert.ToInt32("0x" & codestr, 16))
					Catch
						scode = ""
						cnt = hcnt
					End Try
					ycnt += 1
				Next
			End If
		End If

		Return scode
	End Function
#End Region
End Class