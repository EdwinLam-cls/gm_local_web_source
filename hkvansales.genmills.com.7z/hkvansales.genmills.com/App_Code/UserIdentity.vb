﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text

Public Class UserIdentity
    Public Sub New()

        Me.New(System.Threading.Thread.CurrentPrincipal.Identity.Name.ToUpper())
    End Sub

    Public Sub New(ByVal logonCd__1 As String)
        m_LogonCd = logonCd__1
        Dim parts As String() = logonCd__1.Split("\"c)
        If parts.Length > 1 Then
            m_Domain = parts(0)
            m_AccountName = parts(1)
        Else
            m_Domain = Nothing
            m_AccountName = logonCd__1
        End If
    End Sub

    Public ReadOnly Property LogonCd As String
        Get
            Return m_LogonCd
        End Get
    End Property
    Private m_LogonCd As String
    Public ReadOnly Property Domain As String
        Get
            Return m_Domain
        End Get
    End Property
    Private m_Domain As String
    Public ReadOnly Property AccountName As String
        Get
            Return m_AccountName
        End Get
    End Property
    Private m_AccountName As String

    Public Shared Function CreateFromCurrentUser() As UserIdentity
        Return New UserIdentity()
    End Function
End Class