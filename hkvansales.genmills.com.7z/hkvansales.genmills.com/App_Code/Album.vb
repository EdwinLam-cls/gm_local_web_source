﻿'---------------------------------------------------------------------------- 
'專案名稱	公用函數 
'程式功能	相簿相關定義 
'設計人員	 
'修改人員 
'備註說明 
'---------------------------------------------------------------------------- 

Public Class Album
	' 根目錄 
	Public Shared ReadOnly Property Root() As String
		Get
			Return "../3002/Files/"
		End Get
	End Property
End Class