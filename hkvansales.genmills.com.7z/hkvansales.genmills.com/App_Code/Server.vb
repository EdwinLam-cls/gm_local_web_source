﻿Public Class Server
    Public Shared ReadOnly Property CurrentEnvironment As String
        Get
            Try
                Dim val As String = System.Environment.GetEnvironmentVariable("GMIServer").ToUpper()
                Select Case val
                    Case "DEVELOPER", "DEVELOPMENT", "QA", "PRODUCTION"
                        Return val
                    Case Else
                        'When the environment variable GMIServer is not defined, default it to DEVELOPER
                        Return "DEVELOPER"
                End Select
            Catch ex As NullReferenceException
                ' If there is no environment variable GMIServer, the GetEnvironmentVariable() will 
                ' throw an exception. Just return "DEVELOPER" here.
                Return "DEVELOPER"
            End Try

        End Get
    End Property
End Class
