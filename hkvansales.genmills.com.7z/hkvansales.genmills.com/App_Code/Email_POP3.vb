﻿'---------------------------------------------------------------------------- 
'專案名稱	公用函數
'程式功能	POP3 通訊處理 (Post Office Protocol Version 3)
'設計人員	 
'修改人員 
'備註說明   屬性與函數的說明請參閱第 19 章
'---------------------------------------------------------------------------- 
Imports System.Collections.Generic
Imports System.IO
Imports System.Net
Imports System.Net.Sockets
Imports System.Text
Imports System.Web

Public Class Email_POP3
	Private _pop3_host As String = ""			' POP3 主機名稱 例：msa.hinet.net
	Private _pop3_port As Integer = 110			' POP3 通訊埠 例：110
	Private _pop3_id As String = ""				' 登入帳號
	Private _pop3_pw As String = ""				' 登入密碼
	Private _pop3_client As New TcpClient()		' TCP/IP Client 元件
	Private _netstream As NetworkStream
	Private _st_reader As StreamReader
	Private _st_writer As StreamWriter

	Private _st_line As String = ""				' 最後一行接收到的資料
	Private _st_read_flag As Boolean			' 最後讀取的狀態 true : 正確， false : 失敗
	Private _mail_num As Integer = -1			' 郵件數量 (-1 表示尚未執行 Stat 指令或是執行失敗)
	Private _mail_total As Integer = -1			' 郵件大小 (-1 表示尚未執行 Stat 指令或是執行失敗)
	Private _mail_size As Integer()				' 個別郵件大小
	Private _mail_uidl As String()				' 個別郵件的唯一識別碼

    Public Property POP3_Host() As String
        Get
            Return _pop3_host
        End Get
        Set(ByVal value As String)
            Me._pop3_host = value
        End Set
    End Property

    Public Property POP3_Port() As Integer
        Get
            Return _pop3_port
        End Get
        Set(ByVal value As Integer)
            Me._pop3_port = value
        End Set
    End Property

    Public Property POP3_ID() As String
        Get
            Return _pop3_id
        End Get
        Set(ByVal value As String)
            Me._pop3_id = value
        End Set
    End Property

    Public Property POP3_PW() As String
        Get
            Return _pop3_pw
        End Get
        Set(ByVal value As String)
            Me._pop3_pw = value
        End Set
    End Property

    Public ReadOnly Property Get_Line() As String
        Get
            Return _st_line
        End Get
    End Property

    Public ReadOnly Property Get_Read_Flag() As Boolean
        Get
            Return _st_read_flag
        End Get
    End Property

    Public ReadOnly Property Mail_Num() As Integer
        Get
            Return _mail_num
        End Get
    End Property

    Public ReadOnly Property Mail_Total() As Integer
        Get
            Return _mail_total
        End Get
    End Property

    Public Function Mail_Size(ByVal aCnt As Integer) As Integer
        Dim intSize As Integer = -2

        If _mail_size IsNot Nothing Then
            If _mail_size.Length > aCnt AndAlso aCnt > -1 Then
                intSize = _mail_size(aCnt)
            Else
                intSize = -1
            End If
        End If

        Return intSize
    End Function

    Public Function Mail_UIDL(ByVal aCnt As Integer) As String
        Dim strUIDL As String = "-2"

        If _mail_uidl IsNot Nothing Then
            If _mail_uidl.Length > aCnt AndAlso aCnt > -1 Then
                strUIDL = _mail_uidl(aCnt)
            Else
                strUIDL = "-1"
            End If
        End If

        Return strUIDL
    End Function

    Public Function Connect() As Integer
        Dim ckint As Integer = 1

        If _pop3_host = "" Then
            ckint = -2
        ElseIf _pop3_port < 1 OrElse _pop3_port > 65534 Then
            ckint = -3
        End If

        If ckint = 1 Then
            Try
                _pop3_client.Connect(_pop3_host, _pop3_port)
                If _pop3_client.Connected Then
                    _netstream = _pop3_client.GetStream()
                    _st_reader = New StreamReader(_netstream, Encoding.Default)
                    _st_writer = New StreamWriter(_netstream, Encoding.Default)
                    If POP3_Receive() Then
                        ckint = 0
                    Else
                        _netstream.Close()
                        _st_reader.Close()
                        _st_writer.Close()
                        _pop3_client.Close()

                        _netstream.Dispose()
                        _st_reader.Dispose()
                        _st_writer.Dispose()
                        ckint = -4
                    End If
                Else
                    ckint = -1
                End If
            Catch
                ckint = -1
            End Try
        End If
        Return ckint
    End Function

    Public Function Login() As Integer
        Dim ckint As Integer = 0

        If _pop3_client.Connected Then
            If POP3_Send("USER " & _pop3_id) Then
                If Not POP3_Receive() Then
                    ckint = -2
                End If
            Else
                ckint = -2
            End If

            If ckint = 0 Then
                If POP3_Send("PASS " & _pop3_pw) Then
                    If Not POP3_Receive() Then
                        ckint = -3
                    End If
                Else
                    ckint = -3
                End If
            End If
        Else
            ckint = -1
        End If

        Return ckint
    End Function

    Public Function POP3_Read() As String
        Try
            _st_line = _st_reader.ReadLine()
            _st_read_flag = True
        Catch
            _st_line = ""
            _st_read_flag = False
        End Try

        Return _st_line
    End Function

    Public Function POP3_Receive() As Boolean
        Dim ckbool As Boolean = False
        Dim str_read As String = ""

        Try
            str_read = _st_reader.ReadLine()
            If str_read.Substring(0, 3) = "+OK" Then
                ckbool = True
            Else
                ckbool = False
            End If
        Catch
            ckbool = False
        End Try

        _st_line = str_read
        _st_read_flag = ckbool

        Return ckbool
    End Function

    Public Function POP3_Send(ByVal str_send As String) As Boolean
        Dim ckbool As Boolean = False

        Try
            ' 將串流中的資料清空
            _st_reader.DiscardBufferedData()

            _st_writer.WriteLine(str_send)
            _st_writer.Flush()

            ckbool = True
        Catch
            ckbool = False
        End Try

        Return ckbool
    End Function

    Public Function POP3_Send_Check(ByVal str_send As String) As Boolean
        Dim ckbool As Boolean = False
        Dim str_read As String = ""

        Try
            ' 將串流中的資料清空
            _st_reader.DiscardBufferedData()

            _st_writer.WriteLine(str_send)
            _st_writer.Flush()

            str_read = _st_reader.ReadLine()
            If str_read.Substring(0, 3) = "+OK" Then
                ckbool = True
            Else
                ckbool = False
            End If
        Catch
            ckbool = False
        End Try

        _st_line = str_read
        _st_read_flag = ckbool

        Return ckbool
    End Function

    Public Function Stat() As Integer
        Dim ckint As Integer = 0, mailnum As Integer = 0, mailsize As Integer = 0

        If _pop3_client.Connected Then
            If POP3_Send("STAT") Then
                If POP3_Receive() Then
                    ckint = 0
                Else
                    ckint = -2
                End If
            Else
                ckint = -2
            End If
        Else
            ckint = -1
        End If

        ' 資料存入 _mail_num 及 _mail_total
        If ckint < 0 Then
            _mail_num = -1
            _mail_total = -1
        Else
            Dim strtmp As String() = _st_line.Split(" "c)

            If Integer.TryParse(strtmp(1), mailnum) Then
                _mail_num = mailnum
            Else
                _mail_num = -1
                ckint = -3
            End If

            If Integer.TryParse(strtmp(2), mailsize) Then
                _mail_total = mailsize
            Else
                _mail_total = -1
                ckint = -3
            End If
            strtmp = Nothing
        End If

        Return ckint
    End Function

    Public Function ListAll() As Integer
        Dim ckint As Integer = 0, icnt As Integer = 0, mcnt As Integer = 0, lcnt As Integer = 0, scnt As Integer = 0
        Dim tmpstr As String = "", recstr As String = ""

        _mail_size = Nothing

        If _pop3_client.Connected Then
            If POP3_Send("LIST") Then
                If POP3_Receive() Then
                    Try
                        Do
                            tmpstr = _st_reader.ReadLine()

                            If tmpstr.Substring(0, 1) <> "." Then
                                recstr &= tmpstr & "#"
                            End If
                        Loop While tmpstr <> "."
                    Catch
                        ckint = -13
                    End Try

                    If ckint = 0 AndAlso recstr.Length > 0 Then
                        recstr = recstr.Substring(0, recstr.Length - 1)

                        Dim _tmp_size As String() = recstr.Split("#"c)

                        mcnt = _tmp_size.Length

                        ' 填入數值
                        _mail_size = New Integer(mcnt - 1) {}

                        For icnt = 0 To mcnt - 1
                            lcnt = _tmp_size(icnt).IndexOf(" ") + 1
                            scnt = 0

                            If Integer.TryParse(_tmp_size(icnt).Substring(lcnt, _tmp_size(icnt).Length - lcnt), scnt) Then
                                _mail_size(icnt) = scnt
                            Else
                                _mail_size(icnt) = 0
                            End If
                        Next
                        _tmp_size = Nothing
                    End If
                Else
                    ckint = -12
                End If
            Else
                ckint = -12
            End If
        Else
            ckint = -1
        End If

        If ckint < 0 Then
            _mail_size = Nothing
        End If

        Return ckint
    End Function

    Public Function UIDLAll() As Integer
        Dim ckint As Integer = 0, icnt As Integer = 0, lcnt As Integer = 0, mcnt As Integer = 0
        Dim recstr As String = "", tmpstr As String = ""

        If _pop3_client.Connected Then
            If POP3_Send("UIDL") Then
                If POP3_Receive() Then
                    Try
                        Do
                            tmpstr = _st_reader.ReadLine()

                            If tmpstr.Substring(0, 1) <> "." Then
                                recstr &= tmpstr & "#"
                            End If
                        Loop While tmpstr <> "."
                    Catch
                        ckint = -24
                    End Try

                    If ckint = 0 AndAlso recstr.Length > 0 Then
                        recstr = recstr.Substring(0, recstr.Length - 1)

                        _mail_uidl = recstr.Split("#"c)

                        mcnt = _mail_uidl.Length

                        ' 去除編號
                        For icnt = 0 To mcnt - 1
                            lcnt = _mail_uidl(icnt).IndexOf(" ") + 1
                            _mail_uidl(icnt) = _mail_uidl(icnt).Substring(lcnt, _mail_uidl(icnt).Length - lcnt)
                        Next
                    End If
                Else
                    ckint = -22
                End If
            Else
                ckint = -22
            End If
        Else
            ckint = -1
        End If

        If ckint < 0 Then
            _mail_uidl = Nothing
        End If

        Return ckint
    End Function

    Public Function StatAll() As Integer
        Dim ckint As Integer = 0
        ckint = Stat()

        ' 取得個別郵件的大小及UIDL
        If ckint = 0 AndAlso _mail_num > 0 Then
            ckint = ListAll()
        End If

        ' 取得個別郵件的UIDL
        If ckint = 0 AndAlso _mail_num > 0 Then
            ckint = UIDLAll()
        End If

        Return ckint
    End Function

    Public Function Dele_Mail(ByVal mail_cnt As Integer) As Boolean
        Return POP3_Send_Check("DELE " & mail_cnt.ToString())
    End Function

    Public Function Dele_UIDL(ByVal sUIDL As String) As Integer
        Dim tmpstr As String = "", mUIDL As String = ""
        Dim icnt As Integer = 0, mcnt As Integer = 0, ckint As Integer = -9

        If _pop3_client.Connected Then
            If POP3_Send_Check("UIDL") Then
                Do
                    Try
                        tmpstr = _st_reader.ReadLine()

                        icnt = tmpstr.IndexOf(" ")
                        If icnt > 0 Then
                            mUIDL = tmpstr.Substring(icnt + 1)

                            ' 核對識別碼是否相符
                            If mUIDL = sUIDL Then
                                Integer.TryParse(tmpstr.Substring(0, icnt), mcnt)
                                ' 取得臨時郵件序號
                                If mcnt > 0 Then
                                    ' 刪除郵件
                                    If Dele_Mail(mcnt) Then
                                        ckint = 0
                                    Else
                                        ckint = -5
                                    End If
                                Else
                                    ckint = -4
                                End If

                                tmpstr = "."
                            End If
                        End If
                    Catch
                        tmpstr = "."
                        ckint = -3
                    End Try
                Loop While tmpstr <> "."

                ' 將串流中的資料清空
                _st_reader.DiscardBufferedData()
            Else
                ckint = -2
            End If
        Else
            ckint = -1
        End If

        Return ckint
    End Function

    Public Function Get_Topic(ByVal mail_cnt As Integer) As String
        Dim sb_topic As New StringBuilder()
        Dim tmpstr As String = ""

        If _pop3_client.Connected Then
            ' 將串流中的資料清空
            _st_reader.DiscardBufferedData()

            If POP3_Send_Check("TOP " & mail_cnt.ToString() & " 0") Then
                Try
                    Do
                        sb_topic.Append(tmpstr)
                        tmpstr = _st_reader.ReadLine() & vbCr & vbLf
                    Loop While tmpstr <> "." & vbCr & vbLf
                Catch
                    sb_topic.Append(vbCr & vbLf & "<Error 3>")
                End Try
            Else
                sb_topic.Append(vbCr & vbLf & "<Error 2>")
            End If

            ' 將串流中的資料清空
            _st_reader.DiscardBufferedData()
        Else
            sb_topic.Append(vbCr & vbLf & "<Error 1>")
        End If

        Return sb_topic.ToString()
    End Function

    Public Function Get_Mail(ByVal mail_cnt As Integer) As String
        Dim sb_content As New StringBuilder()
        Dim tmpstr As String = ""

        If _pop3_client.Connected Then
            ' 將串流中的資料清空
            _st_reader.DiscardBufferedData()

            If POP3_Send_Check("RETR " & mail_cnt.ToString()) Then
                Try
                    Do
                        sb_content.Append(tmpstr)
                        tmpstr = _st_reader.ReadLine() & vbCr & vbLf
                    Loop While tmpstr <> "." & vbCr & vbLf
                Catch
                    sb_content.Append(vbCr & vbLf & "<Error 3>")
                End Try
            Else
                sb_content.Append(vbCr & vbLf & "<Error 2>")
            End If

            ' 將串流中的資料清空
            _st_reader.DiscardBufferedData()
        Else
            sb_content.Append(vbCr & vbLf & "<Error 1>")
        End If

        Return sb_content.ToString()
    End Function

    Public Function Close() As Boolean
        Dim ckbool As Boolean = False

        Try
            If _pop3_client.Connected Then
                ' 送出結束指令
                POP3_Send("QUIT")

                ' 釋放相關資源
                _st_reader.Close()
                _st_reader.Dispose()

                _st_writer.Close()
                _st_writer.Dispose()

                _netstream.Close()
                _netstream.Dispose()

                _pop3_client.Close()
                _pop3_client = Nothing

                ckbool = True
            End If
        Catch
            ckbool = False
        End Try

        Return ckbool
    End Function
End Class
