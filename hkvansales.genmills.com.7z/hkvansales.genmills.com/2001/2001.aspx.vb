﻿
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration

Partial Class _2001
    Inherits System.Web.UI.Page

    Public strCommonSql As String = "from item_master i inner join item_group_master g on i.materialGroupCode = g.materialGroupCode inner join price_list p on i.materialCode = p.materialCode inner join customer_master c on p.custNo = c.custNo "

    Private Property dtNameList() As DataTable
        Get
            Return ViewState("dt")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dt") = value
        End Set
    End Property



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Check_Power("2001", True)

            rdbView.Visible = False


            SetInterface("Edit")
        End If
        Literal1.Text = ""




    End Sub

    Protected Sub btnChoose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnChoose.Click
        dtNameList = RetrieveActiveTable(True)
        Dim strDate As String = txtDate.Text.Trim
        Dim intCount As Integer = BindRecordDetail(strDate)
        If intCount = 0 Then
            clearAll()
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('" & "No records on the selected date" & "')", True)
        End If
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim strMsg As String = ""

        If gv_products.Rows.Count = 0 Then
            strMsg = "No records to be saved!"
        End If

        If strMsg = "" Then
            InsertToDB(strMsg)
        End If

        If strMsg = "" Then
            strMsg = "Record saved successfully!"
        End If
        If strMsg.Contains("'") Then
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('" & strMsg.Substring(0, 20).Replace("'", "") & "')", True)
        Else
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('" & strMsg & "')", True)
        End If



    End Sub

    Protected Sub btnConfirmCopy_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmCopy.Click



        Dim strDate As String = txtDate.Text.Trim
        If Not RecordExist(strDate) Then
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('" & "No records on the selected date" & "')", True)
            Exit Sub
        End If





        Dim strDateTo As String = txtDateTo.Text.Trim
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim tran As SqlClient.SqlTransaction
        Dim da As New SqlDataAdapter
        Dim cmd As New SqlCommand()
        Dim strMsg As String
        conn.Open()
        tran = conn.BeginTransaction

        Dim strSql As String = "delete from attendance where convert(varchar(10),work_date,111) = @to_date "
        strSql &= " Insert into attendance(vanCode, work_date,sales1,sales2,sales3,remark,is_active,update_date,update_by)"
        strSql &= " select vanCode, @to_date,sales1,sales2,sales3,remark,is_active, @update_date,@update_by from attendance where convert(varchar(10),work_date,111) = @from_date "

        Try
            cmd = New SqlCommand(strSql, conn)
            cmd.Transaction = tran
            cmd.CommandType = CommandType.Text

            cmd.Parameters.Add("@from_date", SqlDbType.NVarChar, 100)
            cmd.Parameters("@from_date").Value = strDate

            cmd.Parameters.Add("@to_date", SqlDbType.NVarChar, 100)
            cmd.Parameters("@to_date").Value = strDateTo

            cmd.Parameters.Add("@update_date", SqlDbType.DateTime, 100)
            cmd.Parameters("@update_date").Value = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID")))

            cmd.Parameters.Add("@update_by", SqlDbType.NVarChar, 100)
            cmd.Parameters("@update_by").Value = Session("mg_name")



            cmd.CommandTimeout = 0
            cmd.ExecuteNonQuery()
            tran.Commit()
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('" & "Copy Success!" & "')", True)
            conn.Close()
        Catch ex As Exception
            tran.Rollback()
            strMsg = ex.Message
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('" & strMsg & "')", True)
        End Try
    End Sub

    Protected Sub GridView1_RowDeleting(ByVal sender As Object, ByVal e As System.EventArgs)

        'Dim ddlSales1 As DropDownList = CType(sender.parent.FindControl("ddlSales1"), DropDownList)
        'Dim ddlSales2 As DropDownList = CType(sender.Parent.FindControl("ddlSales2"), DropDownList)
        'Dim ddlSales3 As DropDownList = CType(sender.parent.FindControl("ddlSales3"), DropDownList)

        'Dim str1 As String = ddlSales1.SelectedValue.Trim
        'Dim str2 As String = ddlSales2.SelectedValue.Trim
        'Dim str3 As String = ddlSales3.SelectedValue.Trim

        'If str1 <> "" Then
        '    dtNameList = AddToDT(dtNameList, str1)
        '    dtNameList.AcceptChanges()
        'End If

        'If str2 <> "" Then
        '    dtNameList = AddToDT(dtNameList, str2)
        '    dtNameList.AcceptChanges()
        'End If

        'If str3 <> "" Then
        '    dtNameList = AddToDT(dtNameList, str3)
        '    dtNameList.AcceptChanges()
        'End If
        'BindAllDropdownList(dtNameList)
        'Dim txtRemark As TextBox = CType(sender.parent.FindControl("txtRemark"), TextBox)
        'txtRemark.Text = ""
        'ddlSales1.ToolTip = ""
        'ddlSales1.SelectedValue = ""
        'ddlSales2.ToolTip = ""
        'ddlSales2.SelectedValue = ""
        'ddlSales3.ToolTip = ""
        'ddlSales3.SelectedValue = ""


    End Sub

    Protected Sub gv_products_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs) Handles gv_products.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then
            'Dim lb As LinkButton = DirectCast(e.Row.Cells(4).Controls(0), LinkButton)
            'lb.OnClientClick = "return confirm('Confirm to delete record?')"
        End If

    End Sub

    Protected Sub rdbView_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdbView.CheckedChanged
        SetInterface("View")
    End Sub

    Protected Sub rdbEdit_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdbEdit.CheckedChanged
        SetInterface("Edit")
    End Sub

    Protected Sub rdbCopy_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdbCopy.CheckedChanged
        SetInterface("Copy")
    End Sub

    Protected Sub btnClear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClear.Click
        clearAll()


    End Sub

    Private Sub clearAll()
        dtNameList = RetrieveActiveTable()
        Dim dt As DataTable = dtNameList
        For Each row As GridViewRow In gv_products.Rows
            Dim ddlSales1 As DropDownList = CType(row.FindControl("ddlSales1"), DropDownList)
            Dim ddlSales2 As DropDownList = CType(row.FindControl("ddlSales2"), DropDownList)
            Dim ddlSales3 As DropDownList = CType(row.FindControl("ddlSales3"), DropDownList)
            Dim txtRemark As TextBox = CType(row.FindControl("txtRemark"), TextBox)

            txtRemark.Text = ""
            ddlSales1.ToolTip = ""
            ddlSales1.DataSource = dt
            ddlSales1.DataTextField = "mg_id"
            ddlSales1.DataValueField = "mg_id"
            ddlSales1.DataBind()

            ddlSales2.ToolTip = ""
            ddlSales2.DataSource = dt
            ddlSales2.DataTextField = "mg_id"
            ddlSales2.DataValueField = "mg_id"
            ddlSales2.DataBind()

            ddlSales3.ToolTip = ""
            ddlSales3.DataSource = dt
            ddlSales3.DataTextField = "mg_id"
            ddlSales3.DataValueField = "mg_id"
            ddlSales3.DataBind()

        Next
    End Sub

    Private Function RecordExist(ByVal strDate As String) As Boolean
        Dim Sql_Conn1 As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim SqlString1 As String = "select vanCode,sales1,sales2,sales3,remark from attendance where convert(varchar(10),work_date,111) = '" & strDate & "'"
        Dim Sql_Command1 As New SqlCommand(SqlString1, Sql_Conn1)
        Dim dt As New DataTable
        Dim sqlDa As New SqlDataAdapter(Sql_Command1)
        sqlDa.Fill(dt)
        sqlDa.Dispose()
        If dt.Rows.Count = 0 Then
            Return False
        Else
            Return True
        End If
    End Function

    Private Function BindRecordDetail(ByVal strDate As String) As Integer

        Dim Sql_Conn1 As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim SqlString1 As String = "select vanCode,sales1,sales2,sales3,remark from attendance where convert(varchar(10),work_date,111) = '" & strDate & "'"
        Dim Sql_Command1 As New SqlCommand(SqlString1, Sql_Conn1)
        Dim dt As New DataTable
        Dim sqlDa As New SqlDataAdapter(Sql_Command1)
        sqlDa.Fill(dt)
        sqlDa.Dispose()


        Dim dtAvailable As New DataTable
        SqlString1 = " select mg_id from Manager where is_active ='1' and mg_id not in ( " & _
        " select sales1 from attendance where convert(varchar(10),work_date,111) = '" & strDate & "'" & _
          " union select sales2 from attendance where convert(varchar(10),work_date,111) = '" & strDate & "'" & _
            " union select sales3 from attendance where convert(varchar(10),work_date,111) = '" & strDate & "'" & _
        ") union select '' order by mg_id  "

        Sql_Command1.CommandText = SqlString1
        Dim sqlDaAp As New SqlDataAdapter(Sql_Command1)
        sqlDaAp.Fill(dtAvailable)
        sqlDaAp.Dispose()
        Sql_Command1.Dispose()
        dtNameList = dtAvailable


        If dt.Rows.Count > 0 Then
            For Each row As GridViewRow In gv_products.Rows
                Dim ddlSales1 As DropDownList = CType(row.FindControl("ddlSales1"), DropDownList)
                Dim ddlSales2 As DropDownList = CType(row.FindControl("ddlSales2"), DropDownList)
                Dim ddlSales3 As DropDownList = CType(row.FindControl("ddlSales3"), DropDownList)
                Dim lblVanCode As Label = CType(row.FindControl("lblVanCode"), Label)
                Dim txtRemark As TextBox = CType(row.FindControl("txtRemark"), TextBox)

                For i = 0 To dt.Rows.Count - 1
                    If lblVanCode.Text = dt.Rows.Item(i)("vanCode").ToString Then
                        Dim str1 As String = dt.Rows.Item(i)("sales1").ToString
                        Dim str2 As String = dt.Rows.Item(i)("sales2").ToString
                        Dim str3 As String = dt.Rows.Item(i)("sales3").ToString

                        ddlSales1.DataSource = AddToDT(dtAvailable, str1)
                        ddlSales1.DataTextField = "mg_id"
                        ddlSales1.DataValueField = "mg_id"
                        ddlSales1.DataBind()
                        ddlSales1.SelectedValue = str1
                        ddlSales1.ToolTip = str1

                        ddlSales2.DataSource = AddToDT(dtAvailable, str2)
                        ddlSales2.DataTextField = "mg_id"
                        ddlSales2.DataValueField = "mg_id"
                        ddlSales2.DataBind()
                        ddlSales2.SelectedValue = str2
                        ddlSales2.ToolTip = str2

                        ddlSales3.DataSource = AddToDT(dtAvailable, str3)
                        ddlSales3.DataTextField = "mg_id"
                        ddlSales3.DataValueField = "mg_id"
                        ddlSales3.DataBind()
                        ddlSales3.SelectedValue = str3
                        ddlSales3.ToolTip = str3

                        txtRemark.Text = dt.Rows.Item(i)("remark").ToString
                        Exit For
                    End If
                Next
            Next
        End If
        Return dt.Rows.Count

    End Function

    Private Sub SetInterface(ByVal strMode As String)
        If strMode = "View" Then
            Func_table.FindControl("tr2").Visible = False

            Func_table2.Visible = False
            btnChoose.Visible = True
            rdbEdit.Checked = False
            rdbCopy.Checked = False
            gv_products.Visible = True
            lblWorkDate.Text = "Working Date"

            Dim bol As Boolean = False
            For Each row As GridViewRow In gv_products.Rows
                Dim ddlSales1 As DropDownList = CType(row.FindControl("ddlSales1"), DropDownList)
                Dim ddlSales2 As DropDownList = CType(row.FindControl("ddlSales2"), DropDownList)
                Dim ddlSales3 As DropDownList = CType(row.FindControl("ddlSales3"), DropDownList)
                Dim txtRemark As TextBox = CType(row.FindControl("txtRemark"), TextBox)
                ddlSales1.Enabled = bol
                ddlSales2.Enabled = bol
                ddlSales3.Enabled = bol
                txtRemark.ReadOnly = Not bol
            Next
        End If

        If strMode = "Edit" Then
            Func_table.FindControl("tr2").Visible = False
            ' gv_products.Columns(5).Visible = True
            Func_table2.Visible = True
            btnChoose.Visible = True
            rdbView.Checked = False
            rdbCopy.Checked = False
            gv_products.Visible = True
            lblWorkDate.Text = "Working Date"

            dtNameList = RetrieveActiveTable()
            BindAllDropdownList(dtNameList)
        End If

        If strMode = "Copy" Then
            rdbView.Checked = False
            rdbEdit.Checked = False
            Func_table.FindControl("tr2").Visible = True

            Func_table2.Visible = False
            btnChoose.Visible = False
            gv_products.DataSource = Nothing
            gv_products.DataBind()
            gv_products.Visible = False
            lblWorkDate.Text = "Copy Attendence From"

        End If

    End Sub

    Private Function ValidateAdd(ByRef strMsg As String) As Boolean
        'If rdbNew.Checked = True Then
        '    If txtPONo.Text.Trim = "" Then
        '        strMsg &= "PO No. should not be empty!\n"
        '    End If
        'End If


        'If txtShippingDate.Text.Trim = "" Then
        '    strMsg &= "Ship Date should not be empty!\n"
        'End If

        'Try
        '    Dim dtmtest As DateTime = CDate(txtShippingDate.Text.Trim)
        '    If dtmtest < Now Then
        '        strMsg &= "Ship Date should be a future date!\n"
        '    End If
        'Catch ex As Exception
        '    strMsg &= "Ship Date should be [yyyy/MM/dd]!\n"
        'End Try


        Dim dt As DataTable = Session("IN")




        If strMsg <> "" Then
            Return False
        End If


        Return True
    End Function

#Region "DB methods"
    Private Function RetrieveActiveTable(Optional ByVal bolFullTable As Boolean = False) As DataTable
        Dim Sql_Conn1 As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim SqlString1 As String = "select mg_id from Manager where is_active ='1' union select '' order by mg_id "

        If (bolFullTable) Then
            SqlString1 = "select mg_id from Manager where 1=1 union select '' order by mg_id "
        End If


        Dim Sql_Command1 As New SqlCommand(SqlString1, Sql_Conn1)
        Sql_Conn1.Open()

        Dim dt As DataTable = getNewDatatable()

        Dim Sql_Reader1 As SqlDataReader = Sql_Command1.ExecuteReader()

        dt.Load(Sql_Reader1)

        Sql_Reader1.Close()
        Sql_Conn1.Close()


        Return dt
    End Function

    Private Sub InsertToDB(ByRef strMsg As String)
        Dim isSucceed As Boolean = False
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim tran As SqlClient.SqlTransaction
        Dim da As New SqlDataAdapter
        Dim cmd As New SqlCommand()

        Try
            cmd.Connection = conn
            cmd.Connection.Open()
            tran = conn.BeginTransaction
            cmd.Transaction = tran

            Dim strDate As String = txtDate.Text
            Dim strUser_id As String = Session("mg_name")
            Dim dtmCr_date As DateTime = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID")))

            isSucceed = Me.DeleteDetail(cmd, conn, tran, strMsg, strDate)

            If (isSucceed) Then
                For Each row As GridViewRow In gv_products.Rows
                    Dim ddlSales1 As DropDownList = CType(row.FindControl("ddlSales1"), DropDownList)
                    Dim ddlSales2 As DropDownList = CType(row.FindControl("ddlSales2"), DropDownList)
                    Dim ddlSales3 As DropDownList = CType(row.FindControl("ddlSales3"), DropDownList)
                    Dim lblVanCode As Label = CType(row.FindControl("lblVanCode"), Label)
                    Dim txtRemark As TextBox = CType(row.FindControl("txtRemark"), TextBox)
                    Dim strIs_active As String = "1"
                    Dim str1 As String = ddlSales1.Text.Trim
                    Dim str2 As String = ddlSales2.Text.Trim
                    Dim str3 As String = ddlSales3.Text.Trim
                    Dim strVanCode As String = lblVanCode.Text.Trim
                    Dim strRemark As String = txtRemark.Text.Trim
                    If str1 = "" And str2 = "" And str3 = "" Then
                        strIs_active = ""
                    End If
                    isSucceed = Me.InsertDetail(cmd, conn, tran, strVanCode, strDate, str1, str2, str3, strRemark, strIs_active, dtmCr_date, strUser_id, strMsg)
                Next
            End If
            If (isSucceed) Then
                tran.Commit()
                isSucceed = True
            Else
                tran.Rollback()
                isSucceed = False
            End If
        Catch ex As Exception
            tran.Rollback()
            strMsg = ex.Message
        Finally
            cmd.Dispose()
            da.Dispose()
            conn.Dispose()
        End Try


    End Sub

    Private Function InsertDetail(ByVal cmd As SqlCommand, ByVal conn As SqlConnection, ByVal tran As SqlTransaction, ByVal strVanCode As String, ByVal strDate As String, ByVal str1 As String, ByVal str2 As String, ByVal str3 As String, ByVal strRemark As String, ByVal strIs_active As String, ByVal dtmUpdateDate As DateTime, ByVal strUpdateBy As String, ByRef strMsg As String) As Boolean
        Dim isSucceed As Boolean = False

        Dim da As New SqlDataAdapter
        Dim strSql As String = "Insert into attendance(vanCode, work_date,sales1,sales2,sales3,remark,is_active,update_date,update_by)"
        strSql &= " values(@vanCode, @work_date,@sales1,@sales2,@sales3,@remark,@is_active,@update_date,@update_by)"

        Try
            cmd = New SqlCommand(strSql, conn)
            cmd.Transaction = tran
            cmd.CommandType = CommandType.Text

            cmd.Parameters.Add("@vanCode", SqlDbType.NVarChar, 100)
            cmd.Parameters("@vanCode").Value = strVanCode

            cmd.Parameters.Add("@work_date", SqlDbType.DateTime, 100)
            cmd.Parameters("@work_date").Value = CDate(strDate)

            cmd.Parameters.Add("@sales1", SqlDbType.NVarChar, 100)
            cmd.Parameters("@sales1").Value = str1

            cmd.Parameters.Add("@sales2", SqlDbType.NVarChar, 100)
            cmd.Parameters("@sales2").Value = str2

            cmd.Parameters.Add("@sales3", SqlDbType.NVarChar, 100)
            cmd.Parameters("@sales3").Value = str3

            cmd.Parameters.Add("@remark", SqlDbType.NVarChar, 200)
            cmd.Parameters("@remark").Value = strRemark

            cmd.Parameters.Add("@is_active", SqlDbType.NVarChar, 100)
            cmd.Parameters("@is_active").Value = strIs_active


            cmd.Parameters.Add("@update_date", SqlDbType.DateTime, 100)
            cmd.Parameters("@update_date").Value = dtmUpdateDate

            cmd.Parameters.Add("@update_by", SqlDbType.NVarChar, 100)
            cmd.Parameters("@update_by").Value = strUpdateBy



            cmd.CommandTimeout = 0
            cmd.ExecuteNonQuery()
            isSucceed = True
        Catch ex As Exception
            strMsg = ex.Message
            isSucceed = False
        End Try

        Return isSucceed
    End Function

    Private Function DeleteDetail(ByVal cmd As SqlCommand, ByVal conn As SqlConnection, ByVal tran As SqlTransaction, _
                                                        ByRef strMsg As String, ByVal strDate As String) As Boolean
        Dim isSucceed As Boolean = False
        Dim strSql As String = "delete from attendance where convert(varchar(10),work_date,111) = @work_date"
        Try
            cmd = New SqlCommand(strSql, conn)
            cmd.Transaction = tran
            cmd.CommandType = CommandType.Text

            cmd.Parameters.Add("@work_date", SqlDbType.NVarChar, 100)
            cmd.Parameters("@work_date").Value = strDate

            cmd.CommandTimeout = 0
            cmd.ExecuteNonQuery()
            isSucceed = True
        Catch ex As Exception
            strMsg = ex.Message
            isSucceed = False
        End Try

        Return isSucceed

    End Function
#End Region

#Region "Interface Events"

    Private Sub BindAllDropdownList(ByVal dt As DataTable)
        For Each row As GridViewRow In gv_products.Rows
            Dim ddlSales1 As DropDownList = CType(row.FindControl("ddlSales1"), DropDownList)
            Dim ddlSales2 As DropDownList = CType(row.FindControl("ddlSales2"), DropDownList)
            Dim ddlSales3 As DropDownList = CType(row.FindControl("ddlSales3"), DropDownList)

            Dim str1 As String = ddlSales1.Text
            Dim str2 As String = ddlSales2.Text
            Dim str3 As String = ddlSales3.Text

            If str1 = "" Then
                ddlSales1.DataSource = dt
                ddlSales1.DataTextField = "mg_id"
                ddlSales1.DataValueField = "mg_id"
                ddlSales1.DataBind()
            Else
                ddlSales1.DataSource = AddToDT(dt, str1)
                ddlSales1.DataTextField = "mg_id"
                ddlSales1.DataValueField = "mg_id"
                ddlSales1.DataBind()
                ddlSales1.SelectedValue = str1
            End If

            If str2 = "" Then
                ddlSales2.DataSource = dt
                ddlSales2.DataTextField = "mg_id"
                ddlSales2.DataValueField = "mg_id"
                ddlSales2.DataBind()
            Else
                ddlSales2.DataSource = AddToDT(dt, str2)
                ddlSales2.DataTextField = "mg_id"
                ddlSales2.DataValueField = "mg_id"
                ddlSales2.DataBind()
                ddlSales2.SelectedValue = str2
            End If

            If str3 = "" Then
                ddlSales3.DataSource = dt
                ddlSales3.DataTextField = "mg_id"
                ddlSales3.DataValueField = "mg_id"
                ddlSales3.DataBind()
            Else
                ddlSales3.DataSource = AddToDT(dt, str3)
                ddlSales3.DataTextField = "mg_id"
                ddlSales3.DataValueField = "mg_id"
                ddlSales3.DataBind()
                ddlSales3.SelectedValue = str3
            End If


        Next



    End Sub

    Protected Sub ChangeSelectedIndex(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddl As DropDownList = CType(sender, DropDownList)
        Dim str As String = ddl.Text.Trim
        Dim preStr As String = ddl.ToolTip
        Dim dt As DataTable = dtNameList


        If preStr <> "" Then
            dt = AddToDT(dt, preStr)
            dt.AcceptChanges()
        End If

        If str <> "" Then
            dt = RemoveFromDT(dt, str)
            dt.AcceptChanges()
        End If

        BindAllDropdownList(dt)
        dtNameList = dt
        ddl.ToolTip = str
    End Sub

    Private Function AddToDT(ByVal dt As DataTable, ByVal str As String) As DataTable
        Dim dtNew As DataTable = dt.Copy



        Dim dtRow As DataRow = dtNew.NewRow()
        dtRow("mg_id") = str
        dtNew.Rows.Add(dtRow)
        dtNew.AcceptChanges()
        Dim dv As DataView = dtNew.DefaultView
        dv.Sort = "mg_id"

        Dim dtResult As DataTable = dv.ToTable
        Return dtResult
    End Function

    Private Function RemoveFromDT(ByVal dt As DataTable, ByVal str As String) As DataTable
        Dim dtNew As DataTable = dt.Copy


        For Each dr As DataRow In dtNew.Rows
            If dr("mg_id") = str Then
                dr.Delete()
            End If
        Next
        dtNew.AcceptChanges()
        Return dtNew
    End Function
#End Region

#Region "Customized Functions/Methods"
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Private Function getNewDatatable() As DataTable
        Dim dt As New DataTable
        dt.Columns.Add("mg_id", GetType(System.String))
        Return dt
    End Function
#End Region



End Class

