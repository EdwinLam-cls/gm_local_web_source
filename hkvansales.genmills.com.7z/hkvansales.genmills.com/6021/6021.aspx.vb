﻿Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration
Imports System.Data.Common
Imports System.Array

Partial Class _6021_6021

    Inherits System.Web.UI.Page

    Dim gErr As String = ""


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Session.LCID = 2057
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim tmpstr As String = ""

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("6021", True)
            btn_search.Visible = False
            ddlMaterialGroup.AutoPostBack = True
        End If

        'Dim xVal() As String = {"1", "2", "3"}
        'Dim yval() As Double = {12, 34, 45}

        'Chart1.Series("Series1").Points.DataBindXY(xVal, yval)

        'System.Diagnostics.Debug.WriteLine(SqlMainSource.SelectCommand)

        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""

    End Sub


    ' Check_Power() 檢查使用者權限並存入登入紀錄
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub ddlMaterialGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlMaterialGroup.SelectedIndexChanged
        Dim strMaterialGroup As String = Me.ddlMaterialGroup.Text.Trim
        BindMaterial(strMaterialGroup)

    End Sub

    Private Sub BindMaterial(ByVal strMaterialGroup As String)
        Dim strSql As String = "select distinct i.chiDesc from item_group_master g inner join item_master i on g.materialGroupCode = i.materialGroupCode where 1=1"
        If strMaterialGroup <> "" Then
            strSql += " and g.chiDesc = '" & strMaterialGroup & "'"
        End If
        strSql += " order by i.chiDesc"
        dsMaterial.SelectCommand = strSql
        ddlMaterial.DataBind()

    End Sub
End Class
