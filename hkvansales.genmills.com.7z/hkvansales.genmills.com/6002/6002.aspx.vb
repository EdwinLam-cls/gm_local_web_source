﻿Imports System.Data
Imports Common_Func


Partial Class _6002_6002
    Inherits System.Web.UI.Page

    Dim gErr As String = ""



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim tmpstr As String = ""

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("6002", True)
            ddlReason.Enabled = False
        End If

        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""


    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub btn_Search_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Search.Click
        Dim strSql As String = getStrSql()
        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()
    End Sub


    Protected Sub gv_custmaster_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gv_custmaster.PageIndexChanging
        Dim strSql As String = getStrSql()
        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()
    End Sub

    Protected Sub gv_custmaster_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gv_custmaster.Sorting
        Dim strSql As String = getStrSql()
        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()
    End Sub

    Private Function getStrSql() As String
        Dim strVanId As String = Me.ddlVanID.Text.Trim
        Dim strRefDocNo As String = Me.txtRefDocNo.Text.Trim
        Dim strDateFrom As String = Me.txtDateFrom.Text
        Dim strDateTo As String = Me.txtDateTo.Text
        Dim strCustGroup As String = Me.ddlCustomerGroup.Text.Trim
        Dim strCustomer As String = Me.ddlCustomer.Text.Trim
        Dim strMaterialGroup As String = ""
        Dim strMaterial As String = Me.ddlMaterial.Text.Trim
        Dim strTxnType As String = Me.ddlTxnType.Text.Trim
        Dim strStatus As String = Me.ddlStatus.Text.Trim
        Dim strReason As String = Me.ddlReason.Text.Trim
        'Dim strInv As String = Me.ddlRefNo.Text.Trim

        Dim iLen As Integer
        If lstMaterialGroup.Items.Count > 0 Then
            For Each i In lstMaterialGroup.Items
                strMaterialGroup &= "'" & i.ToString & "' ,"
            Next
            iLen = strMaterialGroup.Length
            strMaterialGroup = strMaterialGroup.Substring(0, iLen - 1)
        End If


        Dim strSql As String = "select top 3000 h.txn_type, h.refDocNo, h.van_id,h.cr_date,h.custNo,c.name1,d.materialCode,i.chiDesc,"
        strSql += "g.chiDesc as ItemGroup, d.grossPrice,d.netPrice,d.quantity,(d.netPrice*d.quantity) total, h.remark, h.invno from txn_header h inner join txn_detail d on h.refDocNo = d.refDocNo "
        strSql += "inner join customer_master c on h.custNo = c.custNo inner join item_master i on d.materialCode = i.materialCode "
        strSql += "inner join item_group_master g on g.materialGroupCode = i.materialGroupCode inner join customer_group_master cg on c.custGroup = cg.custGroup "
        strSql += "where 1=1 and h.isVoid <>'1' "

        If strVanId <> "" Then
            strSql += " and right(h.van_id,3) = '" & Right(strVanId, 3) & "'"
        End If

        If strRefDocNo <> "" Then
            strSql += " and h.refDocNo like '%" & strRefDocNo & "%'"
        End If

        If strDateFrom <> "" Then
            strSql += " and convert(varchar(10),h.cr_date,111) >= '" & strDateFrom & "'"
        End If

        If strDateTo <> "" Then
            strSql += " and convert(varchar(10),h.cr_date,111) <= '" & strDateTo & "'"
        End If

        If strCustomer <> "" Then
            strSql += " and c.name1 = '" & strCustomer & "'"
        End If

        If strCustGroup <> "" Then
            strSql += " and cg.name1 = '" & strCustGroup & "'"
        End If

        If strMaterial <> "" Then
            strSql += " and i.chiDesc = '" & strMaterial & "' "
        End If

        If strMaterialGroup <> "" Then
            strSql += " and g.chiDesc in (" & strMaterialGroup & ") "
        End If

        If strTxnType <> "" Then
            strSql += " and h.txn_type = '" & strTxnType & "' "
        End If

        If strStatus = "p" Then
            strSql += " and d.quantity >=0 "
        ElseIf strStatus = "n" Then
            strSql += " and d.quantity < 0 "
        End If

        If strReason <> "" Then
            strSql += " and h.remark = '" & strReason & "'"
        End If

        ''If strInv <> "A" Then
        '    If strInv = "H" Then
        '        strSql += " and isnull(h.invno,'') <> ''  "
        '    Else
        '        strSql += " and isnull(h.invno,'') = ''  "
        '    End If


        'End If

            Return strSql
    End Function

    'Protected Sub ddlMaterialGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlMaterialGroup.SelectedIndexChanged
    '    Dim strMaterialGroup As String = Me.ddlMaterialGroup.Text.Trim
    '    BindMaterial(strMaterialGroup)

    'End Sub

    Private Sub BindMaterial(ByVal strMaterialGroup As String)
        Dim strSql As String = "select distinct i.chiDesc from item_group_master g inner join item_master i on g.materialGroupCode = i.materialGroupCode where 1=1"
        If strMaterialGroup <> "" Then
            strSql += " and g.chiDesc = '" & strMaterialGroup & "'"
        End If
        strSql += " union select '' order by i.chiDesc"
        dsMaterial.SelectCommand = strSql
        ddlMaterial.DataBind()

    End Sub

    Protected Sub ddlCustomerGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCustomerGroup.SelectedIndexChanged
        Dim strCustomerGroup As String = Me.ddlCustomerGroup.Text.Trim
        BindCustomer(strCustomerGroup)
    End Sub

    Private Sub BindCustomer(ByVal strCustomerGroup As String)

        Dim strSql As String = "select distinct c.name1 from customer_master c inner join customer_group_master g on g.custGroup = c.custGroup where 1=1"
        If (strCustomerGroup) <> "" Then
            strSql += " and g.Name1 = '" & strCustomerGroup.Replace("'", "''") & "'"
        End If
        strSql += " union select '' order by name1"
        dsCustomer.SelectCommand = strSql
        ddlCustomer.DataBind()

    End Sub


    Protected Sub ddlTxnType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlTxnType.SelectedIndexChanged
        If ddlTxnType.Text = "Sales" Or ddlTxnType.Text = "Free" Or ddlTxnType.Text = "" Then
            ddlReason.Text = ""
            ddlReason.Enabled = False
        Else
            ddlReason.Enabled = True
        End If
    End Sub

    Protected Sub btnAdd_Click()
        Dim sText As String = lstMaterialGroup_Ava.SelectedValue
        Dim it() As String
        ReDim it(0)
        it(0) = ""

        For Each item In lstMaterialGroup_Ava.Items
            If item.Selected = True Then
                sText = item.ToString
                ReDim Preserve it(UBound(it) + 1)
                it(UBound(it)) = sText

                lstMaterialGroup.Items.Add(sText)
                'lstMaterialGroup_Ava.Items.Remove(sText)
            End If
        Next

        For Each i In it
            If i.ToString <> "" Then
                lstMaterialGroup_Ava.Items.Remove(i.ToString)
            End If
        Next

    End Sub

    Protected Sub btnRemove_Click()
        Dim sText As String = lstMaterialGroup.SelectedValue
        Dim it() As String
        ReDim it(0)
        it(0) = ""
        For Each item In lstMaterialGroup.Items
            If item.Selected = True Then
                sText = item.ToString
                lstMaterialGroup_Ava.Items.Add(sText)
                ReDim Preserve it(UBound(it) + 1)
                it(UBound(it)) = sText
                'lstMaterialGroup.Items.Remove(sText)
            End If
        Next

        For Each i In it
            If i.ToString <> "" Then
                lstMaterialGroup.Items.Remove(i.ToString)
            End If
        Next

    End Sub

    Protected Sub btnRemoveAll_Click()
        Dim sText As String
        Dim iCount As Integer = lstMaterialGroup.Items.Count

        Do Until iCount = 0
            lstMaterialGroup.Items(0).Selected = True
            sText = lstMaterialGroup.SelectedValue
            lstMaterialGroup_Ava.Items.Add(sText)
            lstMaterialGroup.Items.Remove(sText)
            iCount = iCount - 1
        Loop

    End Sub
    Protected Sub btnAddAll_Click()
        Dim sText As String
        Dim iCount As Integer = lstMaterialGroup_Ava.Items.Count

        Do Until iCount = 0
            lstMaterialGroup_Ava.Items(0).Selected = True
            sText = lstMaterialGroup_Ava.SelectedValue
            lstMaterialGroup.Items.Add(sText)
            lstMaterialGroup_Ava.Items.Remove(sText)
            iCount = iCount - 1
        Loop

    End Sub
End Class
