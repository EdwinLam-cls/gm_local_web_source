﻿Imports System.Data
Imports Common_Func


Partial Class _6001_6001
    Inherits System.Web.UI.Page

    Dim gErr As String = ""



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim tmpstr As String = ""

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("6001", True)

        End If

        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""

      
    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub btn_Search_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Search.Click
        Dim strSql As String = getStrSql()
        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()
    End Sub


    Protected Sub gv_custmaster_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gv_custmaster.PageIndexChanging
        Dim strSql As String = getStrSql()
        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()
    End Sub

    Protected Sub gv_custmaster_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gv_custmaster.Sorting
        Dim strSql As String = getStrSql()
        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()
    End Sub

    Private Function getStrSql() As String
        Dim strMaterial As String = Me.ddlMaterial.Text.Trim
        Dim strVanId As String = Me.ddlVanID.Text.Trim
        Dim strMaterialGroup As String = Me.ddlMaterialGroup.Text.Trim


        Dim strSql As String = "select b.*, i.engDesc ,i.chiDesc, g.chiDesc as gchiDesc from item_balance b inner join item_master i on i.materialCode = b.materialCode inner join item_group_master g on i.materialGroupCode = g.materialGroupCode  where 1=1 "
        If strMaterial <> "" Then
            strSql += " and i.chiDesc = '" & strMaterial & "' "
        End If

        If strMaterialGroup <> "" Then
            strSql += " and g.chiDesc = '" & strMaterialGroup & "'"
        End If


        If strVanId <> "" Then
            strSql += " and right(vanCode,3) = '" & Right(strVanId, 3) & "'"
        End If
        Return strSql
    End Function

    Protected Sub ddlMaterialGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlMaterialGroup.SelectedIndexChanged
        Dim strMaterialGroup As String = Me.ddlMaterialGroup.Text.Trim
        BindMaterial(strMaterialGroup)

    End Sub

    Private Sub BindMaterial(ByVal strMaterialGroup As String)
        Dim strSql As String = "select distinct i.chiDesc from item_group_master g inner join item_master i on g.materialGroupCode = i.materialGroupCode where 1=1"
        If strMaterialGroup <> "" Then
            strSql += " and g.chiDesc = '" & strMaterialGroup & "'"
        End If
        strSql += " union select '' order by i.chiDesc"
        dsMaterial.SelectCommand = strSql
        ddlMaterial.DataBind()

    End Sub
End Class
