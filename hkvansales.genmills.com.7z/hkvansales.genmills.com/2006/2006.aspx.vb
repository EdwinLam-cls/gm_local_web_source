﻿'---------------------------------------------------------------------------- 
'程式功能	Delivery Master Maintenance
'---------------------------------------------------------------------------- 
Imports System.Data.SqlClient
Imports System
Imports System.Collections.Generic
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO
Imports System.Data.OleDb
Imports System.Data


Partial Class _2006_2006
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()

            ' 檢查使用者權限並存入登入紀錄。 
            Check_Power("2006", True)

            '接受下一頁返回時的舊查詢條件" 
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid"), ckint) Then
                    gv_delivery_master.PageIndex = ckint
                Else
                    lb_pageid.Text = "0"
                End If
            End If


        End If
        Chk_Filter()
    
    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            'If cfc.Check_Power(Session("stk_code").ToString(), Session("stk_desc").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub gv_delivery_master_PageIndexChanged(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        lb_pageid.Text = e.NewPageIndex()
    End Sub

    Protected Sub Btn_Set_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Btn_Set.Click
        ' 檢查查詢條件是否改變 
        Chk_Filter()
    End Sub

    ' 檢查查詢條件是否改變 
    Private Sub Chk_Filter()
        Dim cfc As New Common_Func()

        Dim ckint As Integer = 0
        Dim tmpstr As String = ""



        Dim strSearchCode = cfc.CleanSQL(ddlCode.selectedValue)
        Dim strSearchDesc = cfc.CleanSQL(txtDescription.Text)

        Dim strSql As String = "select * from item_group_desc_master "
        strSql += " where 1=1 "
        If strSearchCode.trim <> "" Then
            strSql += " and [id] ='" & strSearchCode.Trim & "' "
        End If
        If strSearchDesc.Trim <> "" Then
            strSql += " and [chiDesc] like '%" & strSearchDesc.Trim & "%'"
        End If
        dsDeliverMaster.SelectCommand = strSql




        gv_delivery_master.DataBind()
        If gv_delivery_master.PageCount - 1 < gv_delivery_master.PageIndex Then
            gv_delivery_master.PageIndex = gv_delivery_master.PageCount
            gv_delivery_master.DataBind()
        End If

        lb_pageid.Text = gv_delivery_master.PageIndex.ToString()
    End Sub

    Protected Sub btnUpload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpload.Click
        Dim connectionString As String = ""
        If FileUpload1.HasFile Then


            Dim fileName As String = Path.GetFileName(FileUpload1.PostedFile.FileName)
            Dim fileExtension As String = Path.GetExtension(FileUpload1.PostedFile.FileName)
            Dim fileLocation As String = Server.MapPath("~/ExcelExport/" & fileName)
            FileUpload1.SaveAs(fileLocation)
            If fileExtension = ".xls" Then
                'connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=1"""
                connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 12.0;HDR=Yes"""

            ElseIf fileExtension = ".xlsx" Then
                connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 12.0;HDR=Yes;IMEX=1"""
            Else
                ClientScript.RegisterStartupScript(Me.GetType(), "errorScript", "alert('" & "Please select MS Excel file" & "');", True)
                Exit Sub
            End If

            gv_delivery_master.datasource = Nothing


            Dim con As New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand()
            cmd.CommandType = System.Data.CommandType.Text
            cmd.Connection = con
            Dim dAdapter As New OleDbDataAdapter(cmd)
            Dim dtExcelRecords As New DataTable()
            Try
                con.Open()

                Dim dtExcelSheetName As DataTable = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)
                Dim getExcelSheetName As String = ""
                If dtExcelSheetName.Rows.Count > 1 Then
                    getExcelSheetName = dtExcelSheetName.Rows(1)("Table_Name").ToString()
                Else
                    getExcelSheetName = "Sheet1$"
                End If
                cmd.CommandText = "SELECT * FROM [" & getExcelSheetName & "] where id is not null   "
                'cmd.CommandText = "SELECT * FROM [" & getExcelSheetName & "] where isnull(id,'') <> '' "
                dAdapter.SelectCommand = cmd
                dAdapter.Fill(dtExcelRecords)
                con.Close()

                dtExcelRecords.Columns(0).ColumnName = "id"
                dtExcelRecords.Columns(1).ColumnName = "chiDesc"


                If InsertExceltoDB(dtExcelRecords) = True Then
                    ddlCode.DataBind()
                    gv_delivery_master.DataBind()
                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Upload Completed');", True)
                Else
                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Upload Failed. Please choose the right file');", True)
                End If

            Catch ex As Exception
                ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Upload Failed. Please choose the right file');", True)

            End Try

        Else
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Please select an excel file');", True)
        End If
    End Sub

    Private Function InsertExceltoDB(ByVal dt As DataTable) As Boolean



        Dim isSucceed As Boolean = False
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim tran As SqlTransaction
        Dim da As New SqlDataAdapter
        Dim cmd As New SqlCommand()
        cmd.Connection = conn
        cmd.Connection.Open()
        tran = conn.BeginTransaction
        cmd.Transaction = tran
        Dim strSql As String
        Try
            strSql = " delete from item_group_desc_master "
            cmd = New SqlCommand(strSql, conn)
            cmd.Transaction = tran
            cmd.ExecuteNonQuery()

            strSql = "Insert Into [item_group_desc_master] (id,chiDesc) " & _
                         " values(@id, @chiDesc) "
            cmd = New SqlCommand(strSql, conn)

            cmd.CommandType = CommandType.Text
            cmd.Transaction = tran
            cmd.Parameters.Add("@id", SqlDbType.NVarChar, 500, "id")
            cmd.Parameters.Add("@chiDesc", SqlDbType.NVarChar, 500, "chiDesc")

            For Each dr As DataRow In dt.Rows
                dr.SetAdded()
            Next
            da.InsertCommand = cmd
            da.Update(dt)

            tran.Commit()
            isSucceed = True
        Catch ex As Exception
            tran.Rollback()
            isSucceed = False
        End Try

        cmd.Dispose()
        da.Dispose()
        conn.Dispose()
        Return isSucceed
    End Function

    Protected Sub btnExport_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnExport.Click
        Try
            Dim dtCurrentRecord As New DataTable
            Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)

            Dim strSql As String = "Select id, chiDesc from item_group_desc_master"
            Dim cmd As New SqlCommand(strSql, conn)
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            Dim da As New SqlDataAdapter(cmd)
            cmd.Connection.Open()
            da.Fill(dtCurrentRecord)
            cmd.Connection.Close()
            cmd.Dispose()
            da.Dispose()
            dtCurrentRecord.TableName = "CategoryName"
            Dim strFileName As String = "ExcelExport_" + "_" + Format(TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))), "yyyyMMddhhmmss") + ".xls"
            Dim strNewPath As String = HttpContext.Current.Server.MapPath("~/ExcelExport/" & strFileName)
            Dim strPhysicalPath As String = HttpContext.Current.Server.MapPath("~/ExcelExport/" & strFileName)

            If Not IO.Directory.Exists(HttpContext.Current.Server.MapPath("~/ExcelExport")) Then
                IO.Directory.CreateDirectory(HttpContext.Current.Server.MapPath("~/ExcelExport"))
            End If

            Dim connectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & strNewPath & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=2"""
            connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & strNewPath & ";Extended Properties=""Excel 12.0 xml;Mode=ReadWrite;HDR=Yes"""

            InsertDBtoExcel(dtCurrentRecord, connectionString)

            HttpContext.Current.Response.Clear()
            Response.WriteFile(strNewPath)
            Dim httpHeader As String = "attachment;filename=" + "CategoryName" + ".xlsx"
            HttpContext.Current.Response.ContentType = "application/vnd.ms-excel"
            HttpContext.Current.Response.AppendHeader("Content-Disposition", httpHeader)
            HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.Unicode


            HttpContext.Current.Response.Flush()
            System.IO.File.Delete(strNewPath)
            HttpContext.Current.Response.End()
        Catch ex As Exception
            'Response.Write(ex.Message)
        End Try


    End Sub

    Private Sub InsertDBtoExcel(ByVal dt As DataTable, ByVal connectionString As String)
        Dim strTable As String = ""
        strTable = "CREATE TABLE [" & dt.TableName & "]("

        Dim j As Integer = 0
        For j = 0 To dt.Columns.Count - 1
            Dim dCol As DataColumn
            dCol = dt.Columns(j)

            strTable &= " [" & dCol.ColumnName & "] nvarchar(255) , "


        Next
        strTable = strTable.Substring(0, strTable.Length - 2)
        strTable &= ")"

        Dim conn As OleDbConnection = New OleDbConnection(connectionString)
        Dim cmd As New OleDbCommand(strTable, conn)
        conn.Open()
        cmd.ExecuteNonQuery()
        conn.Close()
        cmd.Dispose()


        Dim strInsert As String
        strInsert = "Insert Into " & dt.TableName & " Values ("
        For k As Integer = 0 To dt.Columns.Count - 1
            strInsert &= "@" & dt.Columns(k).ColumnName & " , "
        Next
        strInsert = strInsert.Substring(0, strInsert.Length - 2)
        strInsert &= ")"

        conn.Open()
        For j = 0 To dt.Rows.Count - 1
            Dim cmd2 As New OleDbCommand(strInsert, conn)
            For k As Integer = 0 To dt.Columns.Count - 1

                cmd2.Parameters.AddWithValue("@" & dt.Columns(k).ColumnName.ToString(), dt.Rows(j)(k).ToString())

            Next

            cmd2.ExecuteNonQuery()
            cmd2.Parameters.Clear()
            cmd2.Dispose()
        Next
        conn.Close()
    End Sub
End Class
