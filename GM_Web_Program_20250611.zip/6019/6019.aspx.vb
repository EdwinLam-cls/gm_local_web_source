﻿Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration
Imports System.Data.Common

Partial Class _6019_6019

    Inherits System.Web.UI.Page

    Dim gErr As String = ""


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim tmpstr As String = ""

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("6019", True)
            btn_search.Visible = False
            ddlMaterialGroup.AutoPostBack = True

        End If

        'Dim xVal() As String = {"1", "2", "3"}
        'Dim yval() As Double = {12, 34, 45}

        'Chart1.Series("Series1").Points.DataBindXY(xVal, yval)

        'System.Diagnostics.Debug.WriteLine(SqlMainSource.SelectCommand)

        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""

    End Sub


    ' Check_Power() 檢查使用者權限並存入登入紀錄
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub
    'Protected Sub btn_search_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_search.Click
    '    Chk_Filter()
    'End Sub

    'Private Sub Chk_Filter()

    '    Dim tempString As String = ""

    '    Dim stk_desc As String = ""
    '    Dim customer_name As String = ""
    '    Dim base_qty_uom As String = ""
    '    Dim printDis As Boolean = False
    '    Dim startCompany As String = ""
    '    Dim endCompany As String = ""

    '    Dim company_code As String = ""
    '    Dim district_name As String = ""
    '    Dim subTotalStore As Integer = 0
    '    Dim subTotalPack As Integer = 0
    '    Dim disArray As ArrayList = New ArrayList()
    '    Dim totalCompany As Integer = 0
    '    Dim totalPack As Integer = 0
    '    Dim totalStore As Integer = 0

    '    'If ls_pay_term.Text <> "" Then
    '    '    tempString &= " and a.pay_term ='" & ls_pay_term.Text & "'"
    '    'End If

    '    If fr_tb_comp_code.Text.ToUpper = "所有客戶" Then
    '        tempString &= " and b.company_code between '0' and "
    '    ElseIf fr_tb_comp_code.Text <> "" Then
    '        tempString &= " and b.company_code between '" & fr_tb_comp_code.Text & "' and "
    '    End If

    '    Try
    '        If tb_fr_date.Text <> "" AndAlso DateTime.Parse(tb_fr_date.Text).Year <> 1900 Then
    '            tempString &= " and convert(nvarchar, a.txn_date, 112) >= convert(nvarchar, cast('" & tb_fr_date.Text & "' as smalldatetime), 112) "
    '        End If

    '        If tb_to_date.Text <> "" AndAlso DateTime.Parse(tb_to_date.Text).Year <> 1900 Then
    '            tempString &= " and convert(nvarchar, a.txn_date, 112) <= convert(nvarchar, cast('" & tb_to_date.Text & "' as smalldatetime), 112) "
    '        End If
    '    Catch
    '        gErr = "alert('「日期」輸入錯誤\n')"
    '        lt_show.Text = "<script language=javascript>" & gErr & "</script>"
    '        Return
    '    End Try

    '    Dim myDataTable As DataTable = New DataTable()
    '    Dim myDataSet As New DataSet

    '    Dim Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
    '    Sql_conn.Open()

    '    Dim SqlString As String = ""
    '    SqlString = "select max(a.stk_code) as stk_code, max(isnull(b.company_code,'新客戶')) as company_code , max(b.customer_name) as customer_name ,SUM(a.base_qty) as base_qty, MAX(a.base_uom) as base_uom, max(b.district_name) as district_name ,max(c.stk_desc) as stk_desc ,"
    '    SqlString &= " (cast(sum(a.base_qty) as nvarchar) + max(a.base_uom)) as base_qty_uom "
    '    SqlString &= "from daily_sales_tx_summary a "
    '    SqlString &= "inner join custmas b on a.customer_code = b.customer_code "
    '    SqlString &= "inner join stkmas c on a.stk_code = c.stk_code "
    '    SqlString &= "where a.txn_type = '銷售' and a.stk_code = '" & ddlMaterial.Text & "' "

    '    If tempString <> "" Then SqlString &= tempString

    '    SqlString &= "group by b.customer_code,a.stk_code order by company_code,district_name,stk_code,customer_name "

    '    Dim Sql_Command As New SqlCommand(SqlString, Sql_conn)
    '    Dim reader As SqlDataReader = Sql_Command.ExecuteReader()
    '    Dim tempHash As Hashtable = New Hashtable
    '    myDataTable.Load(reader)
    '    Sql_Command.Dispose()
    '    Sql_conn.Close()

    '    lt_detail.Text = "<br /><table width=""98%"" cellspacing=""0"" cellpadding=""4"" rules=""all"" border=""1"" style=""background-color:White;border-color:#003366;border-width:1px;border-style:Double""> "

    '    If myDataTable.Rows.Count > 0 Then

    '        lt_detail.Text = lt_detail.Text & "<tr align=""left"" style=""background-color:#99FF99;height:18pt"">"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"" style=""width:100"">客戶名稱</th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">地區名稱</th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">種類備註</th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">分店名稱</th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">數量</th>"
    '        lt_detail.Text = lt_detail.Text & "</tr>"

    '        For Each myDataRow As DataRow In myDataTable.Rows

    '            If district_name <> myDataRow.Item("district_name").ToString AndAlso district_name <> "" Then
    '                lt_detail.Text = lt_detail.Text & "<tr align=""left"" style=""background-color:White;9;height:18pt"">"
    '                lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '                lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '                lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">分區小計: " & subTotalStore & " 間分店</th>"
    '                lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '                lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '                lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">" & subTotalPack.ToString & myDataTable.Rows(0).Item("base_uom") & "</th>"
    '                lt_detail.Text = lt_detail.Text & "</tr>"
    '                subTotalPack = 0
    '            End If

    '            If company_code <> myDataRow.Item("company_code").ToString Then
    '                lt_detail.Text = lt_detail.Text & "<tr align=""left"" style=""background-color:#White;height:18pt"">"
    '                lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">" & myDataRow.Item("company_code").ToString & "</th>"
    '                lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '                lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '                lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '                lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '                lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '                lt_detail.Text = lt_detail.Text & "</tr>"
    '                company_code = myDataRow.Item("company_code").ToString
    '                totalCompany += 1
    '            End If

    '            If district_name <> myDataRow.Item("district_name").ToString Then
    '                lt_detail.Text = lt_detail.Text & "<tr align=""left"" style=""background-color:#White;height:18pt"">"
    '                lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '                lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">" & myDataRow.Item("district_name").ToString & "</th>"
    '                lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '                lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '                lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '                lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '                lt_detail.Text = lt_detail.Text & "</tr>"
    '                district_name = myDataRow.Item("district_name").ToString
    '                totalStore += subTotalStore
    '                subTotalStore = 0

    '                'totalPack = 0
    '                If Not disArray.Contains(myDataRow.Item("district_name").ToString) Then
    '                    disArray.Add(myDataRow.Item("district_name").ToString)
    '                End If
    '            End If

    '            lt_detail.Text = lt_detail.Text & "<tr align=""left"" style=""background-color:#White;height:18pt"">"
    '            lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '            lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '            lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '            lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">" & myDataRow.Item("stk_desc") & "</th>"
    '            lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">" & myDataRow.Item("customer_name") & "</th>"
    '            lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">" & myDataRow.Item("base_qty_uom") & "</th>"
    '            lt_detail.Text = lt_detail.Text & "</tr>"

    '            If Not tempHash.Contains(myDataRow.Item("stk_code")) Then
    '                tempHash.Add(myDataRow.Item("stk_code"), myDataRow.Item("stk_desc"))
    '            End If

    '            subTotalStore += 1

    '            subTotalPack += CType(myDataRow.Item("base_qty"), Integer)
    '            totalPack += CType(myDataRow.Item("base_qty"), Integer)
    '        Next

    '        totalStore += subTotalStore
    '        lt_detail.Text = lt_detail.Text & "<tr align=""left"" style=""background-color:White;9;height:18pt"">"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">分區小計: " & subTotalStore & " 間分店</th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">" & subTotalPack.ToString & myDataTable.Rows(0).Item("base_uom") & "</th>"
    '        lt_detail.Text = lt_detail.Text & "</tr>"

    '        lt_detail.Text = lt_detail.Text & "<tr align=""left"" style=""background-color:White;9;height:18pt"">"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">貨品種類小計:</th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">" & disArray.Count & "個分區</th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">" & totalPack & myDataTable.Rows(0).Item("base_uom") & "</th>"
    '        lt_detail.Text = lt_detail.Text & "</tr>"

    '        lt_detail.Text = lt_detail.Text & "<tr align=""left"" style=""background-color:White;9;height:18pt"">"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">合共分店:</th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">" & totalStore & " 間分店</th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">" & totalPack & myDataTable.Rows(0).Item("base_uom") & "</th>"
    '        lt_detail.Text = lt_detail.Text & "</tr>"

    '        lt_detail.Text = lt_detail.Text & "<tr align=""left"" style=""background-color:White;9;height:18pt"">"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">合共客戶:</th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">" & totalCompany & "</th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '        lt_detail.Text = lt_detail.Text & "</tr>"

    '        lt_detail.Text = lt_detail.Text & "<tr align=""left"" style=""background-color:White;9;height:18pt"">"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">合共數量:</th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">" & totalPack & myDataTable.Rows(0).Item("base_uom") & "</th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '        lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '        lt_detail.Text = lt_detail.Text & "</tr>"

    '    Else
    '        lt_detail.Text = "<br /><table cellspacing=""0"" cellpadding=""4"" align=""Center"" rules=""all"" border=""1"" id=""gv_custmaster"" style=""background-color:White;border-color:#003366;border-width:1px;border-style:Double;width:98%;border-collapse:collapse;""><tr align=""center"" valign=""middle"" style=""background-color:#FFFFCC;height:40px;""><td colspan=""5"">沒有任何銷售資料!</td></tr></table>"
    '    End If

    '    'If myDataTable.Rows.Count > 0 Then
    '    '    lt_detail.Text = lt_detail.Text & "<tr align=""left"" style=""background-color:White;9;height:18pt"">"
    '    '    lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '    '    lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '    '    lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">分區小計: " & subTotalStore & " 間分店</th>"
    '    '    lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '    '    lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col""></th>"
    '    '    lt_detail.Text = lt_detail.Text & "<th align=""center"" scope=""col"">" & totalPack.ToString & "包</th>"
    '    '    lt_detail.Text = lt_detail.Text & "</tr>"
    '    'End If

    '    lt_detail.Text = lt_detail.Text & "</table>"

    'End Sub


    Protected Sub ddlMaterialGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlMaterialGroup.SelectedIndexChanged
        Dim strMaterialGroup As String = Me.ddlMaterialGroup.Text.Trim
        BindMaterial(strMaterialGroup)

    End Sub

    Private Sub BindMaterial(ByVal strMaterialGroup As String)
        Dim strSql As String = "select distinct i.chiDesc from item_group_master g inner join item_master i on g.materialGroupCode = i.materialGroupCode where 1=1"
        If strMaterialGroup <> "" Then
            strSql += " and g.chiDesc = '" & strMaterialGroup & "'"
        End If
        strSql += " order by i.chiDesc"
        dsMaterial.SelectCommand = strSql
        ddlMaterial.DataBind()

    End Sub
End Class
