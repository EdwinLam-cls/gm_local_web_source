﻿'**************************************************
' Program Name    : 6045.aspx.vb
' Function        : Daily Return Order Report 
' Author  Name    : Edwin Lam
' Creation Date   : 10-08-2023
' Last Modify Date: 
'**************************************************

Imports System.Data
Imports Common_Func

Partial Class _6045_6045
    Inherits System.Web.UI.Page
    Dim gErr As String = ""
    Dim G_strVanId As String = ""
    Dim G_strDate As String = ""
    Dim G_strMonth As String = ""
    Dim G_strYear As String = ""
    Dim G_strMTDselection As String = ""
    Dim G_strPeriod As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim tmpstr As String = ""

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("6045", True)
        End If

        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""
    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.Click

        Try
            getString()
            showTotal()
            showMTD()
            'show_checking()
        Catch ex As Exception

        End Try

    End Sub

    Private Sub showTotal()
        Dim strSql As String
        Dim myDataTable As DataTable
        Dim totalrefDocNo As Integer = 0
        Dim totalQty As Integer = 0
        Dim totalCustNo As Integer = 0

        strSql = "select COUNT(distinct rh.refDocNo) AS cnt "
        strSql &= "FROM txn_return_header rh "
        strSql &= "WHERE 1=1 "
        strSql &= G_strDate & G_strVanId

        myDataTable = ExeSQLGetDataTable(strSql)
        If myDataTable.Rows.Count > 0 Then
            Integer.TryParse(myDataTable.Rows(0).Item("cnt").ToString, totalrefDocNo)
        End If

        strSql = "SELECT SUM(total_quantity) AS cnt "
        strSql &= "FROM txn_return_header rh "
        strSql &= "WHERE 1=1 "
        strSql &= G_strDate & G_strVanId

        myDataTable = ExeSQLGetDataTable(strSql)
        If myDataTable.Rows.Count > 0 Then
            Integer.TryParse(myDataTable.Rows(0).Item("cnt").ToString, totalQty)
        End If

        strSql = "SELECT COUNT(custNo) AS cnt "
        strSql &= "FROM txn_return_header rh "
        strSql &= "WHERE 1=1 "
        strSql &= G_strDate & G_strVanId

        myDataTable = ExeSQLGetDataTable(strSql)
        If myDataTable.Rows.Count > 0 Then
            Integer.TryParse(myDataTable.Rows(0).Item("cnt").ToString, totalCustNo)
        End If

        myDataTable = ExeSQLGetDataTable(strSql)
        If myDataTable.Rows.Count > 0 Then
            lbl_total.Text = " Total No. of Referenc No: " & totalrefDocNo.ToString("N0") & "&nbsp;&nbsp;&nbsp;"
            lbl_total.Text &= " Total Customer: " & totalCustNo.ToString("N0") & "&nbsp;&nbsp;&nbsp;"
            lbl_total.Text &= " Total Quantity: " & totalQty.ToString("N0") & "&nbsp;&nbsp;&nbsp;"
        Else
            lbl_total.Text = ""
        End If
    End Sub


    Private Sub showMTD()
        Dim strSql As String
        Dim myDataTable As DataTable
        Dim TotalRefDocNo As Integer = 0
        Dim TotalQty As Integer = 0
        Dim TotalCust As Integer = 0

        strSql = "select isnull(sum(rd.quantity),0) as TotalQty, "
        strSql &= "COUNT(distinct rh.CustNo) as TotalCust, "
        strSql &= "COUNT(distinct rh.refDocNo) as cnt "
        strSql &= "FROM txn_return_header rh, txn_return_detail rd "
        strSql &= "WHERE rh.refDocNo = rd.refDocNo "
        strSql &= G_strVanId & G_strMTDselection

        myDataTable = ExeSQLGetDataTable(strSql)
        If myDataTable.Rows.Count > 0 Then
            Integer.TryParse(myDataTable.Rows(0).Item("cnt").ToString, TotalRefDocNo)
            Integer.TryParse(myDataTable.Rows(0).Item("TotalQty").ToString, TotalQty)
            Integer.TryParse(myDataTable.Rows(0).Item("TotalCust").ToString, TotalCust)

            lbl_Mtotal.Text = G_strPeriod & " No. of Reference NO: " & TotalRefDocNo.ToString("N0") & "&nbsp;&nbsp;&nbsp;"
            lbl_Mtotal.Text += G_strPeriod & " Customer: " & TotalCust.ToString("N0") & "&nbsp;&nbsp;&nbsp;"
            lbl_Mtotal.Text += G_strPeriod & " Quantity: " & TotalQty.ToString("N0") & "&nbsp;&nbsp;&nbsp;"
        Else
            lbl_Mtotal.Text = ""
        End If
    End Sub

    Private Sub show_checking()
        Dim van_code As String
        Dim strsql As String
        Dim myDataTable As DataTable
        Dim total_header_line As String
        Dim total_detail_line As String
        Dim total_rheader_line As String
        Dim total_rdetail_line As String
        Dim total_oheader_line As String
        Dim total_odetail_line As String

        Dim last_return_number As String
        Dim last_Hreturn_number As String
        Dim txn_id As String

        total_header_line = ""
        total_detail_line = ""
        total_rheader_line = ""
        total_rdetail_line = ""
        total_oheader_line = ""
        total_odetail_line = ""
        txn_id = ""
        van_code = Right(ddlVanId.Text.Trim, 3)
        If ddlVanId.Text.Trim <> "ALL" Then

            strsql = "select count(*) as totrec from txn_return_header with (nolock) where van_id  = '" + van_code + "' and CONVERT(nvarchar(10),cr_date,112) = '" + Replace(Me.txtDateFrom.Text.Trim, "/", "") + "'"
            myDataTable = ExeSQLGetDataTable(strsql)
            If myDataTable.Rows.Count > 0 Then
                total_rheader_line = myDataTable.Rows(0).Item("totrec").ToString
            End If

            'Check Other transaction header record count
            strsql = "select count(*) as totrec from txn_header with (nolock) where van_id  = '" + van_code + "' and CONVERT(nvarchar(10),cr_date,112) = '" + Replace(Me.txtDateFrom.Text.Trim, "/", "") + "'"
            myDataTable = ExeSQLGetDataTable(strsql)
            If myDataTable.Rows.Count > 0 Then
                total_oheader_line = myDataTable.Rows(0).Item("totrec").ToString
            End If

            strsql = "select count(*) as totrec from txn_return_detail with (nolock) where refDocNo in (select refDocNo from txn_return_header with (nolock) where van_id  = '" + van_code + "' and CONVERT(nvarchar(10),cr_date,112) = '" + Replace(Me.txtDateFrom.Text.Trim, "/", "") + "')"
            myDataTable = ExeSQLGetDataTable(strsql)
            If myDataTable.Rows.Count > 0 Then
                total_rdetail_line = myDataTable.Rows(0).Item("totrec").ToString
            End If

            'Check Other transaction detail record count
            strsql = "select count(*) as totrec from txn_detail with (nolock) where refDocNo in (select refDocNo from txn_header with (nolock) where van_id  = '" + van_code + "' and CONVERT(nvarchar(10),cr_date,112) = '" + Replace(Me.txtDateFrom.Text.Trim, "/", "") + "')"
            myDataTable = ExeSQLGetDataTable(strsql)
            If myDataTable.Rows.Count > 0 Then
                total_odetail_line = myDataTable.Rows(0).Item("totrec").ToString
            End If

            strsql = "select top 1 * from pda_sync_rec with (nolock) where vanCode = '" + van_code + "' and req_type = 'U' and convert(nvarchar(10),req_time,112) = '" + Replace(Me.txtDateFrom.Text.Trim, "/", "") + "' order by req_time desc"
            myDataTable = ExeSQLGetDataTable(strsql)

            If myDataTable.Rows.Count > 0 Then
                txn_id = myDataTable.Rows(0).Item("transaction_id").ToString
                If InStr(txn_id, "-") > 0 Then
                    total_header_line = Split(txn_id, "-")(1)
                    total_detail_line = Split(txn_id, "-")(2)
                    If RTrim(LTrim(total_detail_line)) <> RTrim(LTrim(total_rdetail_line) + LTrim(total_odetail_line)) Or RTrim(LTrim(total_header_line)) <> RTrim(LTrim(total_rheader_line) + LTrim(total_oheader_line)) Then
                        lbl_checking.Text = "ERROR Record not match !!!! PDA upload Header " + total_header_line + "/" + total_rheader_line + " upload Detail " + total_detail_line + "/" + total_rdetail_line
                    Else
                        lbl_checking.Text = ""
                    End If
                Else
                    lbl_checking.Text = ""
                End If
            Else
                lbl_checking.Text = "PDA not yet upload"
            End If
        Else
            lbl_checking.Text = ""
        End If

        last_return_number = ""
        last_Hreturn_number = ""

        If lbl_checking.Text = "" And ddlVanId.Text.Trim <> "ALL" Then
            strsql = "select * from business_unit with (nolock) where vanCode = 'C_HK2ZK" + van_code + "'"
            myDataTable = ExeSQLGetDataTable(strsql)
            If myDataTable.Rows.Count > 0 Then
                last_return_number = myDataTable.Rows(0).Item("last_return_no").ToString
            End If

            strsql = "select top 1 refDocNo from txn_return_header with (nolock) where van_id = '" + van_code + "' and convert(nvarchar(10),cr_date,112) = '" + Replace(Me.txtDateFrom.Text.Trim, "/", "") + "' and refDocNo like 'RN%' order by refdocno desc"
            myDataTable = ExeSQLGetDataTable(strsql)
            If myDataTable.Rows.Count > 0 Then
                last_Hreturn_number = Mid(myDataTable.Rows(0).Item("refDocNo").ToString, 3, 9)
            Else
                last_Hreturn_number = ""
            End If

            If last_return_number <> "" And last_return_number <> last_Hreturn_number Then
                lbl_checking.Text = "ERROR UPLOAD Return Not match " + last_return_number + "/" + last_Hreturn_number + " "
            End If

        End If

    End Sub

    Protected Sub gv_custmaster_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gv_custmaster.Sorting
        getString()
    End Sub

    Private Sub getString()

        Try
            Dim strDate As String = Me.txtDateFrom.Text.Trim
            Dim strVanId As String = ddlVanId.Text.Trim
            Dim strDateSql As String = String.Empty
            Dim strVanSql As String = String.Empty
            Dim strSql As String = String.Empty
            Dim getCodeDataTable As DataTable
            Dim strFrom As String = ""
            Dim strTo As String = ""

            If (strDate <> "") Then
                If Not (strDate Like "####[/]##[/]##" Or IsDate(strDate)) Then
                    gErr = "alert('[Date From] error! \n')"
                    Return
                End If
                G_strYear = " and year(rh.cr_date) = '" & CDate(strDate).ToString("yyyy") & "' "
                G_strMonth = " and month(rh.cr_date) = '" & CDate(strDate).ToString("MM") & "' "

                strDateSql = " and convert(varchar,rh.cr_date,111) = '" & strDate & "' "

                getDateFromTo(strFrom, strTo, txtDateFrom.Text)
                G_strMTDselection = " and convert(varchar(10),rh.cr_date,111) >= '" & strFrom & "' and  convert(varchar(10),rh.cr_date,111) <= '" & strTo & "'"
            End If

            Select Case strVanId
                Case ""     ' No such case. Already handled by JavaScript
                    strVanSql = String.Empty
                Case "ALL"  ' If search by all van, no need to filter out any.
                    strVanSql = String.Empty
                Case Else
                    strVanSql = " AND RIGHT(rh.van_id, 3) = '" & Right(strVanId, 3) & "' "
            End Select

            G_strDate = strDateSql
            G_strVanId = strVanSql

            If (SqlMainSource.SelectParameters.Count > 0) Then
                SqlMainSource.SelectParameters.Clear()
            End If

            SqlMainSource.SelectParameters.Add("date", strDate)
            If strVanId = "ALL" Then
                ' Get the minimum van code and maximum van code
                strSql = "SELECT RIGHT(MIN(vanCode), 3) AS minCode, RIGHT(MAX(vanCode), 3) AS maxCode FROM business_unit"
                getCodeDataTable = ExeSQLGetDataTable(strSql)
                If getCodeDataTable.Rows.Count > 0 Then
                    SqlMainSource.SelectParameters.Add("minVan", getCodeDataTable.Rows(0).Item("minCode").ToString)
                    SqlMainSource.SelectParameters.Add("maxVan", getCodeDataTable.Rows(0).Item("maxCode").ToString)
                End If
            Else
                ' For individual van, list in this order: Sample, Exchange and Sale (Pre-order and regular sale)
                SqlMainSource.SelectParameters.Add("minVan", Right(strVanId, 3))
                SqlMainSource.SelectParameters.Add("maxVan", Right(strVanId, 3))
            End If
        Catch ex As Exception
        End Try

    End Sub

    Private Sub getDateFromTo(ByRef strFrom As String, ByRef strTo As String, ByVal strFromDate As String)
        Dim myDataTable As DataTable
        Dim strSql As String = " select finyear + finperiod as period,  isnull(CONVERT(varchar(10),MIN(startDate),111),'') a, isnull(CONVERT(varchar(10),MAX(EndDate),111),'') b " & _
                               " from fin_period where Finyear + FinPeriod in (select FinYear + FinPeriod from fin_period " & _
        String.Format(" where '{0}' >= CONVERT(varchar(10),StartDate,111) and '{0}' <= CONVERT(varchar(10),enddate,111) )", strFromDate) & " group by finyear, finperiod "
        myDataTable = ExeSQLGetDataTable(strSql)
        If myDataTable.Rows.Count > 0 Then
            G_strPeriod = myDataTable.Rows.Item(0)("period")
            strFrom = myDataTable.Rows.Item(0)("a")
            strTo = myDataTable.Rows.Item(0)("b")
        End If
        If strFrom <> "" Then
            lblPeriod.Text = "Financial Period (" & G_strPeriod & ") : " & strFrom & " - " & strTo
        Else
            lblPeriod.Text = ""
        End If
    End Sub

End Class
