﻿'---------------------------------------------------------------------------- 
'程式功能	District Master > 明細內容 > 新增資料
'---------------------------------------------------------------------------- 

Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration

Partial Class _2013_2013_add
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0

            ' 檢查使用者權限但不存入登入紀錄 
            Check_Power("2013", False)

            ' 承接上一頁的查詢條件設定
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid").ToString(), ckint) Then
                    lb_page.Text = "?pageid=" & ckint.ToString()
                Else
                    lb_page.Text = "?pageid=0"
                End If
            End If

            If Request("district_id") IsNot Nothing Then
                lb_page.Text &= "&district_id=" & Request("district_id")
            End If

        End If
    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub lb_ok_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim mErr As String = ""
        Dim mg_sid As Integer = -1

        ' 載入字串函數 
        Dim sfc As New String_Func()

        ' 載入公用函數 
        Dim cfc As New Common_Func()

        If Me.tb_district_zone.Text.Trim() = "" Then
            mErr &= "Please enter district in Chinese!\n"
        ElseIf cfc.CheckSQL(tb_district_zone.Text.Trim()) Then
            mErr &= "Special Characters not allowed!\n"
        End If

        If Me.tb_district_zone_eng.Text.Trim() = "" Then
            mErr &= "Please enter district in English!\n"
        ElseIf cfc.CheckSQL(tb_district_zone_eng.Text.Trim()) Then
            mErr &= "Special Characters not allowed!\n"
        End If


        If mErr = "" Then
            Using Sql_Conn1 As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                Dim SqlString1 As String = ""
                Dim decoder1 As New Decoder()

                SqlString1 = "Select Top 1 * "
                SqlString1 &= " From district_master b"
                SqlString1 &= " Where b.district_zone = @district_zone"

                Using Sql_Command1 As New SqlCommand(SqlString1, Sql_Conn1)
                    Sql_Conn1.Open()

                    Sql_Command1.Parameters.AddWithValue("district_zone", tb_district_zone.Text)

                    Using Sql_Reader1 As SqlDataReader = Sql_Command1.ExecuteReader()
                        If Sql_Reader1.Read() Then
                            mErr = "District already exists!\n"
                        End If
                    End Using
                    Sql_Command1.Dispose()
                End Using
            End Using
        End If


        If mErr = "" Then
            Using Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                Dim SqlString As String = ""
                Dim decoder As New Decoder()

                ' 建立 SQL 的語法 
                SqlString = "Insert Into district_master (district_name, district_zone,district_name_eng, district_zone_eng)"
                SqlString &= " Values (@district_name, @district_zone,@district_name_eng, @district_zone_eng);"

                Dim strDistrictName As String = tb_district_name.Text.Trim
                Dim strDistrictNameEng As String = ""
                Select Case strDistrictName
                    Case "九龍區"
                        strDistrictNameEng = "Kowloon"
                    Case "新界區"
                        strDistrictNameEng = "New Territories"
                    Case "香港區"
                        strDistrictNameEng = "Hong Kong Island"
                End Select




                Using Sql_Command As New SqlCommand()
                    Sql_Command.Connection = Sql_conn
                    Sql_Command.CommandText = SqlString

                    ' 擷取字串到資料庫所規範的大小 sfc.Left(string mdata, int leng) 
                    Sql_Command.Parameters.AddWithValue("@district_name", sfc.Left(tb_district_name.Text, 40))
                    Sql_Command.Parameters.AddWithValue("@district_zone", sfc.Left(tb_district_zone.Text, 40))
                    Sql_Command.Parameters.AddWithValue("@district_name_eng", strDistrictNameEng)
                    Sql_Command.Parameters.AddWithValue("@district_zone_eng", sfc.Left(tb_district_zone_eng.Text, 80))
                    Sql_conn.Open()

                    Sql_Command.ExecuteNonQuery()
                    Sql_Command.Dispose()

                    ' 取得新增資料的主鍵值 
                    mg_sid = 0
                End Using
            End Using
        End If

        If mErr = "" Then
            mErr = ("alert('Saved successfully!\n');location.replace('2008.aspx" & lb_page.Text & "&sid=") + mg_sid.ToString() & "');"
        Else
            mErr = "alert('" & mErr & "')"
        End If

        lt_show.Text = "<script language=javascript>" & mErr & "</script>"
    End Sub

End Class
