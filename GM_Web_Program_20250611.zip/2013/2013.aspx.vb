﻿'---------------------------------------------------------------------------- 
'程式功能	District Manster Master Maintenance
'---------------------------------------------------------------------------- 
Imports System
Imports System.Collections.Generic
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Partial Class _2013_2013
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()

            ' 檢查使用者權限並存入登入紀錄。 
            Check_Power("2013", True)

            '接受下一頁返回時的舊查詢條件" 
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid"), ckint) Then
                    gv_district_master.PageIndex = ckint
                Else
                    lb_pageid.Text = "0"
                End If
            End If



        End If

        Chk_Filter()

    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            'If cfc.Check_Power(Session("stk_code").ToString(), Session("stk_desc").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub gv_district_master_PageIndexChanged(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        lb_pageid.Text = e.NewPageIndex()
    End Sub



    Protected Sub Btn_Set_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' 檢查查詢條件是否改變 
        Chk_Filter()
    End Sub

    ' 檢查查詢條件是否改變 
    Private Sub Chk_Filter()
        Dim cfc As New Common_Func()

        Dim ckint As Integer = 0
        Dim tmpstr As String = ""

        Dim strSearchGroup = tb_district_name.Text.Trim
        Dim strSearchEngDesc = tb_district_zone.Text.Trim

        Dim strSql As String = "select * from district_master"
        strSql += " where 1=1 and (district_zone_eng <> '' and district_name_eng <>'')"
        strSql += " and [district_name_eng] like '%" & strSearchGroup & "%'"
        strSql += " and [district_zone_eng] like '%" & strSearchEngDesc & "%' order by district_name_eng"

        dsDistrict.SelectCommand = strSql
        gv_district_master.DataBind()
        If gv_district_master.PageCount - 1 < gv_district_master.PageIndex Then
            gv_district_master.PageIndex = gv_district_master.PageCount
            gv_district_master.DataBind()
        End If

        lb_pageid.Text = gv_district_master.PageIndex.ToString()
    End Sub



End Class
