﻿'---------------------------------------------------------------------------- 
'程式功能	日期選擇 
'備註說明	網頁內要有 fullwindow、div_calendar 的 div 區塊及 if_calendar 的 iframe 來開啟 
'			需含入 /js/innerWindow.js 
'			/js/innerCalendar.js 
'---------------------------------------------------------------------------- 

Imports System

Partial Public Class _calendar
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
		If Not IsPostBack Then
			Dim mErr As String = ""
			Dim ckdt As DateTime
			If Request("ndt") IsNot Nothing Then
				If DateTime.TryParse(Request("ndt"), ckdt) Then
					cdr1.VisibleDate = ckdt
				End If
			End If

			If Request("rtobj") Is Nothing Then
				mErr = "未宣告傳回物件\n"
			Else
				lb_rtobj.Text = Request("rtobj")
			End If

			If mErr <> "" Then
				ClientScript.RegisterStartupScript(Me.GetType(), "ClientScript", "alert(""" & mErr & """);parent.close_calendar();", True)
			End If
		End If
	End Sub

	' 選擇日期後，傳回資料並關閉視窗 
	Protected Sub cdr1_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs)
		Dim fDay As DateTime = cdr1.SelectedDate

		ClientScript.RegisterStartupScript(Me.GetType(), "ClientScript", ("parent.rt_parent(""" & lb_rtobj.Text & """,""") + fDay.ToString("yyyy/MM/dd") & """);", True)
	End Sub
End Class