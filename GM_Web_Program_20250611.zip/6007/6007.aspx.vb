﻿Imports System.Data
Imports Common_Func

Partial Class _6007_6007
    Inherits System.Web.UI.Page

    Dim gErr As String = ""
    Dim G_strVanId As String = ""
    Dim G_strDate As String = ""
    Dim G_strMonth As String = ""
    Dim G_strYear As String = ""
    Dim G_strMTDselection As String = ""
    Dim G_strPeriod As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim tmpstr As String = ""

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("6007", True)
        End If

        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""
    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.Click

        Try
            getString()
            showTotal()
            showMTD()
            'show_checking()
        Catch ex As Exception


        End Try
        
    End Sub

    Private Sub showTotal()
        Dim strSql As String
        Dim myDataTable As DataTable
        Dim totalInvoice As Integer = 0
        Dim totalSale As Integer = 0
        Dim totalExchange As Integer = 0
        Dim totalFree As Integer = 0
        Dim totalVoid As Integer = 0
        Dim netTotal As Double = 0.0
        Dim grossTotal As Double = 0.0

        ' Since the total number of invoice has to count also those which are voided,
        ' Have to do it seperately.
        strSql = "select COUNT(distinct h.refDocNo) AS cnt "
        strSql &= "FROM txn_header h "
        strSql &= "WHERE 1=1 "
        strSql &= G_strDate & G_strVanId

        myDataTable = ExeSQLGetDataTable(strSql)
        If myDataTable.Rows.Count > 0 Then
            Integer.TryParse(myDataTable.Rows(0).Item("cnt").ToString, totalInvoice)
        End If

        ' Seperate into total sale, total exchange, total free and total void
        strSql = "SELECT COUNT(txn_type) AS cnt "
        strSql &= "FROM txn_header h "
        strSql &= "WHERE h.txn_type = N'Sales' AND h.isVoid <> '1' "
        strSql &= G_strDate & G_strVanId

        myDataTable = ExeSQLGetDataTable(strSql)
        If myDataTable.Rows.Count > 0 Then
            Integer.TryParse(myDataTable.Rows(0).Item("cnt").ToString, totalSale)
        End If

        strSql = "SELECT COUNT(txn_type) AS cnt "
        strSql &= "FROM txn_header h "
        strSql &= "WHERE h.txn_type = N'Exchange' AND h.isVoid <> '1' "
        strSql &= G_strDate & G_strVanId

        myDataTable = ExeSQLGetDataTable(strSql)
        If myDataTable.Rows.Count > 0 Then
            Integer.TryParse(myDataTable.Rows(0).Item("cnt").ToString, totalExchange)
        End If

        strSql = "SELECT COUNT(txn_type) AS cnt "
        strSql &= "FROM txn_header h "
        strSql &= "WHERE h.txn_type = N'Free' AND h.isVoid <> '1' "
        strSql &= G_strDate & G_strVanId

        myDataTable = ExeSQLGetDataTable(strSql)
        If myDataTable.Rows.Count > 0 Then
            Integer.TryParse(myDataTable.Rows(0).Item("cnt").ToString, totalFree)
        End If

        strSql = "SELECT COUNT(txn_type) AS cnt "
        strSql &= "FROM txn_header h "
        strSql &= "WHERE h.isVoid = '1' "
        strSql &= G_strDate & G_strVanId

        myDataTable = ExeSQLGetDataTable(strSql)
        If myDataTable.Rows.Count > 0 Then
            Integer.TryParse(myDataTable.Rows(0).Item("cnt").ToString, totalVoid)
        End If

        strSql = "select isnull(sum(quantity * netPrice ),0) as netTotal, "
        strSql &= "isnull(sum(quantity * grossPrice ),0) as grossTotal "
        strSql &= "FROM txn_header h, txn_detail d "
        strSql &= "WHERE h.refDocNo = d.refDocNo AND h.txn_type = N'Sales' and h.isVoid <> '1'  "
        strSql &= G_strDate & G_strVanId

        myDataTable = ExeSQLGetDataTable(strSql)
        If myDataTable.Rows.Count > 0 Then
            Double.TryParse(myDataTable.Rows(0).Item("netTotal").ToString, netTotal)
            Double.TryParse(myDataTable.Rows(0).Item("grossTotal").ToString, grossTotal)

            lbl_total.Text = " Total No. of Invoice: " & totalInvoice.ToString("N0") & "&nbsp;&nbsp;&nbsp;"
            lbl_total.Text &= " Total Sale: " & totalSale.ToString("N0") & "&nbsp;&nbsp;&nbsp;"
            lbl_total.Text &= " Total Exchange: " & totalExchange.ToString("N0") & "&nbsp;&nbsp;&nbsp;"
            lbl_total.Text &= " Total Free: " & totalFree.ToString("N0") & "&nbsp;&nbsp;&nbsp;"
            lbl_total.Text &= " Total Void: " & totalVoid.ToString("N0") & "&nbsp;&nbsp;&nbsp;"

            lbl_total.Text += " Total Net Sales: " & netTotal.ToString("N", New System.Globalization.CultureInfo("en-US")) & "&nbsp;&nbsp;&nbsp;"
            lbl_total.Text += " Total Gross Sales: " & grossTotal.ToString("N", New System.Globalization.CultureInfo("en-US")) & "&nbsp;&nbsp;&nbsp;"
        Else
            lbl_total.Text = ""
        End If
    End Sub


    Private Sub showMTD()
        Dim strSql As String
        Dim myDataTable As DataTable
        Dim totalInvoice As Integer = 0
        Dim netTotal As Double = 0.0
        Dim grossTotal As Double = 0.0

        strSql = "select isnull(sum(quantity * netPrice ),0) as netTotal, "
        strSql &= "isnull(sum(quantity * grossPrice ),0) as grossTotal, "
        strSql &= "COUNT(distinct h.refDocNo) as cnt "
        strSql &= "FROM txn_header h, txn_detail d "
        strSql &= "WHERE h.refDocNo = d.refDocNo AND h.txn_type = N'Sales' and h.isVoid <> '1'  "
        strSql &= G_strVanId & G_strMTDselection

        myDataTable = ExeSQLGetDataTable(strSql)
        If myDataTable.Rows.Count > 0 Then
            Integer.TryParse(myDataTable.Rows(0).Item("cnt").ToString, totalInvoice)
            Double.TryParse(myDataTable.Rows(0).Item("netTotal").ToString, netTotal)
            Double.TryParse(myDataTable.Rows(0).Item("grossTotal").ToString, grossTotal)

            lbl_Mtotal.Text = G_strPeriod & " No. of Invoice: " & totalInvoice.ToString("N0") & "&nbsp;&nbsp;&nbsp;"
            lbl_Mtotal.Text += G_strPeriod & " Net Sales: " & netTotal.ToString("N", New System.Globalization.CultureInfo("en-US")) & "&nbsp;&nbsp;&nbsp;"
            lbl_Mtotal.Text += G_strPeriod & " Gross Sales: " & grossTotal.ToString("N", New System.Globalization.CultureInfo("en-US")) & "&nbsp;&nbsp;&nbsp;"
        Else
            lbl_Mtotal.Text = ""
        End If
    End Sub

    Private Sub show_checking()
        Dim van_code As String
        Dim strsql As String
        Dim myDataTable As DataTable
        Dim total_header_line As String
        Dim total_detail_line As String
        Dim total_rheader_line As String
        Dim total_rdetail_line As String

        Dim last_sale_number As String
        Dim last_free_number As String
        Dim last_ex_number As String
        Dim last_hsale_number As String
        Dim last_hfree_number As String
        Dim last_hex_number As String

        Dim txn_id As String

        total_header_line = ""
        total_detail_line = ""
        total_rheader_line = ""
        total_rdetail_line = ""
        txn_id = ""
        van_code = Right(ddlVanId.Text.Trim, 3)
        If ddlVanId.Text.Trim <> "ALL" Then

            strsql = "select count(*) as totrec from txn_header with (nolock) where van_id  = '" + van_code + "' and CONVERT(nvarchar(10),cr_date,112) = '" + Replace(Me.txtDateFrom.Text.Trim, "/", "") + "'"
            myDataTable = ExeSQLGetDataTable(strsql)
            If myDataTable.Rows.Count > 0 Then
                total_rheader_line = myDataTable.Rows(0).Item("totrec").ToString
            End If

            strsql = "select count(*) as totrec from txn_detail with (nolock) where refDocNo in (select refDocNo from txn_header with (nolock) where van_id  = '" + van_code + "' and CONVERT(nvarchar(10),cr_date,112) = '" + Replace(Me.txtDateFrom.Text.Trim, "/", "") + "')"
            myDataTable = ExeSQLGetDataTable(strsql)
            If myDataTable.Rows.Count > 0 Then
                total_rdetail_line = myDataTable.Rows(0).Item("totrec").ToString
            End If

            strsql = "select top 1 * from pda_sync_rec with (nolock) where vanCode = '" + van_code + "' and req_type = 'U' and convert(nvarchar(10),req_time,112) = '" + Replace(Me.txtDateFrom.Text.Trim, "/", "") + "' order by req_time desc"
            myDataTable = ExeSQLGetDataTable(strsql)

            If myDataTable.Rows.Count > 0 Then
                txn_id = myDataTable.Rows(0).Item("transaction_id").ToString
                If InStr(txn_id, "-") > 0 Then
                    total_header_line = Split(txn_id, "-")(1)
                    total_detail_line = Split(txn_id, "-")(2)
                    If RTrim(LTrim(total_detail_line)) <> RTrim(LTrim(total_rdetail_line)) Or RTrim(LTrim(total_header_line)) <> RTrim(LTrim(total_rheader_line)) Then
                        lbl_checking.Text = "ERROR Record not match !!!! PDA upload Header " + total_header_line + "/" + total_rheader_line + " upload Detail " + total_detail_line + "/" + total_rdetail_line

                    Else
                        'lbl_checking.Text = "PDA upload Header " + total_header_line + " upload Detail " + total_detail_line
                        lbl_checking.Text = ""
                    End If
                Else
                    lbl_checking.Text = ""
                End If


            Else
                lbl_checking.Text = "PDA not yet upload"
            End If
        Else
            lbl_checking.Text = ""
        End If

        last_ex_number = ""
        last_free_number = ""
        last_sale_number = ""
        last_hex_number = ""
        last_hfree_number = ""
        last_hsale_number = ""

        If lbl_checking.Text = "" And ddlVanId.Text.Trim <> "ALL" Then
            strsql = "select * from business_unit with (nolock) where vanCode = 'C_HK2ZK" + van_code + "'"
            myDataTable = ExeSQLGetDataTable(strsql)
            If myDataTable.Rows.Count > 0 Then
                last_ex_number = myDataTable.Rows(0).Item("last_exchange_no").ToString
                last_sale_number = myDataTable.Rows(0).Item("last_sale_no").ToString
                last_free_number = myDataTable.Rows(0).Item("last_sample_no").ToString
            End If

            strsql = "select top 1 refDocNo from txn_header with (nolock) where van_id = '" + van_code + "' and convert(nvarchar(10),cr_date,112) = '" + Replace(Me.txtDateFrom.Text.Trim, "/", "") + "' and refDocNo like 'SA%' order by refdocno desc"
            myDataTable = ExeSQLGetDataTable(strsql)
            If myDataTable.Rows.Count > 0 Then
                last_hsale_number = Mid(myDataTable.Rows(0).Item("refDocNo").ToString, 3, 9)
            Else
                last_hsale_number = ""
            End If

            strsql = "select top 1 refDocNo from txn_header with (nolock) where van_id = '" + van_code + "' and convert(nvarchar(10),cr_date,112) = '" + Replace(Me.txtDateFrom.Text.Trim, "/", "") + "' and refDocNo like 'EX%' order by refdocno desc"
            myDataTable = ExeSQLGetDataTable(strsql)
            If myDataTable.Rows.Count > 0 Then
                last_hex_number = Mid(myDataTable.Rows(0).Item("refDocNo").ToString, 3, 9)
            Else
                last_hex_number = ""
            End If

            strsql = "select top 1 refDocNo from txn_header with (nolock) where van_id = '" + van_code + "' and convert(nvarchar(10),cr_date,112) = '" + Replace(Me.txtDateFrom.Text.Trim, "/", "") + "' and refDocNo like 'SF%' order by refdocno desc"
            myDataTable = ExeSQLGetDataTable(strsql)
            If myDataTable.Rows.Count > 0 Then
                last_hfree_number = Mid(myDataTable.Rows(0).Item("refDocNo").ToString, 3, 9)
            Else
                last_hfree_number = ""
            End If

            If last_hsale_number <> "" And last_sale_number <> last_hsale_number Then
                lbl_checking.Text = "ERROR UPLOAD SALES Not match " + last_sale_number + "/" + last_hsale_number + " "
            End If

            If last_hex_number <> "" And last_ex_number <> last_hex_number Then
                lbl_checking.Text = lbl_checking.Text + "ERROR UPLOAD EXCHANGE Not match " + last_ex_number + "/" + last_hex_number + " "
            End If

            If last_hfree_number <> "" And last_free_number <> last_hfree_number Then
                lbl_checking.Text = lbl_checking.Text + "ERROR UPLOAD SAMPLE Not match " + last_free_number + "/" + last_hfree_number
            End If

        End If



    End Sub

    Protected Sub gv_custmaster_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gv_custmaster.Sorting
        getString()        
    End Sub

    Private Sub getString()
        
        Try


            Dim strDate As String = Me.txtDateFrom.Text.Trim
            Dim strVanId As String = ddlVanId.Text.Trim
            Dim strDateSql As String = String.Empty
            Dim strVanSql As String = String.Empty
            Dim strSql As String = String.Empty
            Dim getCodeDataTable As DataTable
            Dim strFrom As String = ""
            Dim strTo As String = ""

            If (strDate <> "") Then
                If Not (strDate Like "####[/]##[/]##" Or IsDate(strDate)) Then
                    gErr = "alert('[Date From] error! \n')"
                    Return
                End If
                G_strYear = " and year(h.cr_date) = '" & CDate(strDate).ToString("yyyy") & "' "
                G_strMonth = " and month(h.cr_date) = '" & CDate(strDate).ToString("MM") & "' "

                strDateSql = " and convert(varchar,h.cr_date,111) = '" & strDate & "' "

                getDateFromTo(strFrom, strTo, txtDateFrom.Text)
                G_strMTDselection = " and convert(varchar(10),h.cr_date,111) >= '" & strFrom & "' and  convert(varchar(10),h.cr_date,111) <= '" & strTo & "'"
            End If

            Select Case strVanId
                Case ""     ' No such case. Already handled by JavaScript
                    strVanSql = String.Empty
                Case "ALL"  ' If search by all van, no need to filter out any.
                    strVanSql = String.Empty
                Case Else
                    strVanSql = " AND RIGHT(h.van_id, 3) = '" & Right(strVanId, 3) & "' "
            End Select

            G_strDate = strDateSql
            G_strVanId = strVanSql

            If (SqlMainSource.SelectParameters.Count > 0) Then
                SqlMainSource.SelectParameters.Clear()
            End If
           
            SqlMainSource.SelectParameters.Add("date", strDate)
            If strVanId = "ALL" Then
                ' Get the minimum van code and maximum van code
                strSql = "SELECT RIGHT(MIN(vanCode), 3) AS minCode, RIGHT(MAX(vanCode), 3) AS maxCode FROM business_unit"
                getCodeDataTable = ExeSQLGetDataTable(strSql)
                If getCodeDataTable.Rows.Count > 0 Then
                    SqlMainSource.SelectParameters.Add("minVan", getCodeDataTable.Rows(0).Item("minCode").ToString)
                    SqlMainSource.SelectParameters.Add("maxVan", getCodeDataTable.Rows(0).Item("maxCode").ToString)
                End If
            Else
                ' For individual van, list in this order: Sample, Exchange and Sale (Pre-order and regular sale)
                SqlMainSource.SelectParameters.Add("minVan", Right(strVanId, 3))
                SqlMainSource.SelectParameters.Add("maxVan", Right(strVanId, 3))
            End If

        Catch ex As Exception
          

        End Try


    End Sub




    Private Sub getDateFromTo(ByRef strFrom As String, ByRef strTo As String, ByVal strFromDate As String)
        Dim myDataTable As DataTable
        Dim strSql As String = " select finyear + finperiod as period,  isnull(CONVERT(varchar(10),MIN(startDate),111),'') a, isnull(CONVERT(varchar(10),MAX(EndDate),111),'') b " & _
           " from fin_period where Finyear + FinPeriod in (select FinYear + FinPeriod from fin_period " & _
        String.Format(" where '{0}' >= CONVERT(varchar(10),StartDate,111) and '{0}' <= CONVERT(varchar(10),enddate,111) )", strFromDate) & _
        " group by finyear, finperiod "
        myDataTable = ExeSQLGetDataTable(strSql)
        If myDataTable.Rows.Count > 0 Then
            G_strPeriod = myDataTable.Rows.Item(0)("period")
            strFrom = myDataTable.Rows.Item(0)("a")
            strTo = myDataTable.Rows.Item(0)("b")
        End If
        If strFrom <> "" Then
            lblPeriod.Text = "Financial Period (" & G_strPeriod & ") : " & strFrom & " - " & strTo
        Else
            lblPeriod.Text = ""
        End If

    End Sub

End Class
