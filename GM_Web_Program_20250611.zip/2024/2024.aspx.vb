﻿'---------------------------------------------------------------------------- 
'程式功能	ITEM Master Maintenance
'---------------------------------------------------------------------------- 
Imports System
Imports System.Collections.Generic
Imports System.Web
Imports System.Web.UI
Imports System.Data.SqlClient
Imports System.Web.UI.WebControls
Imports System.Data.OleDb
Imports System.IO
Imports System.Data

Partial Class _2024
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()

            ' 檢查使用者權限並存入登入紀錄。 
            Check_Power("2024", True)

            '接受下一頁返回時的舊查詢條件" 
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid"), ckint) Then
                    GridView1.PageIndex = ckint
                Else
                    lb_pageid.Text = "0"
                End If
            End If

        End If
    End Sub

    Private Property updateMode() As String
        Get
            Return ViewState("updateMode")
        End Get
        Set(ByVal value As String)
            ViewState("updateMode") = value
        End Set
    End Property

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            'If cfc.Check_Power(Session("stk_code").ToString(), Session("stk_desc").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
            'ImageUrl='<%# "data:Image/png;base64," + Convert.ToBase64String((byte[])Eval("photo")) %>' 
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub gv_itemmaster_PageIndexChanged(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        lb_pageid.Text = e.NewPageIndex()
    End Sub

    Protected Sub Btn_Set_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Btn_Set.Click
        ' 檢查查詢條件是否改變 
        Chk_Filter()
    End Sub

    ' 檢查查詢條件是否改變 
    Private Sub Chk_Filter()
        Dim cfc As New Common_Func()

        Dim strFromDate = txtfromDate.Text
        Dim strToDate = txttoDate.Text
        Dim strpid = ddlperiod.Text

        Dim strSql As String = " SELECT finyear, finperiod, substring(convert(nvarchar, startdate, 111),1,10) as startdate, " & _
                " substring(convert(nvarchar, enddate, 111),1,10) as enddate  from fin_period "
        strSql += " where 1=1 "
        If strpid <> "" Then strSql += " and finyear = '" & strpid & "' "
        If strFromDate <> "" Then strSql += " and startdate >= '" & strFromDate & "' "
        If strToDate <> "" Then strSql += " and enddate <= '" & strToDate & "' "

        strSql += " order by finyear, startdate "
        dsfinperiod.SelectCommand = strSql

        GridView1.DataBind()
        If GridView1.PageCount - 1 < GridView1.PageIndex Then
            GridView1.PageIndex = GridView1.PageCount
            GridView1.DataBind()
        End If

        lb_pageid.Text = GridView1.PageIndex.ToString()
    End Sub


    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs)

        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim lb As LinkButton = DirectCast(e.Row.Cells(5).Controls(0), LinkButton)
            lb.OnClientClick = "return confirm('Confirm to delete record ?')"
        End If

    End Sub

    Protected Sub GridView1_RowCommand(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        Dim fperiod As String = ""
        Dim fyear As String = ""
        'If e.CommandName = "Update" Then
        '    Dim txtUpdate As TextBox = DirectCast(gv_itemmaster.Rows(e.CommandArgument).Controls(7).Controls(0), TextBox)
        '    Dim strmaterialDescChi As String = txtUpdate.Text
        '    Dim strmaterialGroup As String = gv_itemmaster.Rows(e.CommandArgument).Cells(0).Text

        '    If strmaterialDescChi.Trim <> "" Then
        '        dsMaterial.UpdateCommand = "UPDATE item_master SET block = '1' where materialCode = @materialCode"
        '    Else
        '        dsMaterial.UpdateCommand = "UPDATE item_master SET block = '' where materialCode = @materialCode"
        '    End If
        'End If
        If e.CommandName = "Edit" Then
            fperiod = GridView1.Rows(e.CommandArgument).Cells(1).Text
            fyear = GridView1.Rows(e.CommandArgument).Cells(0).Text
            Response.Redirect("2024_edit.aspx?fyear=" & fyear & "&fperiod=" & fperiod)

        End If

        If e.CommandName = "Delete" Then
            fperiod = GridView1.Rows(e.CommandArgument).Cells(1).Text
            fyear = GridView1.Rows(e.CommandArgument).Cells(0).Text
            dsfinperiod.DeleteCommand = " delete from fin_period where finyear = '" & fyear & "' and finperiod = '" & fperiod & "' "
            dsfinperiod.Delete()
            dsfinperiod.DataBind()

        End If

        Chk_Filter()
    End Sub



    'Protected Sub GV_deleting(ByVal sender As Object, ByVal e As GridViewDeleteEventArgs)
    '    Dim r As GridViewRow = GridView1.Rows(e.RowIndex)
    '    Dim strMaterialCode As String = CType(r.FindControl("lblphotoid"), Label).Text

    '    'dsMaterial.DeleteCommand = " delete from gm_photo where photo_id = '" & strMaterialCode & "'"
    '    'dsMaterial.Delete()
    '    'dsMaterial.DataBind()
    '    'Using Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
    '    '    Dim SqlString As String = ""
    '    '    SqlString = "  update customer_material_info_pda set is_active = 1 "
    '    '    SqlString += " update customer_material_info_pda set is_active = 0 from customer_group_master g inner join customer_material_info_pda p on g.custGroup = p.custGroup where block = 1 "
    '    '    SqlString += " update customer_material_info_pda set is_active = 0 where materialCode in(select distinct materialCode from listing)"
    '    '    SqlString += " update customer_material_info_pda set is_active = 1 from customer_material_info_pda p inner join listing l on l.custGroup =p.custGroup and l.materialCode = p.materialCode"

    '    '    Using Sql_Command As New SqlCommand()
    '    '        Sql_Command.Connection = Sql_conn
    '    '        Sql_Command.CommandText = SqlString
    '    '        Sql_conn.Open()
    '    '        Sql_Command.ExecuteNonQuery()
    '    '        Sql_conn.Close()
    '    '        Sql_Command.Dispose()
    '    '    End Using
    '    'End Using


    'End Sub



    Protected Sub btnUpload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpload.Click
        Dim connectionString As String = ""
        If FileUpload1.HasFile Then


            Dim fileName As String = Path.GetFileName(FileUpload1.PostedFile.FileName)
            Dim fileExtension As String = Path.GetExtension(FileUpload1.PostedFile.FileName)
            Dim fileLocation As String = Server.MapPath("~/ExcelExport/" & fileName)
            FileUpload1.SaveAs(fileLocation)
            If fileExtension = ".xls" Then
                connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=2"""
                connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 12.0;HDR=Yes"""

            ElseIf fileExtension = ".xlsx" Then
                'connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 12.0;HDR=Yes;IMEX=2"""
                connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 12.0 xml;HDR=Yes"""

            Else
                ClientScript.RegisterStartupScript(Me.GetType(), "errorScript", "alert('" & "Please select MS Excel file" & "');", True)
                Exit Sub
            End If

            GridView1.DataSource = Nothing

            Dim con As New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand()
            cmd.CommandType = System.Data.CommandType.Text
            cmd.Connection = con
            Dim dAdapter As New OleDbDataAdapter(cmd)
            Dim dtExcelRecords As New DataTable()
            Try
                con.Open()

                Dim dtExcelSheetName As DataTable = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)
                Dim getExcelSheetName As String = ""
                If dtExcelSheetName.Rows.Count > 1 Then
                    getExcelSheetName = dtExcelSheetName.Rows(1)("Table_Name").ToString()
                Else
                    getExcelSheetName = "Sheet1$"
                End If
                cmd.CommandText = "SELECT ucase(finyear) as finyear, ucase(finperiod) as finperiod , startdate, enddate FROM [" & getExcelSheetName & "] where finyear is not null "
                dAdapter.SelectCommand = cmd
                dAdapter.Fill(dtExcelRecords)
                con.Close()

                dtExcelRecords.Columns(0).ColumnName = "finyear"
                dtExcelRecords.Columns(1).ColumnName = "finperiod"
                dtExcelRecords.Columns(2).ColumnName = "startdate"
                dtExcelRecords.Columns(3).ColumnName = "enddate"

                If InsertExceltoDB(dtExcelRecords) = True Then
                    ' ddlCode.DataBind()
                    GridView1.DataBind()
                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Upload Completed');", True)
                Else
                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Upload Failed. Please choose the right file');", True)
                End If

            Catch ex As Exception
                Dim sPath = HttpContext.Current.Server.MapPath("~/ExcelExport")
                Dim objWriter As New System.IO.StreamWriter(sPath + "/fin_error" & ".txt")

                objWriter.WriteLine(ex.Message)
                objWriter.Close()

                'ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Upload Failed. Please choose the right file');", True)
                ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('" & Replace(ex.Message, "'", "") & "');", True)
            End Try

        Else
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Please select an excel file');", True)
        End If
    End Sub

    Private Function InsertExceltoDB(ByVal dt As DataTable) As Boolean
        Dim sTime As String = Today.Year & Today.Month & Today.Day & DateTime.Now.Hour & DateTime.Now.Minute & DateTime.Now.Second
        Dim sPath = HttpContext.Current.Server.MapPath("~/ExcelExport")

        'Dim objWriter As New System.IO.StreamWriter(sPath + "/fin_impdb" & sTime & ".txt")


        Dim isSucceed As Boolean = False
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim tran As SqlTransaction
        Dim da As New SqlDataAdapter
        Dim cmd As New SqlCommand()
        cmd.Connection = conn
        cmd.Connection.Open()
        tran = conn.BeginTransaction
        cmd.Transaction = tran
        Dim strSql As String
        Try
            strSql = " delete from fin_period "

            ' objWriter.WriteLine(strSql)

            cmd = New SqlCommand(strSql, conn)
            cmd.Transaction = tran
            cmd.ExecuteNonQuery()

            strSql = "Insert Into [fin_period] (finyear, finperiod, startdate, enddate) " & _
                         " values(@finyear, @finperiod, @startdate, @enddate) "
            ' objWriter.WriteLine(strSql)

            cmd = New SqlCommand(strSql, conn)

            cmd.CommandType = CommandType.Text
            cmd.Transaction = tran
            cmd.Parameters.Add("@finyear", SqlDbType.NVarChar, 500, "finyear")
            cmd.Parameters.Add("@finperiod", SqlDbType.NVarChar, 500, "finperiod")
            cmd.Parameters.Add("@startdate", SqlDbType.NVarChar, 500, "startdate")
            cmd.Parameters.Add("@enddate", SqlDbType.NVarChar, 500, "enddate")
            Dim i As Integer
            For Each dr As DataRow In dt.Rows
                dr.SetAdded()
                i = i + 1
                ' objWriter.WriteLine(i.ToString())
            Next
            da.InsertCommand = cmd
            da.Update(dt)

            tran.Commit()
            isSucceed = True
        Catch ex As Exception
            Dim smsg As String = ex.Message


            tran.Rollback()
            isSucceed = False
        End Try

        'objWriter.Close()

        cmd.Dispose()
        da.Dispose()
        conn.Dispose()
        Return isSucceed
    End Function


    Protected Sub btnExport_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnExport.Click
        
        Try
            Dim dtCurrentRecord As New DataTable
            Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)

            Dim strSql As String = "  select finyear, finperiod, substring(convert(nvarchar, startdate, 120),1,10) as startdate, " & _
                " substring(convert(nvarchar, enddate, 120),1,10) as enddate from fin_period order  by finyear, startdate "

            Dim cmd As New SqlCommand(strSql, conn)
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            Dim da As New SqlDataAdapter(cmd)
            cmd.Connection.Open()
            da.Fill(dtCurrentRecord)
            cmd.Connection.Close()
            cmd.Dispose()
            da.Dispose()
            dtCurrentRecord.TableName = "FinPeriod"
            Dim strFileName As String = "ExcelExport_" + "_" + Format(TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))), "yyyyMMddhhmmss") + ".xls"
            Dim strNewPath As String = HttpContext.Current.Server.MapPath("~/ExcelExport/" & strFileName)
            Dim strPhysicalPath As String = HttpContext.Current.Server.MapPath("~/ExcelExport/" & strFileName)

            If Not IO.Directory.Exists(HttpContext.Current.Server.MapPath("~/ExcelExport")) Then
                IO.Directory.CreateDirectory(HttpContext.Current.Server.MapPath("~/ExcelExport"))
            End If

            Dim connectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & strNewPath & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=2"""
            connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & strNewPath & ";Extended Properties=""Excel 12.0 xml;Mode=ReadWrite;HDR=Yes"""

            InsertDBtoExcel(dtCurrentRecord, connectionString)

            HttpContext.Current.Response.Clear()
            Response.WriteFile(strNewPath)
            Dim httpHeader As String = "attachment;filename=" + "Fin_period" + ".xlsx"
            HttpContext.Current.Response.ContentType = "application/vnd.ms-excel"
            HttpContext.Current.Response.AppendHeader("Content-Disposition", httpHeader)
            HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.Unicode


            HttpContext.Current.Response.Flush()
            System.IO.File.Delete(strNewPath)
            HttpContext.Current.Response.End()
        Catch ex As Exception
            Dim sMsg As String
            ' sMsg = ex.Message

            'Response.Write(ex.Message)
            'Finally
            Dim sTime As String = Today.Year & Today.Month & Today.Day & DateTime.Now.Hour & DateTime.Now.Minute & DateTime.Now.Second
            Dim sPath = HttpContext.Current.Server.MapPath("~/ExcelExport")

            Dim objWriter As New System.IO.StreamWriter(sPath + "/fin_expdb" & sTime & ".txt")
            objWriter.WriteLine("Export")
            objWriter.WriteLine(sMsg)
            objWriter.Close()

        End Try


    End Sub


    Private Sub InsertDBtoExcel(ByVal dt As DataTable, ByVal connectionString As String)

        Dim sTime As String = Today.Year & Today.Month & Today.Day & DateTime.Now.Hour & DateTime.Now.Minute & DateTime.Now.Second
        Dim sPath = HttpContext.Current.Server.MapPath("~/ExcelExport")

        'Dim objWriter As New System.IO.StreamWriter(sPath + "/fin_expdb" & sTime & ".txt")
        'objWriter.WriteLine("start")

        Try

            Dim strTable As String = ""
            strTable = "CREATE TABLE [" & dt.TableName & "]("

            Dim j As Integer = 0
            For j = 0 To dt.Columns.Count - 1
                Dim dCol As DataColumn
                dCol = dt.Columns(j)

                strTable &= " [" & dCol.ColumnName & "] nvarchar(255) , "


            Next
            strTable = strTable.Substring(0, strTable.Length - 2)
            strTable &= ")"

            'objWriter.WriteLine(strTable)

            Dim conn As OleDbConnection = New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand(strTable, conn)
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            cmd.Dispose()


            Dim strInsert As String
            strInsert = "Insert Into " & dt.TableName & " Values ("
            For k As Integer = 0 To dt.Columns.Count - 1
                strInsert &= "@" & dt.Columns(k).ColumnName & " , "
            Next
            strInsert = strInsert.Substring(0, strInsert.Length - 2)
            strInsert &= ")"

            'objWriter.WriteLine("Insert")

            ' objWriter.WriteLine(strInsert)

            conn.Open()
            For j = 0 To dt.Rows.Count - 1
                Dim cmd2 As New OleDbCommand(strInsert, conn)
                For k As Integer = 0 To dt.Columns.Count - 1

                    cmd2.Parameters.AddWithValue("@" & dt.Columns(k).ColumnName.ToString(), dt.Rows(j)(k).ToString())

                Next

                cmd2.ExecuteNonQuery()

                'objWriter.WriteLine(j.ToString())

                cmd2.Parameters.Clear()
                cmd2.Dispose()
            Next
            conn.Close()
            ' objWriter.Close()
        Catch ex As Exception
            ' objWriter.WriteLine("err")
            'objWriter.WriteLine(ex.Message())
            ' objWriter.Close()

        End Try


    End Sub


End Class
