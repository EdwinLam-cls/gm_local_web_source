﻿'---------------------------------------------------------------------------- 
'程式功能	UOM Master > 明細內容 > 新增資料
'---------------------------------------------------------------------------- 

Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration
Imports System.IO
Imports System.Drawing

Partial Class _2025_2025_edit
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0

            ' 檢查使用者權限但不存入登入紀錄 
            Check_Power("2025", False)

            ' 承接上一頁的查詢條件設定
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid").ToString(), ckint) Then
                    lb_page.Text = "?pageid=" & ckint.ToString()
                Else
                    lb_page.Text = "?pageid=0"
                End If
            End If

            If Request("Code") IsNot Nothing Then
                lb_page.Text &= "&Code=" & Request("Code")
                LoadPhoto(Request("Code"))
            End If

        End If
    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub LoadPhoto(ByVal code As String)
        Dim mErr As String = ""
        Dim mg_sid As Integer = -1



        ' 取得連絡人資料
        If mErr = "" Then
            Using Sql_Conn1 As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                Dim SqlString1 As String = ""
                Dim decoder1 As New Decoder()

                SqlString1 = "SELECT transaction_id, substring(workdate,1,4) +'/'+substring(workdate,5,2) + '/' +substring(workdate,7,2) as workdate, vancode, custno, photo, update_date, updated_by from visit_photo "

                SqlString1 &= " Where transaction_id = @code "


                Using Sql_Command1 As New SqlCommand(SqlString1, Sql_Conn1)
                    Sql_Conn1.Open()

                    Sql_Command1.Parameters.AddWithValue("code", code)
                    'Sql_Command1.Parameters.AddWithValue("cate_desc_c", tb_cate_desc_c.Text.ToUpper)
                    'Sql_Command1.Parameters.AddWithValue("cate_desc_e", tb_cate_desc_e.Text.ToUpper)

                    Using Sql_Reader1 As SqlDataReader = Sql_Command1.ExecuteReader()
                        If Sql_Reader1.Read() Then
                            lblID.InnerText = Sql_Reader1(0).ToString()
                            txtWorkDate.Text = Sql_Reader1(1).ToString()
                            txtVancode.Text = Sql_Reader1(2).ToString()
                            txtCustNo.Text = Sql_Reader1(3).ToString()
                        Else

                            mErr = "Trans ID  err !\n"
                        End If
                    End Using
                    Sql_Command1.Dispose()
                End Using

            End Using

            FetchImage()

        End If


        'If mErr = "" Then
        '    Using Sql_conn As New SqlConnection(WebConfigurationManager.ConnectionStrings("AppSysConnectionString").ConnectionString)
        '        Dim SqlString As String = ""
        '        Dim decoder As New Decoder()


        '        ' 建立 SQL 的語法 
        '        SqlString = "Insert Into cate (cate_code, cate_desc_e, cate_desc_c, cate_type)"
        '        SqlString &= " Values (@cate_code, UPPER(@cate_desc_e), UPPER(@cate_desc_c), @cate_type);"

        '        Using Sql_Command As New SqlCommand()
        '            Sql_Command.Connection = Sql_conn
        '            Sql_Command.CommandText = SqlString

        '            ' 擷取字串到資料庫所規範的大小 sfc.Left(string mdata, int leng) 
        '            ' Sql_Command.Parameters.AddWithValue("@cate_code", sfc.Left(tb_cate_code.Text, 4))
        '            ' Sql_Command.Parameters.AddWithValue("@cate_desc_e", sfc.Left(tb_cate_desc_e.Text, 100))
        '            ' Sql_Command.Parameters.AddWithValue("@cate_desc_c", sfc.Left(tb_cate_desc_c.Text, 100))
        '            ' Sql_Command.Parameters.AddWithValue("@cate_type", sfc.Left(tb_cate_type.Text, 1))

        '            'Dim spt_mg_sid As SqlParameter = Sql_Command.Parameters.Add("@UOM_ID", SqlDbType.Int)
        '            'spt_mg_sid.Direction = ParameterDirection.Output

        '            Sql_conn.Open()

        '            Sql_Command.ExecuteNonQuery()
        '            Sql_Command.Dispose()

        '            ' 取得新增資料的主鍵值 
        '            mg_sid = 0
        '        End Using
        '    End Using
        'End If

        'If mErr = "" Then
        '    mErr = ("alert('存檔完成!\n');location.replace('2016.aspx" & lb_page.Text & "&sid=") + mg_sid.ToString() & "');"
        'Else
        '    mErr = "alert('" & mErr & "')"
        'End If

        'lt_show.Text = "<script language=javascript>" & mErr & "</script>"
    End Sub


    'Protected Sub btnUpload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpload.Click
    '    Dim connectionString As String = ""
    '    Dim errMsg As String = ""
    '    If FileUpload1.HasFile Then

    '        Dim fileName As String = Path.GetFileName(FileUpload1.PostedFile.FileName)
    '        Dim fileExtension As String = Path.GetExtension(FileUpload1.PostedFile.FileName)
    '        Dim fileLocation As String = Server.MapPath("~/Photo/" & fileName)
    '        FileUpload1.SaveAs(fileLocation)

    '    End If

    'End Sub


    'Protected Sub lb_ok_Click(ByVal sender As Object, ByVal e As EventArgs)
    '    Dim mErr As String = ""
    '    Dim mg_sid As Integer = -1
    '    Dim intCountGroupNo As Integer = 0
    '    Dim pid As String = ""
    '    Dim sqlString As String = ""

    '    Dim fileName As String = Path.GetFileName(FileUpload1.PostedFile.FileName)
    '    Dim fileExtension As String = Path.GetExtension(FileUpload1.PostedFile.FileName)
    '    Dim fileLocation As String = Server.MapPath("~/Photo/" & fileName)

    '    Dim length As Integer = FileUpload1.PostedFile.ContentLength
    '    Dim imgbyte As Byte() = New Byte(length - 1) {}
    '    Dim img As HttpPostedFile = FileUpload1.PostedFile


    '    If txtValidFrom.Text = "" Then
    '        mErr &= "Please input Valid From Date\n"
    '    End If

    '    If txtValidTo.Text = "" Then
    '        mErr &= "Please input Valid To Date\n"
    '    End If

    '    If FileUpload1.HasFile And mErr = "" Then


    '        FileUpload1.SaveAs(fileLocation)
    '        Dim imag As Image
    '        imag = Image.FromFile(fileLocation)
    '        Dim wi As Double = imag.Width
    '        Dim he As Double = imag.Height
    '        If wi > he Then
    '            imag.RotateFlip(RotateFlipType.Rotate90FlipNone)
    '            imag.Save(fileLocation)

    '        End If
    '        Dim ms As New MemoryStream()
    '        imag.Save(ms, Drawing.Imaging.ImageFormat.Png)
    '        imgbyte = ms.GetBuffer()
    '        'img.InputStream.Read(imgbyte, 0, length)

    '        Using Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
    '            pid = Request("code").ToString()
    '            Sql_conn.Open()
    '            If mErr = "" Then
    '                ' 建立 SQL 的語法 
    '                sqlString = "update gm_photo set photo = @image where photo_id = @photoid "

    '                Using Sql_Command As New SqlCommand()
    '                    Sql_Command.Connection = Sql_conn
    '                    Sql_Command.CommandText = sqlString

    '                    Sql_Command.Parameters.AddWithValue("@photoid", pid)
    '                    Sql_Command.Parameters.AddWithValue("@image", imgbyte)

    '                    Sql_Command.ExecuteNonQuery()
    '                    Sql_Command.Dispose()

    '                    ' 取得新增資料的主鍵值 
    '                    mg_sid = 0
    '                End Using
    '            End If
    '        End Using

    '    End If

    '    If mErr = "" Then
    '        Using Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
    '            pid = Request("code").ToString()

    '            If mErr = "" Then
    '                ' 建立 SQL 的語法 
    '                sqlString = "update gm_photo set fromdate = @frdate, todate = @todate where photo_id = @photoid "
    '                Sql_conn.Open()

    '                Using Sql_Command As New SqlCommand()
    '                    Sql_Command.Connection = Sql_conn
    '                    Sql_Command.CommandText = sqlString

    '                    Sql_Command.Parameters.AddWithValue("@photoid", pid)
    '                    'Sql_Command.Parameters.AddWithValue("@image", imgbyte)
    '                    Sql_Command.Parameters.AddWithValue("@frdate", txtValidFrom.Text.Trim())
    '                    Sql_Command.Parameters.AddWithValue("@todate", txtValidTo.Text.Trim())

    '                    Sql_Command.ExecuteNonQuery()
    '                    Sql_Command.Dispose()

    '                    ' 取得新增資料的主鍵值 
    '                    mg_sid = 0
    '                End Using
    '            End If
    '        End Using

    '    End If



    '    If mErr = "" Then
    '        mErr = ("alert('Save Success!\n');location.replace('2021.aspx") & "');"
    '    Else
    '        mErr = "alert('" & mErr & "')"
    '    End If

    '    lt_show.Text = "<script language=javascript>" & mErr & "</script>"


    'End Sub


    Private Function GetPic(ByVal query As String) As DataTable
        Dim dt As New DataTable()
        Dim constr As String = DBConnUtil.GetConnectionString().ConnectionString
        Using con As New SqlConnection(constr)
            Using cmd As New SqlCommand(query)
                Using sda As New SqlDataAdapter()
                    cmd.CommandType = CommandType.Text
                    cmd.Connection = con
                    sda.SelectCommand = cmd
                    sda.Fill(dt)
                End Using
            End Using
            Return dt
        End Using
    End Function

    Protected Sub FetchImage()
        Dim id As String = Request("code")
        Image1.Visible = id <> "0"
        If id <> "0" Then
            Dim bytes As Byte() = DirectCast(GetPic(Convert.ToString("SELECT photo FROM visit_photo WHERE transaction_Id ='") & id & "'").Rows(0)("photo"), Byte())
            Dim base64String As String = Convert.ToBase64String(bytes, 0, bytes.Length)
            Image1.ImageUrl = Convert.ToString("data:image/png;base64,") & base64String
        End If
    End Sub
End Class
