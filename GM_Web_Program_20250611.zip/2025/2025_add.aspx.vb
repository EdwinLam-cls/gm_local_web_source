﻿'---------------------------------------------------------------------------- 
'程式功能	UOM Master > 明細內容 > 新增資料
'---------------------------------------------------------------------------- 

Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration
Imports System.IO
Imports System.Drawing

Partial Class _2025_2025_add
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0

            ' 檢查使用者權限但不存入登入紀錄 
            Check_Power("2025", False)

            ' 承接上一頁的查詢條件設定
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid").ToString(), ckint) Then
                    lb_page.Text = "?pageid=" & ckint.ToString()
                Else
                    lb_page.Text = "?pageid=0"
                End If
            End If

            If Request("Code") IsNot Nothing Then
                lb_page.Text &= "&Code=" & Request("Code")
            End If

        End If
    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub



    Protected Sub btnUpload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpload.Click
        Dim connectionString As String = ""
        Dim errMsg As String = ""
        If FileUpload1.HasFile Then

            Dim fileName As String = Path.GetFileName(FileUpload1.PostedFile.FileName)
            Dim fileExtension As String = Path.GetExtension(FileUpload1.PostedFile.FileName)
            Dim fileLocation As String = Server.MapPath("~/Photo/" & fileName)
            FileUpload1.SaveAs(fileLocation)

            Image1.ImageUrl = fileLocation

        End If

    End Sub


    Protected Sub lb_ok_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim mErr As String = ""
        Dim mg_sid As Integer = -1
        Dim intCountGroupNo As Integer = 0
        Dim sfc As New String_Func()
        Dim imgbyte As Byte()
        Dim sToday As String = ""

        ' 載入公用函數 
        Dim cfc As New Common_Func()

        If txtValidFrom.Text = "" Then
            mErr &= "Please input Valid From Date\n"
        End If

        If txtValidTo.Text = "" Then
            mErr &= "Please input Valid To Date\n"
        End If

        If txtValidFrom.Text <> "" And txtValidTo.Text > "" Then
            If DateDiff(DateInterval.Day, Convert.ToDateTime(txtValidFrom.Text), Convert.ToDateTime(txtValidTo.Text)) < 0 Then
                mErr &= "Valid To Date must be later than From Date \n"
            End If
        End If

        If FileUpload1.HasFile Then
            ' Dim length As Integer
            'Dim imgbyte As Byte()
            'Dim img As HttpPostedFile

            Dim fileName As String = Path.GetFileName(FileUpload1.PostedFile.FileName)
            Dim fileExtension As String = Path.GetExtension(FileUpload1.PostedFile.FileName)
            Dim fileLocation As String = Server.MapPath("~/Photo/" & fileName)
            FileUpload1.SaveAs(fileLocation)

            Dim imag As Image
            imag = Image.FromFile(fileLocation)
            Dim wi As Double = imag.Width
            Dim he As Double = imag.Height
            If wi > he Then
                imag.RotateFlip(RotateFlipType.Rotate90FlipNone)
                imag.Save(fileLocation)

            End If


            'Dim length As Integer = FileUpload1.PostedFile.ContentLength
            'Dim imgbyte As Byte() = New Byte(length - 1) {}
            'Dim img As HttpPostedFile = FileUpload1.PostedFile

            Dim ms As New MemoryStream()
            imag.Save(ms, Drawing.Imaging.ImageFormat.Png)
            imgbyte = ms.GetBuffer()

            'img.InputStream.Read(imgbyte, 0, length)

            sToday = Today.Year & sfc.FillLeft(Today.Month.ToString(), 2) & sfc.FillLeft(Today.Day.ToString(), 2)

            Using Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                Dim SqlString As String = ""
                ' Dim decoder As New Decoder()
                Dim pid As String = ""
                SqlString &= " select isnull( max(substring(photo_id,11,3)) ,0) as pid from gm_photo where substring(photo_id,3,8) = '" & sToday & "' "

                Using Sql_Command1 As New SqlCommand(SqlString, Sql_conn)
                    Sql_conn.Open()

                    Using Sql_Reader1 As SqlDataReader = Sql_Command1.ExecuteReader()
                        If Sql_Reader1.Read() Then
                            pid = (Sql_Reader1(0) + 1).ToString()
                            pid = sfc.FillLeft(pid, 3)
                            pid = "GM" + sToday + pid
                        Else
                            mErr = "Photo ID error !\n"
                        End If
                    End Using
                    Sql_Command1.Dispose()
                End Using

                SqlString = " select max(seq_no) as seq_no from gm_photo  "
                Dim seqno As Integer
                Using Sql_Command1 As New SqlCommand(SqlString, Sql_conn)
                    Using Sql_Reader1 As SqlDataReader = Sql_Command1.ExecuteReader()
                        If Sql_Reader1.Read() Then
                            seqno = (Sql_Reader1("seq_no") + 1)

                        Else
                            mErr = "SeqNo error !\n"
                        End If
                    End Using
                    Sql_Command1.Dispose()
                End Using

                If mErr = "" Then
                    ' 建立 SQL 的語法 
                    SqlString = "Insert Into gm_photo (photo_id,seq_no, photo, fromdate, todate)"
                    SqlString &= " Values (@photoid, @seqno, @image, @frdate, @todate);"

                    Using Sql_Command As New SqlCommand()
                        Sql_Command.Connection = Sql_conn
                        Sql_Command.CommandText = SqlString

                        Sql_Command.Parameters.AddWithValue("@photoid", pid)
                        Sql_Command.Parameters.AddWithValue("@seqno", seqno)
                        Sql_Command.Parameters.AddWithValue("@image", imgbyte)
                        Sql_Command.Parameters.AddWithValue("@frdate", txtValidFrom.Text.Trim())
                        Sql_Command.Parameters.AddWithValue("@todate", txtValidTo.Text.Trim())

                        'Dim spt_mg_sid As SqlParameter = Sql_Command.Parameters.Add("@UOM_ID", SqlDbType.Int)
                        'spt_mg_sid.Direction = ParameterDirection.Output

                        ' Sql_conn.Open()

                        Sql_Command.ExecuteNonQuery()
                        Sql_Command.Dispose()

                        ' 取得新增資料的主鍵值 
                        mg_sid = 0
                    End Using
                End If
            End Using

        Else
            mErr &= "Please select Image \n"

        End If



        If mErr = "" Then
            mErr = ("alert('Save Success!\n');location.replace('2021.aspx" & lb_page.Text & "&sid=") + mg_sid.ToString() & "');"
        Else
            mErr = "alert('" & mErr & "')"
        End If

        lt_show.Text = "<script language=javascript>" & mErr & "</script>"


    End Sub


End Class
