﻿'---------------------------------------------------------------------------- 
'程式功能	Delivery Master Maintenance
'---------------------------------------------------------------------------- 
Imports System.Data.SqlClient
Imports System
Imports System.Collections.Generic
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO
Imports System.Data.OleDb
Imports System.Data
Imports System.Windows.Forms


Partial Class _6032_6032
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()

            ' 檢查使用者權限並存入登入紀錄。 
            Check_Power("6032", True)

            '接受下一頁返回時的舊查詢條件" 
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid"), ckint) Then
                    gv_delivery_master.PageIndex = ckint
                Else
                    lb_pageid.Text = "0"
                End If
            End If


            txtExportDate.Text = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))).ToString("yyyy/MM/dd")

            FileUpload1.Attributes.Add("OnChange", "return fileupload()")
        End If


    End Sub
    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            'If cfc.Check_Power(Session("stk_code").ToString(), Session("stk_desc").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try

    End Sub

    Protected Sub gv_txn_detail_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gv_delivery_master.PageIndexChanging
        gv_delivery_master.PageIndex = e.NewPageIndex
        gv_delivery_master.DataSource = ViewState("myDataTable")
        gv_delivery_master.DataBind()


    End Sub

    Protected Sub gv_txn_detail_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gv_delivery_master.Sorting
        Dim dt As DataTable = ViewState("myDataTable")
        Dim dv As DataView = dt.DefaultView
        dv.Sort = e.SortExpression + " " + ConvertSortDirectionToSql(e.SortDirection)
        gv_delivery_master.DataSource = dv
        ViewState("myDataTable") = dv.ToTable
        gv_delivery_master.DataBind()

    End Sub

    Private Function ConvertSortDirectionToSql(ByVal sortDirect As SortDirection) As String

        If ViewState("orderBy") = "ASC" Then
            ViewState("orderBy") = "DESC"
            Return "DESC"
        Else
            ViewState("orderBy") = "ASC"
            Return "ASC"
        End If
        Return 0
    End Function

    Protected Sub Btn_Set_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' 檢查查詢條件是否改變 
        Chk_Filter()
    End Sub

    Private Sub Chk_Filter()
        Dim cfc As New Common_Func()

        Dim ckint As Integer = 0
        Dim tmpstr As String = ""


  


        Dim strSql As String = "rpt_SRN"






        Dim dtCurrentRecord As New DataTable
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)

        Dim cmd As New SqlCommand(strSql, conn)
        cmd.Parameters.Add("@Date", SqlDbType.DateTime, 100)
        cmd.Parameters("@Date").Value = CDate(txtExportDate.Text)
        cmd.Parameters.Add("@status", SqlDbType.VarChar, 100)
        cmd.Parameters("@status").Value = ddlCode.SelectedValue

        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        Dim da As New SqlDataAdapter(cmd)
        cmd.Connection.Open()
        da.Fill(dtCurrentRecord)
        cmd.Connection.Close()
        cmd.Dispose()
        da.Dispose()

        gv_delivery_master.DataSource = dtCurrentRecord
        ViewState("myDataTable") = dtCurrentRecord

        gv_delivery_master.DataBind()

        If gv_delivery_master.PageCount - 1 < gv_delivery_master.PageIndex Then
            gv_delivery_master.PageIndex = gv_delivery_master.PageCount
            gv_delivery_master.DataBind()
        End If

        lb_pageid.Text = gv_delivery_master.PageIndex.ToString()
    End Sub

    Protected Sub btnUpload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpload.Click
        Dim connectionString As String = ""
        Dim errMsg As String = ""
        If FileUpload1.HasFile Then

            Dim dtm As DateTime = CDate(txtImportDate.Text)


            Dim fileName As String = Path.GetFileName(FileUpload1.PostedFile.FileName)
            Dim fileExtension As String = Path.GetExtension(FileUpload1.PostedFile.FileName)
            Dim fileLocation As String = Server.MapPath("~/ExcelExport/" & fileName)
            FileUpload1.SaveAs(fileLocation)

            Try
                Dim dtExcelRecords As DataTable = ReadCSV(fileLocation)

                File.Delete(fileLocation)

                If InsertExceltoDB(dtExcelRecords) = True Then
                    'gv_delivery_master.DataBind()

                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Upload Completed');", True)
                Else
                    txtImportDate.Text = ""
                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Upload Failed. Please choose the right file');", True)
                End If

            Catch ex As Exception
                txtImportDate.Text = ""
                ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('" & ex.Message.Replace("'", "''") & "');", True)
            End Try

        Else
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Please select an excel file');", True)
        End If


    End Sub

    Function ReadCSV(ByVal path As String) As System.Data.DataTable
        Dim sr As New StreamReader(path)
        Dim fullFileStr As String = sr.ReadToEnd()
        sr.Close()
        sr.Dispose()
        Dim lines As String() = fullFileStr.Split(Environment.NewLine.ToCharArray(), StringSplitOptions.RemoveEmptyEntries)
        Dim recs As New DataTable()
        Dim sArr As String() = lines(0).Split(","c)
        For j = 1 To sArr.Length - 1

            If sArr(j).ToUpper = "UNIT COST" Or sArr(j).StartsWith("TOTAL COST") Then
                recs.Columns.Add(sArr(j), System.Type.GetType("System.Decimal"))
            Else
                recs.Columns.Add(sArr(j))
            End If
        Next
        recs.Columns.Add("engDesc") ' Extra column to be added




        Dim row As DataRow
        Dim finalLine As String = ""
        For i = 1 To lines.Length - 1

            Dim line As String = lines(i)
            Dim cells As String() = line.Split(","c)
            If cells(0) = "" Then
                Continue For
            End If
            row = recs.NewRow()
            For j = 1 To cells.Length - 1

                If sArr(j).ToUpper = "ITEM" Then
                    row(sArr(j)) = cells(j).Split(" ")(0).Trim
                    row(cells.Length - 1) = cells(j).Substring(cells(j).IndexOf("-") + 2).Trim
                ElseIf sArr(j).ToUpper = "UNIT COST" Or sArr(j).StartsWith("TOTAL COST") Then
                    If cells(j).Trim = "" Then
                        row(sArr(j)) = 0.0
                    Else
                        row(sArr(j)) = CDbl(cells(j).Trim)
                    End If

                Else
                    row(sArr(j)) = cells(j).Trim
                End If
            Next
            recs.Rows.Add(row)
        Next
        Return recs
    End Function

    Private Function InsertExceltoDB(ByVal dt As DataTable) As Boolean

        dt.Columns(0).ColumnName = "custName"
        dt.Columns(1).ColumnName = "PO_no"
        dt.Columns(2).ColumnName = "custMaterialCode"
        dt.Columns(3).ColumnName = "order_qty"
        dt.Columns(4).ColumnName = "recei_qty"
        dt.Columns(5).ColumnName = "varia_qty"
        dt.Columns(6).ColumnName = "netPrice"
        dt.Columns(7).ColumnName = "total_price"
        dt.Columns(8).ColumnName = "engDesc"

        Dim isSucceed As Boolean = False
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim tran As SqlTransaction
        Dim da As New SqlDataAdapter
        Dim cmd As New SqlCommand()
        cmd.Connection = conn
        cmd.Connection.Open()
        tran = conn.BeginTransaction
        cmd.Transaction = tran
        Dim strSql As String
        Try
            strSql = " delete from srn_record where convert(varchar(10),issue_date,111) = '" & txtImportDate.Text.Trim & "'"
            cmd = New SqlCommand(strSql, conn)
            cmd.Transaction = tran
            cmd.ExecuteNonQuery()

            strSql = "  insert into srn_record(custName, PO_no, custMaterialCode,order_qty,recei_qty,varia_qty,netPrice,total_price,engDesc,issue_date,update_date, updated_by)"
            strSql &= " values(@custName, @PO_no, @custMaterialCode, @order_qty, @recei_qty, @varia_qty, @netPrice, @total_price, @engDesc, @issue_date, @update_date, @updated_by)"

            cmd = New SqlCommand(strSql, conn)

            cmd.CommandType = CommandType.Text
            cmd.Transaction = tran
            cmd.Parameters.Add("@custName", SqlDbType.NVarChar, 50, "custName")
            cmd.Parameters.Add("@PO_no", SqlDbType.NVarChar, 50, "PO_no")
            cmd.Parameters.Add("@custMaterialCode", SqlDbType.NVarChar, 50, "custMaterialCode")

            cmd.Parameters.Add("@order_qty", SqlDbType.Int, 50, "order_qty")
            cmd.Parameters.Add("@recei_qty", SqlDbType.Int, 50, "recei_qty")
            cmd.Parameters.Add("@varia_qty", SqlDbType.Int, 50, "varia_qty")

            cmd.Parameters.Add("@netPrice", SqlDbType.Decimal, 50, "netPrice")
            cmd.Parameters.Add("@total_price", SqlDbType.Decimal, 50, "total_price")
            cmd.Parameters.Add("@engDesc", SqlDbType.NVarChar, 50, "engDesc")


            cmd.Parameters.Add("@issue_date", SqlDbType.DateTime, 10)
            cmd.Parameters("@issue_date").Value = CDate(txtImportDate.Text.Trim)

            cmd.Parameters.Add("@update_date", SqlDbType.DateTime, 1000)
            cmd.Parameters("@update_date").Value = Now

            cmd.Parameters.Add("@updated_by", SqlDbType.NVarChar, 1000)
            cmd.Parameters("@updated_by").Value = Session("mg_name")
        
            da.InsertCommand = cmd
            da.Update(dt)


            'strSql = " update gm_route set is_active = 1, update_date =getdate(), updated_by ='" & Session("mg_name") & "' where is_active is null"
            'cmd = New SqlCommand(strSql, conn)
            'cmd.Transaction = tran
            'cmd.ExecuteNonQuery()

            tran.Commit()
            isSucceed = True
        Catch ex As Exception
            tran.Rollback()
            isSucceed = False
        End Try

        cmd.Dispose()
        da.Dispose()
        conn.Dispose()
        Return isSucceed
    End Function

  

    Private Sub InsertDBtoExcel(ByVal dt As DataTable, ByVal connectionString As String)
        Try
            Dim strTable As String = ""
            strTable = "CREATE TABLE [" & dt.TableName & "]("

            Dim j As Integer = 0
            For j = 0 To dt.Columns.Count - 1
                Dim dCol As DataColumn
                dCol = dt.Columns(j)

                Dim strColName As String = dCol.ColumnName
                If strColName.StartsWith("k") Then

                    strTable &= " [" & dCol.ColumnName & "] int , "
                Else
                    strTable &= " [" & dCol.ColumnName & "] nvarchar(255) , "
                End If




            Next
            strTable = strTable.Substring(0, strTable.Length - 2)
            strTable &= ")"

            Dim conn As OleDbConnection = New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand(strTable, conn)
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            cmd.Dispose()


            Dim strInsert As String
            strInsert = "Insert Into " & dt.TableName & " Values ("
            For k As Integer = 0 To dt.Columns.Count - 1
                strInsert &= "@" & dt.Columns(k).ColumnName & " , "
            Next
            strInsert = strInsert.Substring(0, strInsert.Length - 2)
            strInsert &= ")"

            conn.Open()
            For j = 0 To dt.Rows.Count - 1
                Dim cmd2 As New OleDbCommand(strInsert, conn)
                For k As Integer = 0 To dt.Columns.Count - 1
                    Dim strName As String = dt.Columns(k).ColumnName

                    If strName.StartsWith("k") Then
                        If dt.Rows(j)(k).ToString() = "" Then
                            cmd2.Parameters.AddWithValue("@" & dt.Columns(k).ColumnName.ToString(), System.DBNull.Value)
                        Else
                            cmd2.Parameters.AddWithValue("@" & dt.Columns(k).ColumnName.ToString(), dt.Rows(j)(k).ToString())
                        End If


                    Else
                        cmd2.Parameters.AddWithValue("@" & dt.Columns(k).ColumnName.ToString(), dt.Rows(j)(k).ToString())
                    End If


                Next

                cmd2.ExecuteNonQuery()
                cmd2.Parameters.Clear()
                cmd2.Dispose()
            Next
            conn.Close()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub InsertDBtoExcel_Version2(ByVal dt As DataTable, ByVal connectionString As String)
        Try
            Dim strTable As String = ""
            strTable = "CREATE TABLE [" & dt.TableName & "]("

            Dim j As Integer = 0
            For j = 0 To dt.Columns.Count - 1
                Dim dCol As DataColumn
                dCol = dt.Columns(j)

                Dim strColName As String = dCol.ColumnName
                If strColName.StartsWith("k") Then

                    'strTable &= " [" & dCol.ColumnName & "] int , "
                    strTable &= " [" & dCol.ColumnName & "] nvarchar(255) , "
                Else
                    strTable &= " [" & dCol.ColumnName & "] nvarchar(255) , "
                End If




            Next
            strTable = strTable.Substring(0, strTable.Length - 2)
            strTable &= ")"

            Dim conn As OleDbConnection = New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand(strTable, conn)
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            cmd.Dispose()


            Dim strInsert As String
            strInsert = "Insert Into " & dt.TableName & " Values ("
            For k As Integer = 0 To dt.Columns.Count - 1
                strInsert &= "@" & dt.Columns(k).ColumnName & " , "
            Next
            strInsert = strInsert.Substring(0, strInsert.Length - 2)
            strInsert &= ")"

            conn.Open()
            For j = 0 To dt.Rows.Count - 1
                Dim cmd2 As New OleDbCommand(strInsert, conn)
                For k As Integer = 0 To dt.Columns.Count - 1
                    Dim strName As String = dt.Columns(k).ColumnName
                    Dim str As String = dt.Rows(j)(k).ToString()

                    If strName.StartsWith("k") Then
                        If str = "" Then
                            cmd2.Parameters.AddWithValue("@" & strName, System.DBNull.Value)
                        Else
                            cmd2.Parameters.AddWithValue("@" & strName, str)
                        End If


                    ElseIf strName = "materialCode" Then

                        If str.StartsWith("00") Then str = "3rd Item"
                        cmd2.Parameters.AddWithValue("@" & strName, str)
                    Else
                        cmd2.Parameters.AddWithValue("@" & strName, str)
                    End If


                Next

                cmd2.ExecuteNonQuery()
                cmd2.Parameters.Clear()
                cmd2.Dispose()
            Next
            conn.Close()
        Catch ex As Exception
        End Try
    End Sub


    Private Function RetrieveVanCount(ByRef intStart As Integer) As Integer
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim result As Integer = 0
        Dim Sql_Command As New SqlCommand("select count(*) as cnt, min(vanCode) as intMin from business_unit", conn)
        conn.Open()
        Dim dr As SqlDataReader
        dr = Sql_Command.ExecuteReader
        Do While dr.Read()
            result = dr("cnt")
            intStart = CInt(Right(dr("intMin"), 3))
        Loop
        dr.Close()
        Sql_Command.Dispose()
        Return result
    End Function

    Private Function RetrieveDtByGroup(ByVal strGroupDesc As String) As DataTable
        Dim dtCurrentRecord As New DataTable
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)

        Dim strSql As String = "Select materialCode, i.engDesc "
        Dim intVanStart As Integer = 0
        Dim intVanCnt As Integer = RetrieveVanCount(intVanStart)
        For i = 0 To intVanCnt - 1
            strSql &= String.Format(" ,'Qty' as '{0}' ", "k" & intVanStart + i)
        Next
        strSql &= " from item_master i inner join item_group_master g on i.materialGroupCode = g.materialGroupCode where g.chiDesc ='" & strGroupDesc & "'"
        strSql = strSql.Replace("Qty", "") & " union " & strSql.Replace("materialCode", "'" & "00 3rd Item" & "'").Replace("i.engDesc", "'" & strGroupDesc & "' ")
        strSql &= " order by materialCode asc"

        Dim cmd As New SqlCommand(strSql, conn)
        cmd.Connection = conn
        cmd.CommandType = CommandType.Text
        Dim da As New SqlDataAdapter(cmd)
        cmd.Connection.Open()
        da.Fill(dtCurrentRecord)
        cmd.Connection.Close()
        cmd.Dispose()
        da.Dispose()

        Return dtCurrentRecord
    End Function

    Private Function RetrieveReplenishDT() As DataTable
        Dim dtGroup As DataTable = RetrieveDtGroup()
        Dim dtResult As New DataTable


        For i = 0 To dtGroup.Rows.Count - 1
            Dim strGroupDesc As String = dtGroup.Rows.Item(i)("chidesc")
            dtResult.Merge(RetrieveDtByGroup(strGroupDesc))
        Next


        Return dtResult
    End Function

    Private Function RetrieveDtGroup() As DataTable
        Dim dt As New DataTable
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim strSql As String = "Select distinct chiDesc from item_group_master order by chiDesc "
        Dim cmd As New SqlCommand(strSql, conn)
        cmd.Connection = conn
        cmd.CommandType = CommandType.Text
        Dim da As New SqlDataAdapter(cmd)
        cmd.Connection.Open()
        da.Fill(dt)
        cmd.Connection.Close()
        cmd.Dispose()
        da.Dispose()
        Return dt
    End Function

    Private Function hasDataOnDate(ByVal strDate As String) As Boolean
        Dim dtCurrentRecord As New DataTable
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)

        Dim strSql As String = "select workDate from replenishment where 1 =1 and workDate = '" & strDate & "'"


        Dim cmd As New SqlCommand(strSql, conn)
        cmd.Connection = conn
        cmd.CommandType = CommandType.Text
        cmd.Connection.Open()
        Dim dr As SqlDataReader
        dr = cmd.ExecuteReader()

        Dim result As Boolean = False

        If dr.Read() Then
            result = True
        End If


        Return result
    End Function


End Class
