﻿'---------------------------------------------------------------------------- 
'程式功能	Customer Manster Master Maintenance
'---------------------------------------------------------------------------- 
Imports System
Imports System.Collections.Generic
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Data
Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports System.IO

Partial Class _2004_2004
    Inherits System.Web.UI.Page
    Private s3 As String
    Private s4 As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()



            ' 檢查使用者權限並存入登入紀錄。 
            Check_Power("2004", True)

            '接受下一頁返回時的舊查詢條件" 
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid"), ckint) Then
                    gv_customer_master.PageIndex = ckint
                    lb_pageid.Text = gv_customer_master.PageIndex
                Else
                    lb_pageid.Text = "0"
                End If

            End If



            If Request("s1") IsNot Nothing Then
                txtCustNo.Text = Request("s1")
            End If

            If Request("s2") IsNot Nothing Then
                tb_customer_code.Text = Request("s2")
            End If

            If Request("s3") IsNot Nothing Then
                tb_company_code.DataSourceID = Nothing
                tb_company_code.DataSource = RetrieveDataTable("select [name1] from [customer_group_master] union select ''")
                tb_company_code.DataBind()
                Try
                    tb_company_code.SelectedValue = Request("s3")
                Catch
                End Try
            End If

            If Request("s4") IsNot Nothing Then
                tb_district_name.DataSourceID = Nothing
                tb_district_name.DataSource = RetrieveDataTable("SELECT distinct UPPER([district_zone_eng]) as district_zone_eng FROM [district_master] union select ''")
                tb_district_name.DataBind()
                Try
                    tb_district_name.SelectedValue = Request("s4")
                Catch
                End Try

            End If

            mgids.Text = Session("mg_sid")

            Chk_Filter()
        End If


    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            'If cfc.Check_Power(Session("stk_code").ToString(), Session("stk_desc").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub gv_customer_master_PageIndexChanged(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        Chk_Filter()
        lb_pageid.Text = e.NewPageIndex()

    End Sub

    Protected Sub gv_custmaster_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gv_customer_master.PageIndexChanging
        Chk_Filter()
    End Sub

    Protected Sub gv_custmaster_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gv_customer_master.Sorting
        Chk_Filter()
    End Sub

    Protected Sub Btn_Set_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' 檢查查詢條件是否改變 
        Chk_Filter()
    End Sub

    ' 檢查查詢條件是否改變 
    Private Sub Chk_Filter()
        Dim cfc As New Common_Func()

        Dim ckint As Integer = 0
        Dim tmpstr As String = ""

        Dim strSearchCustNo = cfc.CleanSQL(txtCustNo.Text.Trim)
        Dim strSearchName = cfc.CleanSQL(tb_customer_code.Text.Trim)
        Dim strSearchGroup = cfc.CleanSQL(tb_company_code.SelectedValue.Trim)
        Dim strSearchDistrict = cfc.CleanSQL(tb_district_name.SelectedValue.Trim)
        Dim strSearchActive = tb_active.SelectedValue.Trim

        Dim strSql As String = " select c.custNo,c.name1,c.salesOrg,c.custGroup, g.name1 as g_name1,c.city as district, c.street4 ,  case when isnull(b.is_active,'1')  = 1 then 'Active' else 'Block' End as is_active  from customer_master c inner join customer_group_master g on g.custGroup = c.custGroup left join block_customer b on c.custNo = b.custNo "
        strSql += " where 1=1 "
        If strSearchCustNo <> "" Then strSql += " and c.custNo like '%" & strSearchCustNo & "%'"
        If strSearchName <> "" Then strSql += " and c.name1 like '%" & strSearchName & "%'"
        If strSearchGroup <> "" Then strSql += " and g.name1 = '" & strSearchGroup & "'"
        If strSearchDistrict <> "" Then strSql += " and c.city = '" & strSearchDistrict & "'"
        If strSearchActive = "1" Then
            strSql += " and b.is_active = '" & strSearchActive & "'"
        ElseIf strSearchActive = "0" Then
            strSql += " and b.is_active = '' "
        End If


        dsCustomer.SelectCommand = strSql
        gv_customer_master.DataBind()
        If gv_customer_master.PageCount - 1 < gv_customer_master.PageIndex Then
            gv_customer_master.PageIndex = gv_customer_master.PageCount
            gv_customer_master.DataBind()
        End If

        lb_pageid.Text = gv_customer_master.PageIndex.ToString()
    End Sub

    Protected Sub gv_customer_master_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs) Handles gv_customer_master.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim btnView As Button = DirectCast(e.Row.FindControl("btnView"), Button)
            Dim strCustNo As String = e.Row.Cells(0).Text
            btnView.ToolTip = strCustNo
        End If

    End Sub

    Public Sub btnView_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim strCustNo As String = CType(sender, Button).ToolTip

        Dim strCustSearch As String = txtCustNo.Text
        Dim strCustName As String = tb_customer_code.Text
        Dim strCustGroup As String = tb_company_code.Text
        Dim strDistrict As String = tb_district_name.Text

        Response.Redirect(String.Format("2004_view.aspx?pageid={0}&mg_sid={1}&s1={2}&s2={3}&s3={4}&s4={5}", lb_pageid.Text, strCustNo, strCustSearch, strCustName, strCustGroup, strDistrict), False)
    End Sub

    Protected Sub tb_company_code_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tb_company_code.SelectedIndexChanged
        Chk_Filter()
    End Sub

    Protected Sub tb_district_name_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tb_district_name.SelectedIndexChanged
        Chk_Filter()
    End Sub



    Private Function RetrieveDataTable(ByVal strSQL As String) As DataTable
        Dim Sql_Conn1 As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim SqlString1 As String = strSQL


        Dim Sql_Command1 As New SqlCommand(SqlString1, Sql_Conn1)
        Sql_Conn1.Open()

        Dim dt As New DataTable

        Dim Sql_Reader1 As SqlDataReader = Sql_Command1.ExecuteReader()

        dt.Load(Sql_Reader1)

        Sql_Reader1.Close()
        Sql_Conn1.Close()


        Return dt
    End Function


    Protected Sub btnExport_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnExport.Click
        Try
            Dim dtCurrentRecord As New DataTable
            Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)

            Dim strSql As String = " select c.custNo, name1, isnull(b.is_active,'1') as is_active from customer_master c Left join block_customer b on c.custno = b.custno "


            Dim cmd As New SqlCommand(strSql, conn)
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            Dim da As New SqlDataAdapter(cmd)
            cmd.Connection.Open()
            da.Fill(dtCurrentRecord)
            cmd.Connection.Close()
            cmd.Dispose()
            da.Dispose()
            dtCurrentRecord.TableName = "Customer"
            Dim strFileName As String = "ExcelExport_" + "_" + Format(TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))), "yyyyMMddhhmmss") + ".xls"
            Dim strNewPath As String = HttpContext.Current.Server.MapPath("~/ExcelExport/" & strFileName)
            Dim strPhysicalPath As String = HttpContext.Current.Server.MapPath("~/ExcelExport/" & strFileName)

            If Not IO.Directory.Exists(HttpContext.Current.Server.MapPath("~/ExcelExport")) Then
                IO.Directory.CreateDirectory(HttpContext.Current.Server.MapPath("~/ExcelExport"))
            End If

            Dim connectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & strNewPath & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=2"""
            connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & strNewPath & ";Extended Properties=""Excel 12.0 xml;HDR=Yes"""

            InsertDBtoExcel(dtCurrentRecord, connectionString)

            HttpContext.Current.Response.Clear()
            Response.WriteFile(strNewPath)
            Dim httpHeader As String = "attachment;filename=" + "Customer" + ".xlsx"
            HttpContext.Current.Response.ContentType = "application/vnd.ms-excel"
            HttpContext.Current.Response.AppendHeader("Content-Disposition", httpHeader)
            HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.Unicode


            HttpContext.Current.Response.Flush()
            System.IO.File.Delete(strNewPath)
            HttpContext.Current.Response.End()
        Catch ex As Exception
            '    Dim sMsg As String
            '    sMsg = ex.Message

            '    Response.Write(ex.Message)
            'Finally

        End Try


    End Sub


    Private Sub InsertDBtoExcel(ByVal dt As DataTable, ByVal connectionString As String)
        Dim strTable As String = ""
        strTable = "CREATE TABLE [" & dt.TableName & "]("

        Dim j As Integer = 0
        For j = 0 To dt.Columns.Count - 1
            Dim dCol As DataColumn
            dCol = dt.Columns(j)

            strTable &= " [" & dCol.ColumnName & "] nvarchar(255) , "


        Next
        strTable = strTable.Substring(0, strTable.Length - 2)
        strTable &= ")"

        Dim conn As OleDbConnection = New OleDbConnection(connectionString)
        Dim cmd As New OleDbCommand(strTable, conn)
        conn.Open()
        cmd.ExecuteNonQuery()
        conn.Close()
        cmd.Dispose()


        Dim strInsert As String
        strInsert = "Insert Into " & dt.TableName & " Values ("
        For k As Integer = 0 To dt.Columns.Count - 1
            strInsert &= "@" & dt.Columns(k).ColumnName & " , "
        Next
        strInsert = strInsert.Substring(0, strInsert.Length - 2)
        strInsert &= ")"

        conn.Open()
        For j = 0 To dt.Rows.Count - 1
            Dim cmd2 As New OleDbCommand(strInsert, conn)
            For k As Integer = 0 To dt.Columns.Count - 1

                cmd2.Parameters.AddWithValue("@" & dt.Columns(k).ColumnName.ToString(), dt.Rows(j)(k).ToString())

            Next

            cmd2.ExecuteNonQuery()
            cmd2.Parameters.Clear()
            cmd2.Dispose()
        Next
        conn.Close()
    End Sub



    Protected Sub btnUpload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpload.Click
        Dim connectionString As String = ""
        If FileUpload1.HasFile Then



            Dim fileName As String = Path.GetFileName(FileUpload1.PostedFile.FileName)
            Dim fileExtension As String = Path.GetExtension(FileUpload1.PostedFile.FileName)
            Dim fileLocation As String = Server.MapPath("~/ExcelExport/" & fileName)
            FileUpload1.SaveAs(fileLocation)
            If fileExtension = ".xls" Then
                connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=2"""
            ElseIf fileExtension = ".xlsx" Then
                connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 12.0;HDR=Yes;IMEX=2"""
            Else
                ClientScript.RegisterStartupScript(Me.GetType(), "errorScript", "alert('" & "Please select MS Excel file" & "');", True)
                Exit Sub
            End If

            gv_customer_master.DataSource = Nothing





            Dim con As New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand()
            cmd.CommandType = System.Data.CommandType.Text
            cmd.Connection = con
            Dim dAdapter As New OleDbDataAdapter(cmd)
            Dim dtExcelRecords As New DataTable()
            Try
                con.Open()

                Dim dtExcelSheetName As DataTable = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)
                Dim getExcelSheetName As String = ""
                If dtExcelSheetName.Rows.Count > 1 Then
                    getExcelSheetName = dtExcelSheetName.Rows(1)("Table_Name").ToString()
                Else
                    getExcelSheetName = "Sheet1$"
                End If
                cmd.CommandText = "SELECT custNo, name1,   is_active  FROM [" & getExcelSheetName & "] where custNo is not null "
                dAdapter.SelectCommand = cmd
                dAdapter.Fill(dtExcelRecords)
                con.Close()

                dtExcelRecords.Columns(0).ColumnName = "custNo"
                dtExcelRecords.Columns(1).ColumnName = "name1"
                dtExcelRecords.Columns(2).ColumnName = "is_active"


                If InsertExceltoDB(dtExcelRecords) = True Then
                    ' ddlCode.DataBind()
                    gv_customer_master.DataBind()
                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Upload Completed');", True)
                Else
                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Upload Failed. Please choose the right file');", True)
                End If

            Catch ex As Exception
                ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Upload Failed. Please choose the right file');", True)

            End Try

        Else
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('Please select an excel file');", True)
        End If
    End Sub

    Private Function InsertExceltoDB(ByVal dt As DataTable) As Boolean



        Dim isSucceed As Boolean = False
        Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim tran As SqlTransaction
        Dim da As New SqlDataAdapter
        Dim cmd As New SqlCommand()
        cmd.Connection = conn
        cmd.Connection.Open()
        tran = conn.BeginTransaction
        cmd.Transaction = tran
        Dim strSql As String
        Try
            strSql = " delete from block_customer "
            cmd = New SqlCommand(strSql, conn)
            cmd.Transaction = tran
            cmd.ExecuteNonQuery()

            strSql = "Insert Into [block_customer] (custNo,is_active) " & _
                         " values(@custNo, @is_active) "
            cmd = New SqlCommand(strSql, conn)

            cmd.CommandType = CommandType.Text
            cmd.Transaction = tran
            cmd.Parameters.Add("@custNo", SqlDbType.NVarChar, 500, "custNo")
            cmd.Parameters.Add("@is_active", SqlDbType.NVarChar, 500, "is_active")

            For Each dr As DataRow In dt.Rows
                dr.SetAdded()
            Next
            da.InsertCommand = cmd
            da.Update(dt)

            strSql = "update block_customer set is_active = '' where isnull(is_active,0) = 0 "
            cmd = New SqlCommand(strSql, conn)
            cmd.Transaction = tran
            cmd.ExecuteNonQuery()


            tran.Commit()
            isSucceed = True
        Catch ex As Exception
            Dim smsg As String = ex.Message


            tran.Rollback()
            isSucceed = False
        End Try

        cmd.Dispose()
        da.Dispose()
        conn.Dispose()
        Return isSucceed
    End Function


    Protected Sub btnExport2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnExport2.Click
        Try
            Dim dtCurrentRecord As New DataTable
            Dim conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)

            Dim strSql As String = " select cm.custNo, cm.name1, cm.shippingPoint as [ShippingVia], cg.name1 as [GroupName], cm.street4 as [ChineseAddress], cm.City as District,  cm.telno as [TelNo], isnull(cm.is_active, '1') as is_active  from customer_master  cm left join  customer_group_master cg On  cg.custGroup = cm.custGroup order by cm.custNo"

            Dim cmd As New SqlCommand(strSql, conn)
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            Dim da As New SqlDataAdapter(cmd)
            cmd.Connection.Open()
            da.Fill(dtCurrentRecord)
            cmd.Connection.Close()
            cmd.Dispose()
            da.Dispose()
            dtCurrentRecord.TableName = "CustomerMaster"
            Dim strFileName As String = "ExcelExport_" + "_" + Format(TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))), "yyyyMMddhhmmss") + ".xlsx"
            Dim strNewPath As String = HttpContext.Current.Server.MapPath("~/ExcelExport/" & strFileName)
            Dim strPhysicalPath As String = HttpContext.Current.Server.MapPath("~/ExcelExport/" & strFileName)

            If Not IO.Directory.Exists(HttpContext.Current.Server.MapPath("~/ExcelExport")) Then
                IO.Directory.CreateDirectory(HttpContext.Current.Server.MapPath("~/ExcelExport"))
            End If

            Dim connectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & strNewPath & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=2"""
            connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & strNewPath & ";Extended Properties=""Excel 12.0 xml;HDR=Yes"""

            InsertDBtoExcel(dtCurrentRecord, connectionString)

            HttpContext.Current.Response.Clear()
            Response.WriteFile(strNewPath)
            Dim httpHeader As String = "attachment;filename=" + "Customer_Master_Report" + ".xlsx"
            HttpContext.Current.Response.ContentType = "application/vnd.ms-excel"
            HttpContext.Current.Response.AppendHeader("Content-Disposition", httpHeader)
            HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.Unicode


            HttpContext.Current.Response.Flush()
            System.IO.File.Delete(strNewPath)
            HttpContext.Current.Response.End()
        Catch ex As Exception
            '    Dim sMsg As String
            '    sMsg = ex.Message

            '    Response.Write(ex.Message)
            'Finally

        End Try
    End Sub
End Class
