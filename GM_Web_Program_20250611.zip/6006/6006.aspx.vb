﻿Imports System.Data
Imports Common_Func

Partial Class _6006_6006
    Inherits System.Web.UI.Page

    Dim gErr As String = ""


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim tmpstr As String = ""
            txtDateFrom.Text = Today.Year.ToString & "/" & Today.Month.ToString & "/" & "01"
            txtDateTo.Text = Today.Year.ToString & "/" & Today.Month.ToString & "/" & Today.Day.ToString

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("6006", True)

            Chkfilter()
            'Dim SQLString As String
            'SQLString = "select top 1000 isnull(sum(quantity * netPrice ),0) as total from txn_header h inner join txn_detail d on h.refDocNo = d.refDocNo where h.txn_type = N'Sales' and h.isVoid <> '1' and cr_date between  '" & txtDateFrom.ToString & "' and '" & txtDateTo.Text & "' "
            'Dim myDataTable As DataTable = ExeSQLGetDataTable(SQLString)
            'If myDataTable.Rows.Count > 0 Then
            '    lbl_total.Text = "Total: " & myDataTable.Rows(0).Item("total").ToString
            'Else
            '    lbl_total.Text = ""
            'End If
        End If


        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""

    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub


    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        Chkfilter()
    End Sub

    Private Sub Chkfilter()

        Dim strDateFrom As String = Me.txtDateFrom.Text.Trim
        Dim strDateTo As String = Me.txtDateTo.Text.Trim
        Dim strVanId As String = ddlVanId.Text.Trim
        Dim period As String = ddlGroupBy.SelectedItem.Value

        If period = 0 Then
            period = "convert(nvarchar,datepart(YEAR,h.cr_date))"
        ElseIf period = 1 Then
            period = "convert(nvarchar,datepart(YEAR,h.cr_date))  + '/' + RIGHT('00'+ CAST(convert(nvarchar,datepart(month,h.cr_date)) AS VARCHAR(7)), 2)"
        ElseIf period = 2 Then
            period = "convert(nvarchar,datepart(YEAR,h.cr_date))  + '/' + RIGHT('00'+ CAST(Convert(nvarchar, DatePart(week,h.cr_date)) AS VARCHAR(7)), 2)"

        End If

        Dim SQLString As String = ""
        If (strDateFrom <> "") Then
            If Not (strDateFrom Like "####[/]##[/]##" Or IsDate(strDateFrom)) Then
                gErr = "alert('[Date From] error! \n')"
                Return
            End If
            strDateFrom = " and convert(varchar,h.cr_date,111) >= '" & strDateFrom & "' "
        End If
        If (strDateTo <> "") Then
            If Not (strDateTo Like "####[/]##[/]##" Or IsDate(strDateTo)) Then
                gErr = "alert('[Date To] error! \n')"
                Return
            End If
            strDateTo = " and convert(varchar,h.cr_date,111) <= '" & strDateTo & "' "
        End If

        If strVanId <> "" Then
            strVanId = " and right(h.van_id,3) = '" & Right(strVanId, 3) & "' "
        End If


        SQLString = "select d.materialCode, i.chiDesc, h.van_id, " & period & " date,sum(d.quantity) qty, sum(d.quantity*d.netPrice) price from txn_header h inner join txn_detail d on h.refDocNo = d.refDocNo inner join item_master i on d.materialCode = i.materialCode where h.txn_type=N'Sales' and h.isVoid <> '1' " & strDateFrom & strDateTo & strVanId & " group by d.materialCode, i.chiDesc, h.van_id, " & period

        SqlMainSource.SelectCommand = SQLString


        SQLString = "select isnull(sum(quantity * netPrice ),0) as total from txn_header h inner join txn_detail d on h.refDocNo = d.refDocNo where h.txn_type = N'Sales' and h.isVoid <>'1' " & strDateFrom & strDateTo & strVanId
        Dim myDataTable As DataTable = ExeSQLGetDataTable(SQLString)
        If myDataTable.Rows.Count > 0 Then
            lbl_total.Text = "Total: " & myDataTable.Rows(0).Item("total").ToString
        Else
            lbl_total.Text = ""
        End If

    End Sub

    Protected Sub gv_custmaster_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gv_custmaster.PageIndexChanging
        Dim strDateFrom As String = Me.txtDateFrom.Text.Trim
        Dim strDateTo As String = Me.txtDateTo.Text.Trim
        Dim strVanId As String = ddlVanId.Text.Trim
        Dim period As String = ddlGroupBy.SelectedItem.Value

        If period = 0 Then
            period = "convert(nvarchar,datepart(YEAR,h.cr_date))"
        ElseIf period = 1 Then
            period = "convert(nvarchar,datepart(YEAR,h.cr_date))  + '/' + RIGHT('00'+ CAST(convert(nvarchar,datepart(month,h.cr_date)) AS VARCHAR(7)), 2)"
        ElseIf period = 2 Then
            period = "convert(nvarchar,datepart(YEAR,h.cr_date))  + '/' + RIGHT('00'+ CAST(Convert(nvarchar, DatePart(week, h.cr_date)) AS VARCHAR(7)), 2)"

        End If

        Dim SQLString As String = ""
        If (strDateFrom <> "") Then
            If Not (strDateFrom Like "####[/]##[/]##" Or IsDate(strDateFrom)) Then
                gErr = "alert('[Date From] error! \n')"
                Return
            End If
            strDateFrom = " and convert(varchar,h.cr_date,111) >= '" & strDateFrom & "' "
        End If
        If (strDateTo <> "") Then
            If Not (strDateTo Like "####[/]##[/]##" Or IsDate(strDateTo)) Then
                gErr = "alert('[Date To] error! \n')"
                Return
            End If
            strDateTo = " and convert(varchar,h.cr_date,111) <= '" & strDateTo & "' "
        End If

        If strVanId <> "" Then
            strVanId = " and right(h.van_id,3) = '" & Right(strVanId, 3) & "' "
        End If


        SQLString = "select d.materialCode, i.chiDesc, h.van_id, " & period & " date,sum(d.quantity) qty, sum(d.quantity*d.netPrice) price from txn_header h inner join txn_detail d on h.refDocNo = d.refDocNo inner join item_master i on d.materialCode = i.materialCode where h.txn_type=N'Sales' and h.isVoid <> '1' " & strDateFrom & strDateTo & strVanId & " group by d.materialCode, i.chiDesc, h.van_id, " & period

        SqlMainSource.SelectCommand = SQLString

    End Sub

    Protected Sub gv_custmaster_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gv_custmaster.Sorting
        Dim strDateFrom As String = Me.txtDateFrom.Text.Trim
        Dim strDateTo As String = Me.txtDateTo.Text.Trim
        Dim strVanId As String = ddlVanId.Text.Trim
        Dim period As String = ddlGroupBy.SelectedItem.Value

        If period = 0 Then
            period = "convert(nvarchar,datepart(YEAR,h.cr_date))"
        ElseIf period = 1 Then
            period = "convert(nvarchar,datepart(YEAR,h.cr_date))  + '/' + RIGHT('00'+ CAST(convert(nvarchar,datepart(month,h.cr_date)) AS VARCHAR(7)), 2)"
        ElseIf period = 2 Then
            period = "convert(nvarchar,datepart(YEAR,h.cr_date))  + '/' + RIGHT('00'+ CAST(Convert(nvarchar, DatePart(week, h.cr_date)) AS VARCHAR(7)), 2)"

        End If

        Dim SQLString As String = ""
        If (strDateFrom <> "") Then
            If Not (strDateFrom Like "####[/]##[/]##" Or IsDate(strDateFrom)) Then
                gErr = "alert('[Date From] error! \n')"
                Return
            End If
            strDateFrom = " and convert(varchar,h.cr_date,111) >= '" & strDateFrom & "' "
        End If
        If (strDateTo <> "") Then
            If Not (strDateTo Like "####[/]##[/]##" Or IsDate(strDateTo)) Then
                gErr = "alert('[Date To] error! \n')"
                Return
            End If
            strDateTo = " and convert(varchar,h.cr_date,111) <= '" & strDateTo & "' "
        End If

        If strVanId <> "" Then
            strVanId = " and right(h.van_id,3) = '" & Right(strVanId, 3) & "' "
        End If


        SQLString = "select d.materialCode, i.chiDesc, h.van_id, " & period & " date,sum(d.quantity) qty, sum(d.quantity*d.netPrice) price from txn_header h inner join txn_detail d on h.refDocNo = d.refDocNo inner join item_master i on d.materialCode = i.materialCode where h.txn_type=N'Sales' and h.isVoid <> '1' " & strDateFrom & strDateTo & strVanId & " group by d.materialCode, i.chiDesc, h.van_id, " & period

        SqlMainSource.SelectCommand = SQLString

    End Sub
End Class
