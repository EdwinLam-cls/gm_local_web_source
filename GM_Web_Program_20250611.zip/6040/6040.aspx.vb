﻿Imports System.Data
Imports Common_Func


Partial Class _6040_6040
    Inherits System.Web.UI.Page

    Dim gErr As String = ""
    Dim ssql As String = ""



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim tmpstr As String = ""

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("6040", True)

        End If

        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""

        'showData()




    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub




    Protected Sub btn_Search_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Search.Click
        Dim strSql As String = getStrSql()
        'strSql = "select req_date, req_time, vanCode, case when req_type = 'D' then 'Download' else 'Upload' end as req_type from sync_rec where 1=1 "
        'Dim strVanNo As String = Right(ddlVanID.Text, 3)
        'If strVanNo <> "" Then strSql &= " and right(vanCode,3) = '" & strVanNo & "'"

        'Dim strFrom As String
        'Dim strTo As String
        'Try
        '    strFrom = CDate(txtDateFrom.Text).ToString("yyyy-MM-dd")
        'Catch
        '    strFrom = ""
        'End Try
        'Try
        '    strTo = CDate(txtDateTo.Text).ToString("yyyy-MM-dd")
        'Catch
        '    strTo = ""
        'End Try

        'If strFrom <> "" Then strSql &= " and req_date >= '" & strFrom & "'"
        'If strTo <> "" Then strSql &= " and req_date <= '" & strTo & "'"

        'Dim strStatus As String = ddlStatus.SelectedValue
        'If strStatus <> "" Then strSql &= " and req_type = '" & strStatus & "'"



        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()
    End Sub


    Protected Sub gv_custmaster_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gv_custmaster.PageIndexChanging
        Dim strSql As String = getStrSql()
        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()
    End Sub

    Protected Sub gv_custmaster_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gv_custmaster.Sorting
        Dim strSql As String = getStrSql()
        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()
    End Sub

    Private Function getStrSql() As String
        Dim strSql As String
        strSql = "select req_date, req_time, vanCode, case when req_type = 'D' then 'Download' else 'Upload' end as req_type from sync_rec where 1=1 "
        Dim strVanNo As String = Right(ddlVanID.Text, 3)
        If strVanNo <> "" Then strSql &= " and right(vanCode,3) = '" & strVanNo & "'"

        Dim strFrom As String
        Dim strTo As String
        Try
            strFrom = CDate(txtDateFrom.Text).ToString("yyyy-MM-dd")
        Catch
            strFrom = ""
        End Try
        Try
            strTo = CDate(txtDateTo.Text).ToString("yyyy-MM-dd")
        Catch
            strTo = ""
        End Try

        If strFrom <> "" Then strSql &= " and req_date >= '" & strFrom & "'"
        If strTo <> "" Then strSql &= " and req_date <= '" & strTo & "'"

        Dim strStatus As String = ddlStatus.SelectedValue
        If strStatus <> "" Then strSql &= " and req_type = '" & strStatus & "'"


        Return strSql
    End Function

End Class
