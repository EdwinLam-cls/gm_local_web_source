﻿
Partial Class _6015_6015
    Inherits System.Web.UI.Page

    Dim gErr As String = ""


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim tmpstr As String = ""

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("6015", True)

        End If

        'Dim xVal() As String = {"1", "2", "3"}
        'Dim yval() As Double = {12, 34, 45}

        'Chart1.Series("Series1").Points.DataBindXY(xVal, yval)

        System.Diagnostics.Debug.WriteLine(SqlMainSource.SelectCommand)

        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""

    End Sub


    ' Check_Power() 檢查使用者權限並存入登入紀錄
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub




    Protected Sub btn_add_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_add.Click
        Dim fr_date As String = tb_fr_date.Text
        Dim to_date As String = tb_to_date.Text

        Dim SQLString As String = ""

        If (tb_fr_date.Text.Trim <> "") Then
            If Not (tb_fr_date.Text.Trim() Like "####[/]##[/]##" Or IsDate(tb_fr_date.Text)) Then
                gErr = "alert('「由日期」輸入錯誤\n')"
                lt_show.Text = "<script language=javascript>" & gErr & "</script>"
                Return
            End If
            fr_date = " and convert(varchar,creation_date,111) >= '" & tb_fr_date.Text.Trim & "' "
        End If
        If (tb_to_date.Text.Trim <> "") Then
            If Not (tb_to_date.Text.Trim() Like "####[/]##[/]##" Or IsDate(tb_to_date.Text)) Then
                gErr = "alert('「到日期」輸入錯誤\n')"
                lt_show.Text = "<script language=javascript>" & gErr & "</script>"
                Return
            End If
            to_date = " and convert(varchar,creation_date,111) <= '" & tb_to_date.Text.Trim & "' "
        End If

        SQLString = " select creation_date,message,vanCode,case when type = 'm' then 'Company' else 'Van' end as type from message_master where expired ='1' " & fr_date & to_date
        SqlMainSource.SelectCommand = SQLString

    End Sub
End Class
