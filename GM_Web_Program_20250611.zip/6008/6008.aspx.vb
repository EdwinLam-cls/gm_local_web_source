﻿Imports System.Data
Imports System.Web
Imports Common_Func

Partial Class _6008_6008
    Inherits System.Web.UI.Page

    Dim gErr As String = ""
    Dim G_strVanId As String = ""
    Dim G_strDate As String = ""
    Dim G_strMonth As String = ""
    Dim G_strYear As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim tmpstr As String = ""

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("6008", True)
        End If

        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""
    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        If (SqlMainSource.SelectParameters.Count > 0) Then
            SqlMainSource.SelectParameters.Clear()
        End If
        Try

        
            SqlMainSource.SelectParameters.Add("dateFrom", txtDateFrom.Text.Trim)
            SqlMainSource.SelectParameters.Add("dateTo", txtDateTo.Text.Trim)
            SqlMainSource.SelectParameters.Add("vanFrom", Right(ddlVanFromId.Text.Trim, 3))
            SqlMainSource.SelectParameters.Add("vanTo", Right(ddlVanToId.Text.Trim, 3))
            SqlMainSource.SelectParameters.Add("dateNow", Format(TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))), "yyyy/MM/dd"))
            SqlMainSource.SelectParameters.Add("sreason", ddlReason.SelectedValue.Trim)
            SqlMainSource.SelectCommand = "list_visit_report"
            SqlMainSource.DataBind()

            'gvVisitReport.PageIndex = 0
            gvVisitReport.DataBind()
            If gvVisitReport.PageCount - 1 < gvVisitReport.PageIndex Then
                gvVisitReport.PageIndex = gvVisitReport.PageCount
                gvVisitReport.DataBind()
            End If
        Catch ex As Exception
            Dim smsg As String = ex.Message

        End Try
    End Sub

    'Protected Sub gvVisitReport_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gvVisitReport.Sorting
    '    getString()
    'End Sub


    'Private Sub getString()
    '    Dim strDateFrom As String = Me.txtDateFrom.Text.Trim
    '    Dim str
    '    Dim strVanId As String = ddlVanFromId.Text.Trim
    '    Dim strDateSql As String = String.Empty
    '    Dim strVanSql As String = String.Empty
    '    Dim strSql As String = String.Empty
    '    Dim getCodeDataTable As DataTable

    '    If (strDateFrom <> "") Then
    '        If Not (strDateFrom Like "####[/]##[/]##" Or IsDate(strDateFrom)) Then
    '            gErr = "alert('[Date From] error! \n')"
    '            Return
    '        End If
    '        G_strYear = " and year(h.cr_date) = '" & CDate(strDateFrom).ToString("yyyy") & "' "
    '        G_strMonth = " and month(h.cr_date) = '" & CDate(strDateFrom).ToString("MM") & "' "

    '        strDateSql = " and convert(varchar,h.cr_date,111) = '" & strDateFrom & "' "
    '    End If

    '    Select Case strVanId
    '        Case ""     ' No such case. Already handled by JavaScript
    '            strVanSql = String.Empty
    '        Case "ALL"  ' If search by all van, no need to filter out any.
    '            strVanSql = String.Empty
    '        Case Else
    '            strVanSql = " AND RIGHT(h.van_id, 3) = '" & Right(strVanId, 3) & "' "
    '    End Select

    '    G_strDate = strDateSql
    '    G_strVanId = strVanSql

    '    If (SqlMainSource.SelectParameters.Count > 0) Then
    '        SqlMainSource.SelectParameters.Clear()
    '    End If

    '    SqlMainSource.SelectParameters.Add("date", strDateFrom)
    '    If strVanId = "ALL" Then
    '        ' Get the minimum van code and maximum van code
    '        strSql = "SELECT RIGHT(MIN(vanCode), 3) AS minCode, RIGHT(MAX(vanCode), 3) AS maxCode FROM business_unit"
    '        getCodeDataTable = ExeSQLGetDataTable(strSql)
    '        If getCodeDataTable.Rows.Count > 0 Then
    '            SqlMainSource.SelectParameters.Add("minVan", getCodeDataTable.Rows(0).Item("minCode").ToString)
    '            SqlMainSource.SelectParameters.Add("maxVan", getCodeDataTable.Rows(0).Item("maxCode").ToString)
    '        End If
    '    Else
    '        ' For individual van, list in this order: Sample, Exchange and Sale (Pre-order and regular sale)
    '        SqlMainSource.SelectParameters.Add("minVan", Right(strVanId, 3))
    '        SqlMainSource.SelectParameters.Add("maxVan", Right(strVanId, 3))
    '    End If
    'End Sub

End Class
