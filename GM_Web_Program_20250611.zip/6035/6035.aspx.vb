﻿Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration
Imports System.Data.Common


Partial Class _6035_6035

    Inherits System.Web.UI.Page

    Dim gErr As String = ""


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim tmpstr As String = ""

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("6035", True)
            mg_name.Value = Session("mg_name").ToString
            tb_fr_date.Text = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID"))).ToString("yyyy/MM/dd")

        End If

        'Dim xVal() As String = {"1", "2", "3"}
        'Dim yval() As Double = {12, 34, 45}

        'Chart1.Series("Series1").Points.DataBindXY(xVal, yval)

        'System.Diagnostics.Debug.WriteLine(SqlMainSource.SelectCommand)

        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""
        showData()
    End Sub

    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub


    Private Sub showData()
        Dim strVan As String = Right(ddlVanID.Text, 3)
        Dim strGrp As String = ddlMaterialGroup.Text
        Dim strItm As String = ddlMaterial.Text


        Dim strSql As String


        strSql = "SELECT workDate,g.chiDesc as gchiDesc, h.materialCode, i.chiDesc, right(h.vanCode,3) as vanCode,SAP_open_bal,SAP_close_bal,act_close_bal,closing_diff,reason_close from item_balance_history "
        strSql &= "h inner join item_master i on i.materialCode = h.materialCode inner join item_group_master g on g.materialGroupCode = i.materialGroupCode  where workDate = '" & CDate(tb_fr_date.Text).ToString("yyyy-MM-dd") & "'"
        If strVan <> "" Then strSql &= " and right(h.vanCode,3) ='" & strVan & "'"
        If strGrp <> "" Then strSql &= " and g.chiDesc ='" & strGrp & "'"
        If strItm <> "" Then strSql &= " and i.chiDesc ='" & strItm & "'"


        SqlMainSource.SelectCommand = strSql
        gv_txn_detail.DataBind()
    End Sub

    Protected Sub ddlMaterialGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlMaterialGroup.SelectedIndexChanged
        Dim strMaterialGroup As String = Me.ddlMaterialGroup.Text.Trim
        BindMaterial(strMaterialGroup)

    End Sub

    Private Sub BindMaterial(ByVal strMaterialGroup As String)
        Dim strSql As String = "select distinct i.chiDesc from item_group_master g inner join item_master i on g.materialGroupCode = i.materialGroupCode where 1=1"
        If strMaterialGroup <> "" Then
            strSql += " and g.chiDesc = '" & strMaterialGroup & "'"
        End If
        strSql += " union select '' order by i.chiDesc"
        dsMaterial.SelectCommand = strSql
        ddlMaterial.DataBind()

    End Sub



End Class
