﻿Imports System
Imports System.Data.SqlClient
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.Configuration
Imports System.Threading

Partial Public Class _1001conv
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            ' Check user access right and record the login
            'Check_Power("1001", True)
        End If
        Session("mg_sid") = "1"
        Dim mg_id As String = "", SqlString As String = ""
        Dim Sql_conn As SqlConnection
        Dim Sql_command As SqlCommand
        Dim Sql_reader As SqlDataReader

        SqlString = " Select Top 1 mg_id, mg_pass, isnull(mg_pass_old,'') as mg_pass_old From Manager Where mg_sid = @mg_sid"

        Sql_conn = New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Sql_conn.Open()
        Sql_command = New SqlCommand(SqlString, Sql_conn)
        Sql_command.Parameters.AddWithValue("@mg_sid", Session("mg_sid").ToString())
        Sql_reader = Sql_command.ExecuteReader()
        If Sql_reader.Read() Then
            mg_id = Sql_reader("mg_id").ToString().Trim()
            If Sql_reader("mg_pass_old").ToString().Trim() <> "" Then
                '  conversion already done, disable convert again
                btnEncr.Enabled = False
            End If
        End If

        Sql_reader.Close()

        Me.tb_id.Text = mg_id
        'tb_id.Text = "aaa12345"
    End Sub

    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        Dim cfc As New Common_Func()

        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub bnTest_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim data As Byte()
        Dim mg_pass As String = ""
        Dim dcd As New Decoder()

        ' // Encode 
        mg_pass = dcd.DeCode(sou.text)
        'mg_pass = "002"
        encr.Text = mg_pass
        data = System.Text.ASCIIEncoding.ASCII.GetBytes(mg_pass)
        decr.Text = System.Convert.ToBase64String(data)

        '// 


        ' // Decode
        Dim newBytes() As Byte = Convert.FromBase64String(decr.Text)
        Dim tex As String
        tex = System.Text.Encoding.UTF8.GetString(newBytes)
        '//

    End Sub
    Protected Sub bnEncr_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim input As String = ""
        Dim output As String = ""
        Dim sKey = "aZ#48495fdjk4950dj39405fk#$"
        'rc4.EncryptDecryptFile(input, output)
        encr.Text = XorC(tb_id.Text, sKey)
        decr.Text = XorC(encr.Text, sKey)

        Dim base64Decoded As String = "base64 encoded string"
        Dim base64Encoded As String
        Dim data As Byte()
        data = System.Text.ASCIIEncoding.ASCII.GetBytes(base64Decoded)
        base64Encoded = System.Convert.ToBase64String(data)
        Dim sRndStr As String
        Dim mg_pass As String = "", mg_id As String = ""
        Dim pass_old As String = ""
        Dim pass_dec As String = ""
        Dim SqlString As String = ""
        Dim Sql_conn As SqlConnection
        Dim sqlconn As SqlConnection
        Dim Sql_command As SqlCommand
        Dim sql_cmd As SqlCommand
        Dim Sql_reader As SqlDataReader
        Dim dcd As New Decoder()
        Dim ssql As String

        SqlString = "Select mg_id, mg_pass  From Manager "

        Sql_conn = New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Sql_conn.Open()
        sqlconn = New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        sqlconn.Open()
        Sql_command = New SqlCommand(SqlString, Sql_conn)
        sql_cmd = New SqlCommand()
        Sql_reader = Sql_command.ExecuteReader()

        If Sql_reader.HasRows Then
            While Sql_reader.Read
                mg_id = Sql_reader("mg_id").ToString().Trim()
                pass_old = Sql_reader("mg_pass").ToString().Trim()
                mg_pass = dcd.DeCode(Sql_reader("mg_pass").ToString().Trim())
                pass_dec = mg_pass
                data = System.Text.ASCIIEncoding.ASCII.GetBytes(pass_dec)
                mg_pass = System.Convert.ToBase64String(data)
                sRndStr = GenRandStr(4)
                Thread.Sleep(200)
                mg_pass = sRndStr & mg_pass
                ssql = "update Manager set mg_pass_old = '" & pass_old & "', mg_pass = '" & mg_pass & "', mg_pass_dec = '" & pass_dec & "' where mg_id = '" & mg_id & "' "
                sql_cmd.Connection = sqlconn
                sql_cmd.CommandText = ssql
                sql_cmd.ExecuteNonQuery()
            End While
        End If
        Sql_reader.Close()
        sql_cmd = Nothing

        Dim mErr As String = "Finish Convert"
        Dim txtMsgConv As New Literal()
        txtMsgConv.Text = "<script language=javascript>alert('" & mErr & "');</script>"
        Page.Controls.Add(txtMsgConv)

    End Sub

    Public Function GenRandStr(ByRef iLength As Integer) As String
        Dim rdm As New Random()
        Dim allowChrs() As Char = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLOMNOPQRSTUVWXYZ0123456789".ToCharArray()
        Dim sResult As String = ""

        For i As Integer = 0 To iLength - 1
            sResult += allowChrs(rdm.Next(0, allowChrs.Length))
        Next

        Return sResult
    End Function

    Protected Sub bn_ok_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim cfc As New Common_Func()

        Dim mErr As String = "", mg_npass As String = ""

        mg_npass = tb_npass.Text.Trim()

        If tb_spass.Text.Trim() = "" Then
            mErr = mErr & "Please enter password!\n"
        End If

        If mg_npass = "" Then
            mErr = mErr & "Please enter new password!\n"
        ElseIf cfc.CheckSQL(mg_npass) Then
            mErr = mErr & "Special Characters not allowed in new password!\n"
        ElseIf mg_npass.Length > 12 OrElse mg_npass.Length < 4 Then
            mErr = mErr & "The length of the new password is between 4 and 12!\n"
        End If

        If mg_npass <> tb_rpass.Text.Trim() Then
            mErr = mErr & "New Password does not match!\n"
        Else
            If tb_spass.Text.Trim() = tb_npass.Text.Trim() Then
                mErr = mErr & "New Password should be different!\n"
            End If
        End If

        If mErr = "" Then
            Dim mg_pass As String = "", mg_id As String = ""
            Dim SqlString As String = ""
            Dim Sql_conn As SqlConnection
            Dim Sql_command As SqlCommand
            Dim Sql_reader As SqlDataReader
            Dim dcd As New Decoder()

            SqlString = "Select Top 1 mg_id, mg_pass From Manager Where mg_sid = @mg_sid"

            Sql_conn = New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
            Sql_conn.Open()
            Sql_command = New SqlCommand(SqlString, Sql_conn)
            Sql_command.Parameters.AddWithValue("@mg_sid", Session("mg_sid").ToString())
            Sql_reader = Sql_command.ExecuteReader()

            If Sql_reader.Read() Then
                mg_id = Sql_reader("mg_id").ToString().Trim()
                mg_pass = dcd.DeCode(Sql_reader("mg_pass").ToString().Trim())
            End If
            Sql_reader.Close()

            If mg_id = tb_id.Text.Trim() AndAlso mg_pass = tb_spass.Text.Trim() Then
                ' Encode new password.
                mg_pass = dcd.EnCode(tb_npass.Text.Trim())

                ' Change password
                SqlString = "Update Manager Set mg_pass = @mg_pass Where mg_sid = @mg_sid and mg_id = @mg_id"
                Sql_command.Parameters.Clear()
                Sql_command = New SqlCommand(SqlString, Sql_conn)
                Sql_command.Parameters.AddWithValue("@mg_sid", Session("mg_sid").ToString())
                Sql_command.Parameters.AddWithValue("@mg_id", mg_id)
                Sql_command.Parameters.AddWithValue("@mg_pass", mg_pass)
                Sql_command.ExecuteNonQuery()
                mErr = "Password Changed!\n"
            Else
                mErr = mErr & "Incorrect User or Password!\n"
            End If

            Sql_command.Dispose()
            Sql_conn.Close()
        End If

        Dim txtMsg As New Literal()

        txtMsg.Text = "<script language=javascript>alert('" & mErr & "');</script>"
        Page.Controls.Add(txtMsg)

    End Sub

    Function XorC(ByVal sData As String, ByVal sKey As String) As String
        'Dim sKey = "aZ#48495fdjk4950dj39405fk#$"
        Dim l As Long, i As Long, byIn() As Byte, byOut() As Byte, byKey() As Byte
        Dim bEncOrDec As Boolean
        'confirm valid string and key input:
        If Len(sData) = 0 Or Len(sKey) = 0 Then XorC = "Invalid argument(s) used" : Exit Function
        'check whether running encryption or decryption (flagged by presence of "xxx" at start of sData):
        If Left$(sData, 3) = "xxx" Then
            bEncOrDec = False 'decryption
            sData = Mid$(sData, 4)
        Else
            bEncOrDec = True 'encryption
        End If
        'assign strings to byte arrays (unicode)
        byIn = System.Text.Encoding.ASCII.GetBytes(sData)
        byOut = System.Text.Encoding.ASCII.GetBytes(sData)
        byKey = System.Text.Encoding.ASCII.GetBytes(sKey)
        l = LBound(byKey)
        For i = LBound(byIn) To UBound(byIn) - 1 Step 2
            byOut(i) = ((byIn(i) + Not bEncOrDec) Xor byKey(l)) - bEncOrDec 'avoid Chr$(0) by using bEncOrDec flag
            l = l + 2
            If l > UBound(byKey) Then l = LBound(byKey) 'ensure stay within bounds of Key
        Next i
        XorC = System.Text.Encoding.ASCII.GetString(byOut)
        If bEncOrDec Then XorC = "xxx" & XorC 'add "xxx" onto encrypted text
    End Function

End Class