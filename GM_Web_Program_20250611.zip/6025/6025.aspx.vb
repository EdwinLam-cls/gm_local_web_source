﻿Imports System.Data
Imports Common_Func


Partial Class _6025_6025
    Inherits System.Web.UI.Page

    Dim gErr As String = ""



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim tmpstr As String = ""

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("6025", True)
            'btn_Search.Attributes.Add("href", "javascript: return search();")
        End If

        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""


    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub btn_Search_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim strSql As String = getStrSql()
        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()
    End Sub


    Protected Sub gv_custmaster_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gv_custmaster.PageIndexChanging
        Dim strSql As String = getStrSql()
        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()
    End Sub

    Protected Sub gv_custmaster_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gv_custmaster.Sorting
        Dim strSql As String = getStrSql()
        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()
    End Sub

    Private Function getStrSql() As String
        Dim cfc As New Common_Func


        Dim strVanId As String = Me.ddlVanID.Text.Trim
        Dim strRefDocNo As String = cfc.CleanSQL(Me.txtPONo.Text.Trim)
        Dim strDateFrom As String = Me.txtDateFrom.Text
        Dim strDateTo As String = Me.txtDateTo.Text

        Dim strShipFrom As String = Me.txtShipFrom.Text
        Dim strShipTo As String = Me.txtShipTo.Text

        Dim strReason As String = Me.ddlReason.SelectedValue.Trim
        If strReason = "0" Then strReason = ""
        Dim strSql As String = "select h.PO_no, isnull(h.custNo,'Not Found') as custNo,h.cust_name as name1 , h.van_id,convert(varchar(10),h.cr_date,111) cr_date,convert(varchar(10),h.ship_date,111) ship_date,isnull(i.materialCode,'Not Found') as materialCode,d.custMaterialCode, d.engDesc as chiDesc, h.isException as h_error, d.isException as d_error, d.quantity from rush_order_header h inner join rush_order_detail d on h.PO_no = d.PO_no left outer join customer_master c on h.custNo =c.custNo left outer join item_master i on i.materialCode = d.materialCode where isnull(d.isException,'') <>'' "

        If strVanId <> "" Then
            strSql += " and right(h.van_id,3) = '" & Right(strVanId, 3) & "'"
        End If

        If strRefDocNo <> "" Then
            strSql += " and h.PO_no like '%" & strRefDocNo & "%'"
        End If

        If strDateFrom <> "" Then
            strSql += " and convert(varchar(10),h.cr_date,111) >= '" & strDateFrom & "'"
        End If

        If strDateTo <> "" Then
            strSql += " and convert(varchar(10),h.cr_date,111) <= '" & strDateTo & "'"
        End If

        If strShipFrom <> "" Then
            strSql += " and convert(varchar(10),h.ship_date,111) >= '" & strShipFrom & "'"
        End If

        If strShipTo <> "" Then
            strSql += " and convert(varchar(10),h.ship_date,111) <= '" & strShipTo & "'"
        End If



        If strReason <> "" Then
            strSql += " and (h.isException = '" & strReason & "'"
            strSql += " or d.isException = '" & strReason & "')"
        End If
        strSql += " order by PO_no"
        Return strSql
    End Function



End Class
