﻿'---------------------------------------------------------------------------- 
'程式功能	District Master > 明細內容 > 新增資料
'---------------------------------------------------------------------------- 

Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration

Partial Class _2012_2012_add
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0

            ' 檢查使用者權限但不存入登入紀錄 
            Check_Power("2012", False)

            ' 承接上一頁的查詢條件設定
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid").ToString(), ckint) Then
                    lb_page.Text = "?pageid=" & ckint.ToString()
                Else
                    lb_page.Text = "?pageid=0"
                End If
            End If

            If Request("district_id") IsNot Nothing Then
                lb_page.Text &= "&district_id=" & Request("district_id")
            End If
            ' disable the save button
            lb_ok.Visible = False

        End If
    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub ddlMaterialGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlMaterialGroup.SelectedIndexChanged
        Dim strMaterialGroup As String = Me.ddlMaterialGroup.Text.Trim
        BindMaterial(strMaterialGroup)

    End Sub

    Private Sub BindMaterial(ByVal strMaterialGroup As String)
        Dim strSql As String = "select distinct i.chiDesc, i.materialCode from item_group_master g inner join item_master i on g.materialGroupCode = i.materialGroupCode where 1=1"
        If strMaterialGroup <> "" Then
            strSql += " and g.chiDesc = '" & strMaterialGroup & "'"
        End If
        strSql += " union select '','' order by i.chiDesc"
        dsMaterial.SelectCommand = strSql
        ddlMaterial.DataBind()

    End Sub

    Protected Sub lb_ok_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim mErr As String = ""
        Dim mg_sid As Integer = -1
        Dim intCountGroupNo As Integer = 0

        ' 載入字串函數 
        Dim sfc As New String_Func()

        ' 載入公用函數 
        Dim cfc As New Common_Func()

        Dim bolCheckVan As String = ""

        If ddlMaterial.Text.Trim = "" Then
            mErr &= "Please select one material\n"
        End If


        For Each item As ListItem In cblVan.Items
            If item.Selected = True Then
                bolCheckVan &= item.Text & ","
                intCountGroupNo += 1
            End If
        Next

        If bolCheckVan = "" Then
            mErr &= "Select at least one Customer Group\n"
        Else
            bolCheckVan = bolCheckVan.Substring(0, bolCheckVan.Length - 2)
        End If



        'Dim strValidFrom As String = ""

        'If Me.txtValidFrom.Text.Trim() = "" Then
        '    mErr &= "Please enter [Valid Period From] \n"
        'Else
        '    Try
        '        strValidFrom = CDate(Me.txtValidFrom.Text).ToString("yyyy-MM-dd")
        '    Catch ex As Exception
        '        ClientScript.RegisterStartupScript(Me.GetType(), "recScript", "alert('" & "Wrong Date!" & "');", True)
        '        Exit Sub
        '    End Try
        'End If

        'Dim strValidTo As String = ""

        'If Me.txtValidTo.Text.Trim() = "" Then
        '    mErr &= "Please enter [Valid Period To]\n"
        'Else
        '    Try
        '        strValidTo = CDate(Me.txtValidTo.Text).ToString("yyyy-MM-dd")
        '    Catch ex As Exception
        '        ClientScript.RegisterStartupScript(Me.GetType(), "recScript", "alert('" & "Wrong Date!" & "');", True)
        '        Exit Sub
        '    End Try
        'End If



        If mErr = "" Then
            Using Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                Dim SqlString As String = ""


                ' 建立 SQL 的語法 
                SqlString = "Insert Into listing (materialCode,chiDesc, custGroup,groupName, valid_from, valid_to, updatedDate, updatedBy)"
                SqlString &= " Values  (@materialCode,@chiDesc, @custGroup, @groupName, @valid_from, @valid_to, @updatedDate, @updatedBy);"
                Dim strMaterialCode As String = ddlMaterial.SelectedValue
                Dim strChiDesc As String = ddlMaterial.SelectedItem.Text
                Dim strVanIds As String = bolCheckVan
                Dim dtmCreateDate As DateTime = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID")))
                'Dim dtmFrom As DateTime = CDate(strValidFrom)
                'Dim dtmTo As DateTime = CDate(strValidTo)
                Dim dtmFrom As DateTime = CDate("1900-01-01")
                Dim dtmTo As DateTime = CDate("2099-12-31")
                Dim intExpired As Integer = 0
                Dim strUserName As String = Session("mg_name")





                Using Sql_Command As New SqlCommand()
                    Sql_Command.Connection = Sql_conn
                    Sql_Command.CommandText = SqlString

                    Sql_conn.Open()


                    Dim strGroup() As String = strVanIds.Split(",")
                    Dim strGroupNo As String
                    Dim strGroupName As String
                    For i = 0 To intCountGroupNo - 1
                        Dim intPosition As Integer = strGroup(i).IndexOf(" ")
                        strGroupNo = strGroup(i).Split(" ")(0)
                        strGroupName = strGroup(i).Substring(intPosition).Trim

                        ' 擷取字串到資料庫所規範的大小 sfc.Left(string mdata, int leng) 
                        Sql_Command.Parameters.AddWithValue("@materialCode", strMaterialCode)
                        Sql_Command.Parameters.AddWithValue("@chiDesc", strChiDesc)
                        Sql_Command.Parameters.AddWithValue("@custGroup", strGroupNo)
                        Sql_Command.Parameters.AddWithValue("@groupName", strGroupName)
                        Sql_Command.Parameters.AddWithValue("@valid_from", dtmFrom)
                        Sql_Command.Parameters.AddWithValue("@valid_to", dtmTo)
                        Sql_Command.Parameters.AddWithValue("@updatedDate", dtmCreateDate)
                        Sql_Command.Parameters.AddWithValue("@updatedBy", strUserName)

                        Sql_Command.ExecuteNonQuery()
                        Sql_Command.Parameters.Clear()

                    Next

                    SqlString = "  update customer_material_info_pda set is_active = 1 "
                    SqlString += " update customer_material_info_pda set is_active = 0 from customer_group_master g inner join customer_material_info_pda p on g.custGroup = p.custGroup where block = 1 "
                    SqlString += " update customer_material_info_pda set is_active = 0 where materialCode in(select distinct materialCode from listing)"
                    SqlString += " update customer_material_info_pda set is_active = 1 from customer_material_info_pda p inner join listing l on l.custGroup =p.custGroup and l.materialCode = p.materialCode"

                    Sql_Command.CommandText = SqlString
                    Sql_Command.ExecuteNonQuery()
                    Sql_Command.Dispose()

                    ' 取得新增資料的主鍵值 
                    mg_sid = 0
                End Using
            End Using
        End If


        If mErr = "" Then
            mErr = ("alert('Record saved successfully!\n');location.replace('2012.aspx" & lb_page.Text & "&sid=") + mg_sid.ToString() & "');"
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", mErr, True)
        Else
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('" & mErr & "')", True)
        End If


    End Sub



End Class
