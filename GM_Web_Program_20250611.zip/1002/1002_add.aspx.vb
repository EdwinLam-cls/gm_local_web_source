﻿'---------------------------------------------------------------------------- 
'程式功能	人員資料管理 > 明細內容 > 新增資料
'---------------------------------------------------------------------------- 

Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration

Partial Public Class _1002_add
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0

            ' 檢查使用者權限但不存入登入紀錄 
            Check_Power("1002", False)

            ' 承接上一頁的查詢條件設定
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid").ToString(), ckint) Then
                    lb_page.Text = "?pageid=" & ckint.ToString()
                Else
                    lb_page.Text = "?pageid=0"
                End If
            End If

            If Request("mg_sid") IsNot Nothing Then
                lb_page.Text &= "&mg_sid=" & Request("mg_sid")
            End If

            If Request("mg_name") IsNot Nothing Then
                lb_page.Text &= "&mg_name=" & Server.UrlEncode(Request("mg_name"))
            End If

            If Request("mg_nike") IsNot Nothing Then
                lb_page.Text &= "&mg_nike=" & Server.UrlEncode(Request("mg_nike"))
            End If

            If Request("btime") IsNot Nothing Then
                lb_page.Text &= "&btime=" & Server.UrlEncode(Request("btime"))
            End If

            If Request("etime") IsNot Nothing Then
                lb_page.Text &= "&etime=" & Server.UrlEncode(Request("etime"))
            End If
        End If
    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub lb_ok_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim mErr As String = ""
        Dim mg_sid As Integer = -1

        Dim sfc As New String_Func()
        Dim cfc As New Common_Func()

        If txtLoginID.Text.Trim() = "" Then
            mErr &= " Please enter Login name!\n"
        ElseIf cfc.CheckSQL(txtLoginID.Text.Trim()) Then
            mErr &= " Special Characters not allowed in login name!\n"
        End If

        If ddlPDA.SelectedValue = "Y" Then
            If txtPass.Text.Length > 12 OrElse txtPass.Text.Length < 4 Then
                mErr &= "The length of the password is between 4 and 12!\n"
            End If
        End If

        'GMI Commented out since we do not want to store any passwords in DB
        'If tb_mg_pass.Text.Trim() = "" Then
        '    mErr &= "「登入密碼」沒有輸入!\n"
        'ElseIf cfc.CheckSQL(tb_mg_pass.Text.Trim()) Then
        '    mErr &= "「登入密碼」請勿使用特殊符號!\n"
        'ElseIf tb_mg_pass.Text.Trim().Length > 12 OrElse tb_mg_pass.Text.Trim().Length < 4 Then
        '    mErr &= "「登入密碼」長度為4~12個字!!\n"
        'End If

        'If tb_mg_pass.Text <> tb_mg_pass1.Text Then
        '    mErr &= "「登入密碼」與「密碼確認」不相同!\n"
        'End If

        If txtSurname.Text.Trim() = "" Then
            mErr &= " Please enter name!\n"
        End If

        If txtNickName.Text.Trim() = "" Then
            mErr &= "Please enter nickname!\n"
        End If

        If ddlAuthority.Text.Trim() = "" Then
            mErr &= "Please enter class!\n"
        End If

        If mErr = "" Then
            Using Sql_Conn1 As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                Dim SqlString1 As String = ""

                SqlString1 = "Select Top 1 * "
                SqlString1 &= " From Manager b"
                SqlString1 &= " Where b.mg_id = @mg_id"

                Using Sql_Command1 As New SqlCommand(SqlString1, Sql_Conn1)
                    Sql_Conn1.Open()

                    Sql_Command1.Parameters.AddWithValue("mg_id", txtLoginID.Text.Trim())


                    Using Sql_Reader1 As SqlDataReader = Sql_Command1.ExecuteReader()
                        If Sql_Reader1.Read() Then
                            mErr = "Login name is already used!\n"
                        End If
                    End Using
                    Sql_Command1.Dispose()
                End Using
            End Using
        End If

        If mErr = "" Then
            Using Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                Dim SqlString As String = ""
                Dim decoder As New Decoder()
                Dim tran As SqlClient.SqlTransaction
                Sql_conn.Open()
                tran = Sql_conn.BeginTransaction


                ' 建立 SQL 的語法 
                SqlString = "Insert Into Manager (mg_name, mg_nike, mg_id, mg_pass, mg_unit, mg_desc,is_active, is_pda_user)"
                SqlString &= " Values (@mg_name, @mg_nike, @mg_id, @mg_pass, @mg_unit, @mg_desc,@is_active, @is_pda_user);"
                SqlString &= "Select @mg_sid = Scope_Identity()"
                SqlString &= "insert into Func_power select @mg_sid as mg_sid, fi2.fi_no1 ,fi2.fi_no2,'1' as is_enable  from func_item1 fi1 "
                SqlString &= "inner join func_item2 fi2 on fi1.fi_no1 = fi2.fi_no1 where fi1.is_visible = 1 and fi2.is_visible = 1"

                If sfc.Left(ddlAuthority.Text.Trim(), 50) = "N" Then
                    SqlString &= " and fi1.fi_no1 = '6'"
                End If

                Using Sql_Command As New SqlCommand()
                    Sql_Command.Transaction = tran
                    Sql_Command.Connection = Sql_conn
                    Sql_Command.CommandText = SqlString

                    Dim sRndStr As String
                    sRndStr = GenRandStr(4)


                    ' 擷取字串到資料庫所規範的大小 sfc.Left(string mdata, int leng) 
                    Sql_Command.Parameters.AddWithValue("@mg_name", sfc.Left(txtSurname.Text.Trim(), 50))
                    Sql_Command.Parameters.AddWithValue("@mg_nike", sfc.Left(txtNickName.Text.Trim(), 50))
                    Sql_Command.Parameters.AddWithValue("@mg_id", sfc.Left(txtLoginID.Text.Trim(), 50))
                    If Left(ddlPDA.Text, 1) = "Y" Then
                        'Sql_Command.Parameters.AddWithValue("@mg_pass", decoder.EnCode(sfc.Left(txtPass.Text, 12)))
                        Sql_Command.Parameters.AddWithValue("@mg_pass", sRndStr & EncodePass(sfc.Left(txtPass.Text, 12)))
                    Else
                        Sql_Command.Parameters.AddWithValue("@mg_pass", sRndStr & EncodePass(System.Web.Security.Membership.GeneratePassword(12, 2))) 'gmi changed to store some randome password val
                    End If
                    Sql_Command.Parameters.AddWithValue("@mg_unit", sfc.Left(ddlAuthority.Text.Trim(), 50))
                    Sql_Command.Parameters.AddWithValue("@mg_desc", sfc.Left(txtRemarks.Text.Trim(), 1000))
                    Sql_Command.Parameters.AddWithValue("@is_pda_user", IIf(Left(ddlPDA.Text, 1) = "Y", "1", "0"))
                    Sql_Command.Parameters.AddWithValue("@is_active", "1")

                    Dim spt_mg_sid As SqlParameter = Sql_Command.Parameters.Add("@mg_sid", SqlDbType.Int)
                    spt_mg_sid.Direction = ParameterDirection.Output

                    Try
                        Sql_Command.ExecuteNonQuery()
                        tran.Commit()
                        ' 取得新增資料的主鍵值 
                        mg_sid = CInt(spt_mg_sid.Value)
                    Catch
                        tran.Rollback()
                    Finally
                        Sql_conn.Close()
                    End Try
                End Using
            End Using
        End If

        If mErr = "" Then
            mErr = ("alert('Saved successfully!\n');location.replace('1002_view.aspx" & "?mg_sid=") + mg_sid.ToString() & "');"
        Else
            mErr = "alert('" & mErr & "')"
        End If
        lt_show.Text = "<script language=javascript>" & mErr & "</script>"
    End Sub

    Protected Sub ddlPDA_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlPDA.SelectedIndexChanged
        If Left(ddlPDA.Text, 1) = "Y" Then
            txtPass.Visible = True
            lblPass.Visible = True
            txtPass.Text = ""
        Else

            txtPass.Visible = False
            lblPass.Visible = False
            txtPass.Text = ""
        End If
    End Sub

    '// Use new encode logic 
    Function EncodePass(ByVal password As String) As String
        Dim Data() As Byte
        Dim EnStr As String
        ' // Encode 
        Data = System.Text.ASCIIEncoding.ASCII.GetBytes(password)
        EnStr = System.Convert.ToBase64String(Data)
        Return EnStr

    End Function

    Function DecodePass(ByVal password As String) As String
        ' // Decode
        Dim newBytes() As Byte = Convert.FromBase64String(password)
        Dim DeStr As String
        DeStr = System.Text.ASCIIEncoding.ASCII.GetString(newBytes)
        Return DeStr
        '//
    End Function

    Public Function GenRandStr(ByRef iLength As Integer) As String
        Dim rdm As New Random()
        Dim allowChrs() As Char = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLOMNOPQRSTUVWXYZ0123456789".ToCharArray()
        Dim sResult As String = ""

        For i As Integer = 0 To iLength - 1
            sResult += allowChrs(rdm.Next(0, allowChrs.Length))
        Next

        Return sResult
    End Function


End Class