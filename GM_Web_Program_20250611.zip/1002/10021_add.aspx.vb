﻿'---------------------------------------------------------------------------- 
'程式功能	人員資料管理 > 明細內容 > 新增資料
'---------------------------------------------------------------------------- 

Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration

Partial Public Class _10021_add
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0

            ' 檢查使用者權限但不存入登入紀錄 
            Check_Power("1005", False)

            ' 承接上一頁的查詢條件設定
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid").ToString(), ckint) Then
                    lb_page.Text = "?pageid=" & ckint.ToString()
                Else
                    lb_page.Text = "?pageid=0"
                End If
            Else
                lb_page.Text = "?pageid=0"
            End If

            If Request("mg_sid") IsNot Nothing Then
                lb_page.Text &= "&mg_sid=" & Request("mg_sid")
            End If

            If Request("mg_name") IsNot Nothing Then
                lb_page.Text &= "&mg_name=" & Server.UrlEncode(Request("mg_name"))
            End If

            If Request("mg_nike") IsNot Nothing Then
                lb_page.Text &= "&mg_nike=" & Server.UrlEncode(Request("mg_nike"))
            End If

            If Request("btime") IsNot Nothing Then
                lb_page.Text &= "&btime=" & Server.UrlEncode(Request("btime"))
            End If

            If Request("etime") IsNot Nothing Then
                lb_page.Text &= "&etime=" & Server.UrlEncode(Request("etime"))
            End If
        End If
    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub lb_ok_Click(ByVal sender As Object, ByVal e As EventArgs) Handles lb_ok.Click
        Dim mErr As String = ""
        Dim mg_sid As Integer = -1

        Dim sfc As New String_Func()
        Dim cfc As New Common_Func()

        If tb_mg_id.Text.Trim() = "" Then
            mErr &= "Please enter login name!\n"
        ElseIf cfc.CheckSQL(tb_mg_id.Text.Trim()) Then
            mErr &= "Special Characters not allowed in login name!\n"
        End If

        'GMI Commented out password handling
        'If tb_mg_pass.Text.Trim() = "" Then
        '    mErr &= "please enter password!\n"
        'ElseIf cfc.CheckSQL(tb_mg_pass.Text.Trim()) Then
        '    mErr &= "Special Characters not allowed in password!\n"
        'ElseIf tb_mg_pass.Text.Trim().Length > 12 OrElse tb_mg_pass.Text.Trim().Length < 4 Then
        '    mErr &= "password length should be between 4 and 12\n"
        'End If

        'If tb_mg_pass.Text <> tb_mg_pass1.Text Then
        '    mErr &= "New password should be different!\n"
        'End If

        If tb_mg_name.Text.Trim() = "" Then
            mErr &= "Please enter name!\n"
        End If

        If tb_mg_nike.Text.Trim() = "" Then
            mErr &= "Please enter nickname!\n"
        End If

        If tb_mg_unit.Text.Trim() = "" Then
            mErr &= "Please enter class!\n"
        End If

        If mErr = "" Then
            Using Sql_Conn1 As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                Dim SqlString1 As String = ""

                SqlString1 = "Select Top 1 * "
                SqlString1 &= " From Manager b"
                SqlString1 &= " Where b.mg_id = @mg_id"


                Using Sql_Command1 As New SqlCommand(SqlString1, Sql_Conn1)
                    Sql_Conn1.Open()

                    Sql_Command1.Parameters.AddWithValue("mg_id", tb_mg_id.Text.Trim())

                    Using Sql_Reader1 As SqlDataReader = Sql_Command1.ExecuteReader()
                        If Sql_Reader1.Read() Then
                            mErr = "This user name is already used!\n"
                        End If
                    End Using
                    Sql_Command1.Dispose()
                End Using
            End Using
        End If

        If mErr = "" Then
            Using Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                Dim SqlString As String = ""
                Dim decoder As New Decoder()

                ' 建立 SQL 的語法 
                SqlString = "Insert Into Manager (mg_name, mg_nike, mg_id, mg_pass, mg_unit, mg_desc)"
                SqlString &= " Values (@mg_name, @mg_nike, @mg_id, @mg_pass, @mg_unit, @mg_desc);"
                SqlString &= "Select @mg_sid = Scope_Identity();"
                SqlString &= "insert into Func_power select @mg_sid as mg_sid, fi2.fi_no1 ,fi2.fi_no2,'1' as is_enable  from func_item1 fi1 "
                SqlString &= "inner join func_item2 fi2 on fi1.fi_no1 = fi2.fi_no1 where fi1.is_visible = 1 and fi2.is_visible = 1"

                Using Sql_Command As New SqlCommand()
                    Sql_Command.Connection = Sql_conn
                    Sql_Command.CommandText = SqlString

                    ' 擷取字串到資料庫所規範的大小 sfc.Left(string mdata, int leng) 

                    Sql_Command.Parameters.AddWithValue("@mg_name", sfc.Left(tb_mg_name.Text.Trim(), 50))
                    Sql_Command.Parameters.AddWithValue("@mg_nike", sfc.Left(tb_mg_nike.Text.Trim(), 50))
                    Sql_Command.Parameters.AddWithValue("@mg_id", sfc.Left(tb_mg_id.Text.Trim(), 50))
                    Sql_Command.Parameters.AddWithValue("@mg_pass", decoder.EnCode(System.Web.Security.Membership.GeneratePassword(12, 2))) 'gmi changed to store some randome password val
                    Sql_Command.Parameters.AddWithValue("@mg_unit", sfc.Left(tb_mg_unit.Text.Trim(), 50))
                    Sql_Command.Parameters.AddWithValue("@mg_desc", sfc.Left(tb_mg_desc.Text.Trim(), 1000))
                    Dim spt_mg_sid As SqlParameter = Sql_Command.Parameters.Add("@mg_sid", SqlDbType.Int)
                    spt_mg_sid.Direction = ParameterDirection.Output


                    Sql_conn.Open()

                    Sql_Command.ExecuteNonQuery()
                    Sql_conn.Close()
                    ' 取得新增資料的主鍵值 
                    mg_sid = CInt(spt_mg_sid.Value)
                End Using
            End Using
        End If

        If mErr = "" Then
            mErr = ("alert('Saved successfully!\nPlease wait.....\n');location.replace('1002_view.aspx" & "?mg_sid=") + mg_sid.ToString() & "');"
        Else
            mErr = "alert('" & mErr & "')"
        End If
        lt_show.Text = "<script language=javascript>" & mErr & "</script>"
    End Sub

   

End Class