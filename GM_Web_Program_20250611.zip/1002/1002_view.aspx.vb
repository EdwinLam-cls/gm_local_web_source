﻿'---------------------------------------------------------------------------- 
'程式功能	人員資料管理 > 明細內容
'---------------------------------------------------------------------------- 

Imports System
Imports System.Data.SqlClient
Imports System.Web.Configuration

Partial Public Class _1002
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0, mg_sid As Integer = -1
            Dim SqlString As String = "", mErr As String = ""

            ' 檢查使用者權限但不存入登入紀錄 
            Check_Power("1002", False)

            ' 承接上一頁的查詢條件設定 
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid").ToString(), ckint) Then
                    lb_page.Text = "?pageid=" & ckint.ToString()
                Else
                    lb_page.Text = "?pageid=" & "0"
                End If
            Else
                lb_page.Text = "?"
            End If

            If Request("mg_sid") IsNot Nothing Then
                lb_page.Text &= "&mg_sid=" & Request("mg_sid")
            End If

            If Request("mg_name") IsNot Nothing Then
                lb_page.Text &= lb_page.Text & "&mg_name=" & Server.UrlEncode(Request("mg_name"))
            End If

            If Request("mg_nike") IsNot Nothing Then
                lb_page.Text &= "&mg_nike=" & Server.UrlEncode(Request("mg_nike"))
            End If

            If Request("btime") IsNot Nothing Then
                lb_page.Text &= "&btime=" & Server.UrlEncode(Request("btime"))
            End If

            If Request("etime") IsNot Nothing Then
                lb_page.Text &= "&etime=" & Server.UrlEncode(Request("etime"))
            End If

            ' 檢查傳入參數 
            If Request("mg_sid") IsNot Nothing Then
                If Integer.TryParse(Request("mg_sid").ToString(), mg_sid) Then
                    ' 取得相關資料 
                    Using sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                        sql_conn.Open()

                        ' "取得人員基本資料
                        SqlString = "Select Top 1 mg_sid, mg_name, mg_nike, mg_id, mg_unit, mg_desc, last_date, init_time, is_pda_user,is_active"
                        SqlString &= " From Manager Where mg_sid = " & mg_sid.ToString()

                        Using Sql_Command As New SqlCommand(SqlString, sql_conn)
                            Using Sql_Reader As SqlDataReader = Sql_Command.ExecuteReader()
                                If Sql_Reader.Read() Then
                                    lb_mg_sid.Text = Sql_Reader("mg_sid").ToString()
                                    lb_mg_id.Text = Sql_Reader("mg_id").ToString()
                                    lb_mg_name.Text = Sql_Reader("mg_name").ToString().Trim()
                                    lb_mg_nike.Text = Sql_Reader("mg_nike").ToString().Trim()
                                    lb_mg_unit.Text = Sql_Reader("mg_unit").ToString().Trim()
                                    lb_mg_desc.Text = Sql_Reader("mg_desc").ToString().Trim()
                                    lb_is_pda_user.Text = Sql_Reader("is_pda_user").ToString().Trim()
                                    lb_active.Text = Sql_Reader("is_active").ToString().Trim()

                                    If Sql_Reader.IsDBNull(6) Then
                                        lb_last_date.Text = "[No login record yet]"
                                    Else
                                        lb_last_date.Text = DirectCast(Sql_Reader("last_date"), DateTime).ToString("yyyy/MM/dd hh:mm")
                                    End If
                                    lb_init_time.Text = DirectCast(Sql_Reader("init_time"), DateTime).ToString("yyyy/MM/dd hh:mm")
                                Else
                                    mErr = "No record for current user!\n"
                                End If
                            End Using
                        End Using

                        ' 取得人員權限資料
                        If mg_sid = 1 Then
                            ' 關閉權限設定選項 
                            'lk_power.Visible = False
                            lk_del.Visible = False

                            ' 若為系統總管理者，擁有全部的功能執行權限 
                            SqlString = "Select f1.fi_name_eng1 as fi_name1 ,  f2.fi_name_eng2 as fi_name2 From Func_Item2 f2"
                            SqlString &= " Left Outer Join Func_Item1 f1 On f2.fi_no1 = f1.fi_no1"
                            SqlString &= " Where f2.is_visible = 1 order by f2.fi_no2"
                        Else
                            ' 一般使用者，由人員系統權限 Func_Power 資料表取得可執行的權限 
                            SqlString = "Select f1.fi_name_eng1 as fi_name1, f2.fi_name_eng2 as fi_name2 From Func_Power p"
                            SqlString &= " Left Outer Join Func_Item2 f2 On p.fi_no2 = f2.fi_no2"
                            SqlString &= " Left Outer Join Func_Item1 f1 On f2.fi_no1 = f1.fi_no1 and p.fi_no1 = f1.fi_no1"
                            SqlString &= " Where p.mg_sid = @mg_sid And p.is_enable = 1 and f1.is_visible = 1 and f2.is_visible =1 order by f2.fi_no2"
                        End If

                        Using Sql_Command As New SqlCommand(SqlString, sql_conn)
                            Sql_Command.Parameters.AddWithValue("@mg_sid", mg_sid)

                            Using Sql_Reader As SqlDataReader = Sql_Command.ExecuteReader()
                                Dim spower As String = "", bgcolor As String = "", fi_name1 As String = "", sfi_name1 As String

                                While Sql_Reader.Read()
                                    If fi_name1 = Sql_Reader("fi_name1").ToString().Trim() Then
                                        sfi_name1 = ""
                                    Else
                                        sfi_name1 = Sql_Reader("fi_name1").ToString().Trim()
                                        fi_name1 = sfi_name1

                                        If bgcolor = "" Then
                                            bgcolor = " style='background-color:#99FF99'"
                                        Else
                                            bgcolor = ""
                                        End If
                                    End If

                                    spower &= "<tr align=left" & bgcolor & ">"
                                    spower &= "<td class=text9pt>" & sfi_name1 & "</td>"
                                    spower &= "<td class=text9pt>" & Sql_Reader("fi_name2").ToString().Trim() & "</td>"
                                    spower &= "<td class=text9pt align=center>Accessible</td></tr>"
                                End While

                                If spower = "" Then
                                    spower = "<tr><td align=center colspan=3 class=text9pt style='height:24pt'>No rights for this user!</td></tr>"
                                End If

                                lt_power.Text = "<table cellspacing=0 cellpadding=4 rules=all border=0 style='width:580px;background-color:#F7F7DE;border-color:#003366;border-width:1px;border-style:Double;border-collapse:collapse;'>"
                                lt_power.Text &= "<tr align=center bgcolor=#FF6A04>"
                                lt_power.Text &= "<td class=text9pt style='color:white'>Main Function</td>"
                                lt_power.Text &= "<td class=text9pt style='color:white'>Sub Function</td>"
                                lt_power.Text &= "<td class=text9pt style='color:white'>Rights</td>"
                                lt_power.Text &= "</tr>"
                                lt_power.Text &= spower
                                lt_power.Text &= "</table>"
                            End Using
                        End Using
                    End Using
                Else
                    mErr = "Parameters Error!\n"
                End If

                If mErr <> "" Then
                    lt_show.Text = "<script language='javascript'>alert('" & mErr & "');history.go(-1);</script>"
                Else
                    lb_pg_mg_sid.Text = mg_sid.ToString()
                    '#End Region 
                End If
            End If
        End If
    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    'Protected Sub lk_power_Click(ByVal sender As Object, ByVal e As EventArgs) Handles lk_power.Click
    '    Response.Redirect("100511.aspx" & lb_page.Text & "&sid=" & lb_pg_mg_sid.Text)
    'End Sub
End Class
