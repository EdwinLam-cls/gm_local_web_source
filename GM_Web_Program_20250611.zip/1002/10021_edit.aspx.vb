﻿'---------------------------------------------------------------------------- 
'程式功能	人員資料管理 > 明細內容 > 修改資料
'---------------------------------------------------------------------------- 
Imports System
Imports System.Data.SqlClient
Imports System.Web.Configuration
Imports System.Data

Partial Public Class _10021_edit
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Dim mg_sid As Integer = -1
        Dim SqlString As String = "", mErr As String = ""

        If Not IsPostBack Then
            Dim ckint As Integer = 0

            ' 檢查使用者權限但不存入登入紀錄 
            Check_Power("1005", False)


            ' 承接上一頁的查詢條件設定
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid").ToString(), ckint) Then
                    lb_page.Text = "?pageid=" & ckint.ToString()
                Else
                    lb_page.Text = "?pageid=0"
                End If
            Else
                lb_page.Text = "?pageid=0"
            End If

            If Request("mg_sid") IsNot Nothing Then
                lb_page.Text &= "&mg_sid=" & Request("mg_sid")
            End If

            If Request("mg_name") IsNot Nothing Then
                lb_page.Text &= "&mg_name=" & Server.UrlEncode(Request("mg_name"))
            End If

            If Request("mg_nike") IsNot Nothing Then
                lb_page.Text &= "&mg_nike=" & Server.UrlEncode(Request("mg_nike"))
            End If

            If Request("btime") IsNot Nothing Then
                lb_page.Text &= "&btime=" & Server.UrlEncode(Request("btime"))
            End If

            If Request("etime") IsNot Nothing Then
                lb_page.Text &= "&etime=" & Server.UrlEncode(Request("etime"))
            End If

            ' 檢查傳入參數
            If Request("sid") IsNot Nothing Then
                ' 取得相關資料
                If Integer.TryParse(Request("sid").ToString(), mg_sid) Then
                    lb_page.Text &= "&sid=" & mg_sid.ToString()

                    Using sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                        sql_conn.Open()

                        ' 取得人員基本資料
                        SqlString = "Select Top 1 mg_sid, mg_name, mg_nike, mg_id, mg_unit, mg_desc, last_date, init_time, is_pda_user, is_active"
                        SqlString &= " From Manager Where mg_sid = " & mg_sid.ToString()

                        Using Sql_Command As New SqlCommand(SqlString, sql_conn)
                            Using Sql_Reader As SqlDataReader = Sql_Command.ExecuteReader()
                                If Sql_Reader.Read() Then
                                    lb_mg_sid.Text = Sql_Reader("mg_sid").ToString()
                                    tb_mg_id.Text = Sql_Reader("mg_id").ToString()
                                    tb_mg_name.Text = Sql_Reader("mg_name").ToString().Trim()
                                    tb_mg_nike.Text = Sql_Reader("mg_nike").ToString().Trim()
                                    tb_mg_unit.Text = Sql_Reader("mg_unit").ToString().Trim()
                                    tb_mg_desc.Text = Sql_Reader("mg_desc").ToString().Trim()

                                    If Sql_Reader("is_pda_user").ToString().Trim() = "1" Then
                                        ddlPDA.SelectedIndex = 0
                                        txtPass.Enabled = True
                                    Else
                                        ddlPDA.SelectedIndex = 1
                                        txtPass.Enabled = False
                                    End If

                                    If Sql_Reader("is_active").ToString().Trim() = "1" Then
                                        ddlIsActive.SelectedIndex = 0
                                    Else
                                        ddlIsActive.SelectedIndex = 1
                                    End If

                                    If Sql_Reader.IsDBNull(6) Then
                                        lb_last_date.Text = "[No Login Record]"
                                    Else
                                        lb_last_date.Text = DirectCast(Sql_Reader("last_date"), DateTime).ToString("yyyy/MM/dd hh:mm")
                                    End If
                                    lb_init_time.Text = DirectCast(Sql_Reader("init_time"), DateTime).ToString("yyyy/MM/dd hh:mm")

                                    lb_pg_mg_sid.Text = mg_sid.ToString()

                                    If mg_sid = 0 Then
                                        tb_mg_name.ReadOnly = True
                                        tb_mg_name.Enabled = False
                                    End If
                                Else
                                    mErr = "Cannot find record!\n"
                                End If
                            End Using
                        End Using
                    End Using
                Else
                    mErr = "Error in page parameter!\n"
                End If
            Else
                mErr = "Error in page parameter!\n"
            End If

            If mErr <> "" Then
                lt_show.Text = "<script language='javascript'>alert('" & mErr & "');history.go(-1);</script>"
            End If
        End If
    End Sub


    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub ddlPDA_OnSelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlPDA.SelectedIndexChanged
        If ddlPDA.SelectedItem.Text.Trim = "Yes" Then
            txtPass.Enabled = True
        Else
            txtPass.Enabled = False
        End If
    End Sub


    Protected Sub lb_ok_Click(ByVal sender As Object, ByVal e As EventArgs) Handles lb_ok.Click
        Dim mErr As String = ""

        ' 載入字串函數 
        Dim sfc As New String_Func()

        ' 載入公用函數 
        Dim cfc As New Common_Func()

        If tb_mg_id.Text.Trim() = "" Then
            mErr = mErr & "Please enter login name!\n"
        ElseIf cfc.CheckSQL(tb_mg_id.Text.Trim()) Then
            mErr = mErr & "No Special characters in login name !\n"
        End If

        If tb_mg_name.Text.Trim() = "" Then
            mErr = mErr & "Please enter name!\n"
        End If

        If tb_mg_nike.Text.Trim() = "" Then
            mErr = mErr & "Please enter nickname!\n"
        End If

        If tb_mg_unit.Text.Trim() = "" Then
            mErr = mErr & "Please enter class!\n"
        End If

        If mErr = "" Then
            Using Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                Dim SqlString As String = ""

                Sql_conn.Open()

                ' 檢查「帳號」是否有其它人用過 (帳號不允許重覆) 
                SqlString = "Select Top 1 mg_id From Manager Where mg_id = @mg_id And mg_sid <> @mg_sid"

                Using Sql_Command As New SqlCommand(SqlString, Sql_conn)

                    Sql_Command.Parameters.AddWithValue("@mg_id", sfc.Left(tb_mg_id.Text, 12))
                    Sql_Command.Parameters.AddWithValue("@mg_sid", lb_pg_mg_sid.Text)

                    Dim Sql_Reader As SqlDataReader = Sql_Command.ExecuteReader()

                    If Sql_Reader.Read() Then
                        mErr = mErr & "This login name is already used!\n"
                    End If

                    Sql_Reader.Close()
                    Sql_Reader.Dispose()
                End Using

                If mErr = "" Then
                    ' 建立 SQL 修改資料的語法 
                    SqlString = "Update Manager Set mg_name = @mg_name, mg_nike = @mg_nike, mg_id = @mg_id"
                    SqlString &= ", mg_unit = @mg_unit, mg_desc = @mg_desc, init_time = @getdate, is_pda_user = @is_pda_user, is_active = @is_active"
                    SqlString &= " Where mg_sid = @mg_sid"


                    Using Sql_Command As New SqlCommand(SqlString, Sql_conn)
                        Sql_Command.Parameters.Clear()

                        ' 擷取字串到資料庫所規範的大小 sfc.Left(string mdata, int leng) 
                        Sql_Command.Parameters.AddWithValue("@mg_sid", lb_pg_mg_sid.Text)
                        Sql_Command.Parameters.AddWithValue("@mg_name", sfc.Left(tb_mg_name.Text, 12))
                        Sql_Command.Parameters.AddWithValue("@mg_nike", sfc.Left(tb_mg_nike.Text, 12))
                        Sql_Command.Parameters.AddWithValue("@mg_id", sfc.Left(tb_mg_id.Text, 12))
                        Sql_Command.Parameters.AddWithValue("@mg_unit", sfc.Left(tb_mg_unit.Text, 50))
                        Sql_Command.Parameters.AddWithValue("@mg_desc", sfc.Left(tb_mg_desc.Text, 1000))
                        Sql_Command.Parameters.AddWithValue("@is_pda_user", IIf(Left(ddlPDA.Text, 1) = "Y", "1", "0"))
                        Sql_Command.Parameters.AddWithValue("@is_active", IIf(Left(ddlIsActive.Text, 1) = "Y", "1", "0"))

                        Sql_Command.Parameters.Add("@getdate", SqlDbType.DateTime)
                        Sql_Command.Parameters("@getdate").Value = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID")))

                        Sql_Command.ExecuteNonQuery()



                    End Using

                    If txtPass.Text.Trim <> "" Then

                        Dim sRndStr As String
                        sRndStr = GenRandStr(4)


                        SqlString = "Update Manager Set [mg_pass] = @mg_pass"
                        SqlString &= " Where mg_sid = @mg_sid"
                        Using Sql_Command As New SqlCommand(SqlString, Sql_conn)
                            Sql_Command.Parameters.Clear()
                            Sql_Command.Parameters.AddWithValue("@mg_pass", sRndStr & EncodePass(sfc.Left(txtPass.Text, 12)))
                            Sql_Command.Parameters.AddWithValue("@mg_sid", lb_pg_mg_sid.Text)
                            Sql_Command.ExecuteNonQuery()
                        End Using
                    End If

                End If
            End Using
        End If


        If mErr = "" Then
            mErr = "alert('Edit Completed!\n');location.replace('" & Request("curr") & lb_page.Text & " ');"
        Else
            mErr = "alert('" & mErr & "')"
        End If

        lt_show.Text = "<script language=javascript>" & mErr & "</script>"
    End Sub

    Protected Sub back_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles back.Click
        Server.Transfer(Request("curr"))
    End Sub


    Public Function GenRandStr(ByRef iLength As Integer) As String
        Dim rdm As New Random()
        Dim allowChrs() As Char = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLOMNOPQRSTUVWXYZ0123456789".ToCharArray()
        Dim sResult As String = ""

        For i As Integer = 0 To iLength - 1
            sResult += allowChrs(rdm.Next(0, allowChrs.Length))
        Next

        Return sResult
    End Function


    '// Use new encode logic 
    Function EncodePass(ByVal password As String) As String
        Dim Data() As Byte
        Dim EnStr As String
        ' // Encode 
        Data = System.Text.ASCIIEncoding.ASCII.GetBytes(password)
        EnStr = System.Convert.ToBase64String(Data)
        Return EnStr

    End Function


End Class