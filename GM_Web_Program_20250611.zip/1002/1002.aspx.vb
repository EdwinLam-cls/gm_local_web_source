﻿'---------------------------------------------------------------------------- 
'程式功能	人員資料管理 
'---------------------------------------------------------------------------- 
Imports System
Imports System.Collections.Generic
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls

Partial Public Class _1002
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim ckbtime As DateTime, cketime As DateTime

            ' 檢查使用者權限並存入登入紀錄。 
            Check_Power("1002", True)

            '接受下一頁返回時的舊查詢條件" 
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid"), ckint) Then
                    gv_Manager.PageIndex = ckint
                Else
                    lb_pageid.Text = "0"
                End If
            End If
        End If

    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub gv_Manager_PageIndexChanged(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        lb_pageid.Text = e.NewPageIndex()
    End Sub

    Protected Sub gv_Manager_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gv_Manager.PageIndexChanging
        Chk_Filter()
    End Sub

    Protected Sub gv_Manager_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gv_Manager.Sorting
        Chk_Filter()
    End Sub

    Protected Sub Btn_Set_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' 檢查查詢條件是否改變 
        Chk_Filter()
    End Sub

    ' 檢查查詢條件是否改變 
    Private Sub Chk_Filter()
        Dim cfc As New Common_Func()

        Dim ckint As Integer = 0
        Dim ckbtime As DateTime, cketime As DateTime
        Dim tmpstr As String = ""

        Dim strMg_sid = cfc.CleanSQL(txtMg_sid.Text.Trim)
        Try
            Dim intTest As Integer = CInt(strMg_sid)
        Catch
            strMg_sid = ""
        End Try

        Dim strFrom = cfc.CleanSQL(txtFrom.Text.Trim)
        Try
            strFrom = CDate(strFrom).ToString("yyyy-MM-dd")
        Catch
            strFrom = ""
        End Try

        Dim strTo = cfc.CleanSQL(txtTo.Text.Trim)
        Try
            strTo = CDate(strTo).ToString("yyyy-MM-dd")
        Catch
            strTo = ""
        End Try

        Dim strFullName = cfc.CleanSQL(txtFullName.Text.Trim)
        Dim strUserRight = cfc.CleanSQL(txtUserRight.Text.Trim)
        Dim strDesc = cfc.CleanSQL(txtDesc.Text.Trim)
        Dim strSql As String = "SELECT [mg_sid], [mg_name], [mg_nike], case when [mg_unit] = 'N' then 'Normal' when [mg_unit] = 'S' then 'Supervisor' end as mg_unit, [mg_desc], [mg_id], [mg_pass], [last_date],[init_time] FROM manager"
        strSql += " where 1=1 "

        If strMg_sid <> "" Then
            strSql += " and Mg_sid = '" & strMg_sid & "'"
        End If
        If strFullName <> "" Then
            strSql += " and mg_name like '%" & strFullName & "%'"
        End If
        If strUserRight <> "" Then
            strSql += " and mg_unit like '%" & strUserRight & "%'"
        End If
        If strDesc <> "" Then
            strSql += " and mg_desc like '%" & strDesc & "%'"
        End If

        If strFrom <> "" Then
            strSql += " and convert(varchar(10),[last_date],120) >= '" & strFrom & "'"
        End If

        If strTo <> "" Then
            strSql += " and convert(varchar(10),[last_date],120) <= '" & strTo & "'"
        End If

        If strDesc <> "" Then
            strSql += " and mg_desc like '%" & strDesc & "%'"
        End If

        dsManager.SelectCommand = strSql

        gv_Manager.DataBind()
        If gv_Manager.PageCount - 1 < gv_Manager.PageIndex Then
            gv_Manager.PageIndex = gv_Manager.PageCount
            gv_Manager.DataBind()
        End If

        lb_pageid.Text = gv_Manager.PageIndex.ToString()
    End Sub

    Protected Sub gv_Manager_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs) Handles gv_Manager.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim btnView As Button = DirectCast(e.Row.FindControl("btnView"), Button)
            Dim intMg_sid As Integer = CInt(e.Row.Cells(0).Text)
            'btnView.OnClientClick = String.Format("Javascript: alert('adf');location.replace('3001/3001.aspx?{0}');", intMg_sid)
            btnView.ToolTip = intMg_sid
        End If

    End Sub

    Public Sub btnView_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim intMg_sid As Integer = CType(sender, Button).ToolTip
        Response.Redirect(String.Format("1002_view.aspx?pageid={0}&mg_sid={1}", lb_pageid.Text, intMg_sid), False)
    End Sub

    Protected Sub txtUserRight_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtUserRight.SelectedIndexChanged
        Chk_Filter()
    End Sub

End Class