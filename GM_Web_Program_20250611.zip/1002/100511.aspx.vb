﻿'---------------------------------------------------------------------------- 
'程式功能	人員資料管理 > 明細內容 > 設定權限
'---------------------------------------------------------------------------- 

Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration
Imports System.Web.UI.WebControls

Partial Public Class _100511
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
		Dim mg_sid As Integer = -1
		Dim SqlString As String = "", mErr As String = ""

		If Not IsPostBack Then
			Dim ckint As Integer = 0

			' 檢查使用者權限但不存入登入紀錄 
			Check_Power("1005", False)

			' 承接上一頁的查詢條件設定
			If Request("pageid") IsNot Nothing Then
				If Integer.TryParse(Request("pageid").ToString(), ckint) Then
					lb_page.Text = "?pageid=" & ckint.ToString()
				Else
					lb_page.Text = "?pageid=0"
				End If
			End If

			If Request("mg_sid") IsNot Nothing Then
				lb_page.Text &= "&mg_sid=" & Request("mg_sid")
			End If

			If Request("mg_name") IsNot Nothing Then
				lb_page.Text &= "&mg_name=" & Server.UrlEncode(Request("mg_name"))
			End If

			If Request("mg_nike") IsNot Nothing Then
				lb_page.Text &= "&mg_nike=" & Server.UrlEncode(Request("mg_nike"))
			End If

			If Request("btime") IsNot Nothing Then
				lb_page.Text &= "&btime=" & Server.UrlEncode(Request("btime"))
			End If

			If Request("etime") IsNot Nothing Then
				lb_page.Text &= "&etime=" & Server.UrlEncode(Request("etime"))
			End If

			' 檢查傳入參數
			If Request("sid") IsNot Nothing Then
				' 取得相關資料
				If Integer.TryParse(Request("sid").ToString(), mg_sid) Then
					lb_page.Text &= "&sid=" & mg_sid.ToString()

					Using sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
						sql_conn.Open()

						' 取得人員基本資料
						SqlString = "Select Top 1 mg_sid, mg_name, mg_nike, mg_id From Manager Where mg_sid = " & mg_sid.ToString()

						Using Sql_Command As New SqlCommand(SqlString, sql_conn)
							Using Sql_Reader As SqlDataReader = Sql_Command.ExecuteReader()
								If Sql_Reader.Read() Then
									lb_mg_sid.Text = Sql_Reader("mg_sid").ToString()
									lb_mg_id.Text = Sql_Reader("mg_id").ToString()
									lb_mg_name.Text = Sql_Reader("mg_name").ToString().Trim()
									lb_mg_nike.Text = Sql_Reader("mg_nike").ToString().Trim()

									lb_pg_mg_sid.Text = mg_sid.ToString()

									sqs_Func_Power.SelectParameters("mg_sid").DefaultValue = Sql_Reader("mg_sid").ToString()
									gv_Func_Power.DataBind()
								Else
									mErr = "找不到指定的人員資料!\n"
								End If
							End Using
						End Using
					End Using
				Else
					mErr = "網頁參數傳送錯誤!\n"
				End If
			Else
				mErr = "網頁參數傳送錯誤!\n"
			End If

			If mErr <> "" Then
				lt_show.Text = "<script language='javascript'>alert('" & mErr & "');history.go(-1);</script>"
			End If
		End If
	End Sub

	' Check_Power() 檢查使用者權限並存入登入紀錄 
	Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
		' 載入公用函數 
		Dim cfc As New Common_Func()

		' 若 Session 不存在則直接顯示錯誤訊息 
		Try
			If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
				Response.Redirect("../Error.aspx?ErrCode=1")
			End If
		Catch
			Response.Redirect("../Error.aspx?ErrCode=2")
		End Try
	End Sub

	Protected Sub gv_Func_Power_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs)
		If (e.Row.RowType = DataControlRowType.DataRow) Then
			Dim DataRV As DataRowView = DirectCast(e.Row.DataItem, DataRowView)

			Dim rb_en As RadioButton = DirectCast(e.Row.Cells(2).FindControl("rb_open"), RadioButton)
			Dim rb_di As RadioButton = DirectCast(e.Row.Cells(2).FindControl("rb_close"), RadioButton)
			Dim lb_fi_no1 As Label = DirectCast(e.Row.Cells(2).FindControl("lb_fi_no1"), Label)
			Dim lb_fi_no2 As Label = DirectCast(e.Row.Cells(2).FindControl("lb_fi_no2"), Label)

			' 將主功能代碼及子功能代碼存入隱藏的 Label 控制項， 
			' 因為 DataItem 在 RowDataBound 事件之後，不會被保存。 
			lb_fi_no1.Text = DataRV("fi_no1").ToString()
			lb_fi_no2.Text = DataRV("fi_no2").ToString()

			Select Case lb_enable.Text
				Case "0"
					' 狀態為「全部禁止」 
					rb_en.Checked = False
					rb_di.Checked = True
					Exit Select
				Case "1"
					' 狀態為「全部開放」 
					rb_en.Checked = True
					rb_di.Checked = False
					Exit Select
				Case Else
					' 狀態為「自訂」 
					If DataRV("is_enable").ToString() = "0" Then
						rb_en.Checked = False
						rb_di.Checked = True
					Else
						rb_en.Checked = True
						rb_di.Checked = False
					End If
					Exit Select
			End Select
		End If
	End Sub

	' 「確定儲存」按鈕的 Click 事件處理常式。 
	Protected Sub lb_ok_Click(ByVal sender As Object, ByVal e As EventArgs)
		Dim SqlString As String = ""
		Dim fi_no1 As String = "", fi_no2 As String = ""
		Dim Sql_Command As New SqlCommand()

		Using sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
			sql_conn.Open()

			' 先清除該位人員所有的權限，然後再重新新增。 
			SqlString = "Delete Func_Power Where mg_sid = @mg_sid"

			Sql_Command.Connection = sql_conn
			Sql_Command.CommandText = SqlString
			Sql_Command.Parameters.AddWithValue("mg_sid", lb_pg_mg_sid.Text)

			Sql_Command.ExecuteNonQuery()

			Sql_Command.Dispose()

			' 處理 GridView 裡面的每一筆資料是否賦予使用權限
			For Each row As GridViewRow In gv_Func_Power.Rows
				If row.RowType = DataControlRowType.DataRow Then
					Dim rb_en As RadioButton = DirectCast(row.FindControl("rb_open"), RadioButton)

					' 有「開放」權限時，才要存入資料庫。 
					If rb_en.Checked Then
						Dim lb_fi_no1 As Label = DirectCast(row.FindControl("lb_fi_no1"), Label)
						Dim lb_fi_no2 As Label = DirectCast(row.FindControl("lb_fi_no2"), Label)

						fi_no1 = lb_fi_no1.Text
						fi_no2 = lb_fi_no2.Text

						SqlString = "Insert Into Func_Power (mg_sid, fi_no1, fi_no2, is_enable)"
						SqlString &= " Values (@mg_sid, @fi_no1, @fi_no2, 1);"

						Sql_Command.Parameters.Clear()
						Sql_Command.CommandText = SqlString
						Sql_Command.Parameters.AddWithValue("mg_sid", lb_pg_mg_sid.Text)
						Sql_Command.Parameters.AddWithValue("fi_no1", fi_no1)
						Sql_Command.Parameters.AddWithValue("fi_no2", fi_no2)

						Sql_Command.ExecuteNonQuery()

						Sql_Command.Dispose()
					End If
				End If
			Next
		End Using

        lt_show.Text = "<script language=javascript>alert('權限設定完成！');location.replace('10051_view.aspx?" & lb_page.Text & "');</script>"
	End Sub

	Protected Sub bn_all_open_Click(ByVal sender As Object, ByVal e As EventArgs)
		' 狀態設為「全部開放」 
		lb_enable.Text = "1"
		gv_Func_Power.DataBind()
	End Sub

	Protected Sub bn_all_close_Click(ByVal sender As Object, ByVal e As EventArgs)
		' 狀態設為「全部禁止」 
		lb_enable.Text = "0"
		gv_Func_Power.DataBind()
	End Sub

	Protected Sub rb_open_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs)
		' 狀態設為「自訂」 
		lb_enable.Text = "2"
	End Sub

	Protected Sub rb_close_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs)
		' 狀態設為「自訂」 
		lb_enable.Text = "2"
	End Sub
End Class