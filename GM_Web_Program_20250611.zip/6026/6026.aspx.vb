﻿Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Configuration
Imports System.Data.Common

Partial Class _6026_6026

    Inherits System.Web.UI.Page

    Dim gErr As String = ""


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim tmpstr As String = ""

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("6026", True)
            mg_name.value = Session("mg_name").ToString
        End If

        'Dim xVal() As String = {"1", "2", "3"}
        'Dim yval() As Double = {12, 34, 45}

        'Chart1.Series("Series1").Points.DataBindXY(xVal, yval)

        'System.Diagnostics.Debug.WriteLine(SqlMainSource.SelectCommand)

        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""

    End Sub


    ' Check_Power() 檢查使用者權限並存入登入紀錄
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub
    Protected Sub btn_search_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_search.Click
        Chk_Filter()
    End Sub

    Private Sub Chk_Filter()

    

        Dim myDataTable As DataTable = New DataTable()
        'Dim myDataSet As New DataSet

        Dim Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Sql_conn.Open()

        Dim SqlString As String = "rpt_PO_Completeness"



        Dim Sql_Command As New SqlCommand(SqlString, Sql_conn)
        Sql_Command.CommandType = CommandType.StoredProcedure
        Sql_Command.Parameters.Add("@startdate", SqlDbType.NVarChar, 100)
        Sql_Command.Parameters.Add("@enddate", SqlDbType.NVarChar, 100)

        Sql_Command.Parameters("@startdate").Value = tb_fr_date.Text
        Sql_Command.Parameters("@enddate").Value = tb_to_date.Text

        Dim reader As SqlDataReader = Sql_Command.ExecuteReader()
        ViewState("myDataTable") = myDataTable
        myDataTable.Load(reader)
        Sql_Command.Dispose()
        Sql_conn.Close()


        gv_txn_detail.DataSource = myDataTable
        gv_txn_detail.DataBind()
        If gv_txn_detail.PageCount - 1 < gv_txn_detail.PageIndex Then
            gv_txn_detail.PageIndex = gv_txn_detail.PageCount
            gv_txn_detail.DataBind()
        End If





    End Sub

    Protected Sub gv_txn_detail_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gv_txn_detail.Sorting
        Dim dt As DataTable = ViewState("myDataTable")
        Dim dv As DataView = dt.DefaultView
        dv.Sort = e.SortExpression + " " + ConvertSortDirectionToSql(e.SortDirection)
        gv_txn_detail.DataSource = dv
        ViewState("myDataTable") = dv.ToTable
        gv_txn_detail.DataBind()

    End Sub

    Private Function ConvertSortDirectionToSql(ByVal sortDirect As SortDirection) As String

        If ViewState("orderBy") = "ASC" Then
            ViewState("orderBy") = "DESC"
            Return "DESC"
        Else
            ViewState("orderBy") = "ASC"
            Return "ASC"
        End If
        Return 0
    End Function




    Protected Sub gv_txn_detail_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gv_txn_detail.PageIndexChanging
        gv_txn_detail.PageIndex = e.NewPageIndex
        gv_txn_detail.DataSource = ViewState("myDataTable")
        gv_txn_detail.DataBind()


    End Sub



End Class
