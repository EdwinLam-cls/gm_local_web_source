﻿Imports System.Data
Imports Common_Func
Imports System.Data.SqlClient


Partial Class _9999_9999
    Inherits System.Web.UI.Page

    Dim gErr As String = ""



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()
            Dim tmpstr As String = ""

            ' 檢查使用者權限並存入登入紀錄
            Check_Power("9999", True)

        End If

        If gErr = "" Then
            lt_show.Text = ""
        End If
        gErr = ""


    End Sub

    ' Check_Power() 檢查使用者權限並存入登入紀錄
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息
        Try
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub btn_Search_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Search.Click
        Dim strSql As String = getStrSql()
        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()
    End Sub


    Protected Sub gv_custmaster_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gv_custmaster.PageIndexChanging
        Dim strSql As String = getStrSql()
        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()
    End Sub

    Protected Sub gv_custmaster_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles gv_custmaster.Sorting
        Dim strSql As String = getStrSql()
        dsGridView.SelectCommand = strSql
        gv_custmaster.DataBind()
    End Sub

    Private Function getStrSql() As String

        txtDatetime.Text = Now
        Dim strSql As String

        Try
            Using Sql_Conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                Using Sql_Command As New SqlCommand()
                    Sql_Command.Connection = Sql_Conn
                    Sql_Conn.Open()
                    Sql_Command.CommandType = CommandType.StoredProcedure
                    Sql_Command.CommandText = "sp_pda_emailalert"
                    Sql_Command.ExecuteNonQuery()
                End Using
            End Using

        Catch ex As Exception
            ex.ToString()
        End Try

        strSql = "select * from Sys_emailalert"
        Return strSql
    End Function


End Class
