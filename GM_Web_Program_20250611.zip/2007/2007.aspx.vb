﻿'---------------------------------------------------------------------------- 
'程式功能	ITEM Master Maintenance
'---------------------------------------------------------------------------- 
Imports System
Imports System.Collections.Generic
Imports System.Web
Imports System.Web.UI
Imports System.Data.SqlClient
Imports System.Web.UI.WebControls

Partial Class _2007
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ckint As Integer = 0
            Dim cfc As New Common_Func()

            ' 檢查使用者權限並存入登入紀錄。 
            Check_Power("2007", True)

            '接受下一頁返回時的舊查詢條件" 
            If Request("pageid") IsNot Nothing Then
                If Integer.TryParse(Request("pageid"), ckint) Then
                    gv_itemmaster.PageIndex = ckint
                Else
                    lb_pageid.Text = "0"
                End If
            End If

            If Request("stk_code") IsNot Nothing Then
                If Integer.TryParse(Request("stk_code"), ckint) Then
                    tb_stk_code.Text = ckint.ToString()

                End If
            End If

            If Request("stk_desc") IsNot Nothing Then
                tb_stk_desc.Text = cfc.CleanSQL(Request("stk_desc"))

            End If
        End If
    End Sub

    Private Property updateMode() As String
        Get
            Return ViewState("updateMode")
        End Get
        Set(ByVal value As String)
            ViewState("updateMode") = value
        End Set
    End Property

    ' Check_Power() 檢查使用者權限並存入登入紀錄 
    Private Sub Check_Power(ByVal f_power As String, ByVal bl_save As Boolean)
        ' 載入公用函數 
        Dim cfc As New Common_Func()

        ' 若 Session 不存在則直接顯示錯誤訊息 
        Try
            'If cfc.Check_Power(Session("stk_code").ToString(), Session("stk_desc").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
            If cfc.Check_Power(Session("mg_sid").ToString(), Session("mg_name").ToString(), Session("mg_power").ToString(), f_power, Request.ServerVariables("REMOTE_ADDR"), bl_save) > 0 Then
                Response.Redirect("../Error.aspx?ErrCode=1")
            End If
        Catch
            Response.Redirect("../Error.aspx?ErrCode=2")
        End Try
    End Sub

    Protected Sub gv_itemmaster_PageIndexChanged(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        lb_pageid.Text = e.NewPageIndex()
    End Sub

    Protected Sub Btn_Set_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Btn_Set.Click
        ' 檢查查詢條件是否改變 
        Chk_Filter()
    End Sub

    ' 檢查查詢條件是否改變 
    Private Sub Chk_Filter()
        Dim cfc As New Common_Func()

        Dim ckint As Integer = 0
        Dim tmpstr As String = ""


        Dim strSearchMaterialCode = cfc.CleanSQL(tb_stk_code.Text.Trim)
        Dim strSearchEngDesc = cfc.CleanSQL(tb_stk_desc.Text.Trim)
        Dim strSearchChiDesc = cfc.CleanSQL(txtDescChi.Text.Trim)
        Dim strSearchGroup = cfc.CleanSQL(ddlGroup.Text.Trim)
        Dim strSql As String = "SELECT b.materialGroupCode, b.chiDesc as gChiDesc, materialCode, a.engDesc, a.chiDesc, salesUnit,  ISNULL(b.engDesc, 'Others') 'materialDesc' ,block FROM item_master a inner JOIN item_group_master b ON a.materialGroupCode = b.materialGroupCode"
        strSql += " where 1=1 "
        If strSearchMaterialCode <> "" Then strSql += " and materialCode like '%" & strSearchMaterialCode & "%'"
        If strSearchEngDesc <> "" Then strSql += " and a.engDesc like '%" & strSearchEngDesc & "%'"
        If strSearchChiDesc <> "" Then strSql += " and a.chiDesc like '%" & strSearchChiDesc & "%'"
        If strSearchGroup <> "" Then strSql += " and b.chiDesc = '" & strSearchGroup & "'"
        dsMaterial.SelectCommand = strSql


        gv_itemmaster.DataBind()
        If gv_itemmaster.PageCount - 1 < gv_itemmaster.PageIndex Then
            gv_itemmaster.PageIndex = gv_itemmaster.PageCount
            gv_itemmaster.DataBind()
        End If

        lb_pageid.Text = gv_itemmaster.PageIndex.ToString()
    End Sub


    Protected Sub GridView1_RowCommand(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)

        If e.CommandName = "Update" Then
            Dim txtUpdate As TextBox = DirectCast(gv_itemmaster.Rows(e.CommandArgument).Controls(7).Controls(0), TextBox)
            Dim strmaterialDescChi As String = txtUpdate.Text
            Dim strmaterialGroup As String = gv_itemmaster.Rows(e.CommandArgument).Cells(0).Text


            If strmaterialDescChi.Trim <> "" Then
                dsMaterial.UpdateCommand = "UPDATE item_master SET block = '1' where materialCode = @materialCode"
            Else
                dsMaterial.UpdateCommand = "UPDATE item_master SET block = '' where materialCode = @materialCode"
            End If
        End If
        If e.CommandName = "Edit" Then
            updateMode = "Update"
        Else
            updateMode = ""
        End If
        Chk_Filter()
    End Sub

    Protected Sub ddlGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlGroup.SelectedIndexChanged
        Chk_Filter()
        Dim str As String = ddlGroup.Text.Trim
        If str <> "" Then
            btnBlock.Visible = True
            btnUnblock.Visible = True
        Else
            btnBlock.Visible = False
            btnUnblock.Visible = False
        End If
    End Sub

    Protected Sub btnBlock_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBlock.Click
        If ddlGroup.Text.Trim = "" Then
            ClientScript.RegisterStartupScript(Me.GetType(), "errorScript", "alert('" & "Please select an item group" & "');", True)
            Exit Sub
        End If
        Try
            Using Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                Dim SqlString As String = ""
                SqlString = "  update item_master set block = '1' from item_master i inner join item_group_master g on i.materialGroupCode = g.materialGroupCode where g.chiDesc ='" & ddlGroup.Text & "'"
                Using Sql_Command As New SqlCommand()
                    Sql_Command.Connection = Sql_conn
                    Sql_Command.CommandText = SqlString
                    Sql_conn.Open()
                    Sql_Command.ExecuteNonQuery()
                    Sql_conn.Close()
                End Using
            End Using
            ClientScript.RegisterStartupScript(Me.GetType(), "errorScript", "alert('" & "Block Success!" & "');", True)
        Catch
            ClientScript.RegisterStartupScript(Me.GetType(), "errorScript", "alert('" & "Connection Error!" & "');", True)
        End Try

        Chk_Filter()
    End Sub

    Protected Sub btnUnBlock_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUnblock.Click
        If ddlGroup.Text.Trim = "" Then
            ClientScript.RegisterStartupScript(Me.GetType(), "errorScript", "alert('" & "Please select an item group" & "');", True)
            Exit Sub
        End If
        Try
            Using Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                Dim SqlString As String = ""
                SqlString = "  update item_master set block = '' from item_master i inner join item_group_master g on i.materialGroupCode = g.materialGroupCode where g.chiDesc ='" & ddlGroup.Text & "'"
                Using Sql_Command As New SqlCommand()
                    Sql_Command.Connection = Sql_conn
                    Sql_Command.CommandText = SqlString
                    Sql_conn.Open()
                    Sql_Command.ExecuteNonQuery()
                    Sql_conn.Close()
                End Using
            End Using
            ClientScript.RegisterStartupScript(Me.GetType(), "errorScript", "alert('" & "Unblock Success!" & "');", True)
        Catch
            ClientScript.RegisterStartupScript(Me.GetType(), "errorScript", "alert('" & "Connection Error!" & "');", True)
        End Try

        Chk_Filter()
    End Sub
End Class
