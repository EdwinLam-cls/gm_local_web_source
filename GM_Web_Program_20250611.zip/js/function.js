﻿function selectAllRows(tableID, columnIndex) {
    var chkAll = window.event.srcElement;
    var tbl = document.all(tableID);

    for (var i = 1; i < tbl.rows.length; i++) {
        try {
            var inputs = tbl.rows[i].cells[columnIndex].getElementsByTagName('INPUT');

            for (var c = 0; c < inputs.length; c++) {
                if (inputs[c].checked != chkAll.checked && inputs[c].type == "checkbox") {
                    inputs[c].checked = chkAll.checked;
                }
            }
        }
        catch (e) { }
    }
}