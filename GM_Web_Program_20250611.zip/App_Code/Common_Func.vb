﻿'---------------------------------------------------------------------------- 
'程式功能	公用函數 
'設計人員	 
'修改人員 
'備註說明 
'---------------------------------------------------------------------------- 
Imports System.Data.SqlClient
Imports System.Text
Imports System.Web
Imports System.Web.Configuration
Imports System.Data

Public Class Common_Func
	' Check_ID() 檢查帳號密碼，儲存紀錄，傳回權限 
	' 傳入參數 mg_id 使用者帳號 
	' mg_pass 登入密碼 
	' ip_addr 使用者 IP 
	' 傳回數值 *開頭 *錯誤訊息 
	' 其它 管理者編號；管理者姓名；權限字串 
	Public Function Check_ID(ByVal mg_id As String, ByVal mg_pass As String, ByVal ip_addr As String) As String
		Dim SqlString As String = ""
		Dim mCheck As String = "", mErr As String = "", mg_sid As String = "", mg_name As String = ""
        Dim mg_power As New StringBuilder()
        ''gmi commented out, don't need decoder since we are not validating password
        'Dim dcode As New Decoder()

		' 取得使用者資料 
        Using Sql_Conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
            'Using Sql_Conn As New SqlConnection(WebConfigurationManager.ConnectionStrings("AppSysConnectionString").ConnectionString)
            SqlString = "Select Top 1 mg_sid, mg_name, mg_id, mg_pass From Manager Where mg_id = @mg_id"
            Sql_Conn.Open()
            Using Sql_Command As New SqlCommand()
                Dim Sql_Reader As SqlDataReader

                Sql_Command.Connection = Sql_Conn
                Sql_Command.CommandText = SqlString

                Sql_Command.Parameters.AddWithValue("@mg_id", mg_id)

                Sql_Reader = Sql_Command.ExecuteReader()
                'GMI Automatically Insert Admins
                If (Not Sql_Reader.HasRows) And System.Web.HttpContext.Current.User.IsInRole(ApplicationConfig.Instance().adminsGroup) Then
                    CreateAdminAccount()
                    Sql_Reader.Close()
                    Sql_Reader = Sql_Command.ExecuteReader()
                End If
                If Sql_Reader.Read() Then
                    ' 再次確認帳號及密碼，以防有人使用 SQL 隱碼攻擊侵入 
                    If Sql_Reader("mg_id").ToString().Trim() = mg_id Then

                        ' 密碼欄位需解密後再行核對 
                        ''gmi commmented out if.  we aren't validating passwords
                        'If mg_pass = dcode.DeCode(Sql_Reader("mg_pass").ToString().Trim()) Then
                        ' 建立 Session 
                        mg_sid = Sql_Reader("mg_sid").ToString().Trim()
                        mg_name = Sql_Reader("mg_name").ToString().Trim()
                        Sql_Command.Dispose()
                        Sql_Reader.Close()
                        Sql_Reader.Dispose()

                        ' 取得執行權限，置入 mg_power 
                        ' 清除 SqlString 字串 
                        SqlString.Remove(0, SqlString.Length)

                        If mg_sid.ToString() = "1" Then
                            ' 若為系統總管理者，擁有全部的功能執行權限 
                            SqlString = "Select fi_no2 From Func_Item2 Where is_visible <> 0"
                        ElseIf System.Web.HttpContext.Current.User.IsInRole(ApplicationConfig.Instance().adminsGroup) Then
                            SqlString = "Select fi_no2 From Func_Power Where mg_sid = @mg_sid And is_enable = 1"
                            SqlString &= " Union "
                            SqlString &= "Select fi_no2 From Func_Item2 Where is_visible <> 0"
                        Else
                            ' 一般使用者，由人員系統權限 Func_Power 資料表取得可執行的權限，以及系統管理用的功能 
                            SqlString = "Select fi_no2 From Func_Power Where mg_sid = @mg_sid And is_enable = 1"
                            SqlString &= " Union "
                            SqlString &= "Select fi_no2 From Func_Item2 Where is_visible = 2"
                        End If

                        ' 取得權限，並填入 mg_power 
                        Sql_Command.Connection = Sql_Conn
                        Sql_Command.CommandText = SqlString
                        Sql_Command.Parameters.AddWithValue("@mg_sid", mg_sid)
                        Sql_Reader = Sql_Command.ExecuteReader()
                        While Sql_Reader.Read()
                            mg_power.Append(Sql_Reader("fi_no2").ToString() & ";")
                        End While
                        Sql_Command.Dispose()
                        Sql_Reader.Close()

                        If mg_power.ToString() = "" Then
                            mErr = "沒有任何的執行權限，請用其它帳號重新登入!\n"
                        Else
                            ' 存入使用者登入紀錄，並更新最後更新紀錄 
                            SqlString = "Insert Into Mg_Log (mg_sid, fi_no2, lg_time, lg_ip) Values"
                            SqlString &= " (@mg_sid, '0001', @getdate, @lg_ip);"
                            SqlString &= "Update Manager Set last_date = @getdate Where mg_sid = @mg_sid"

                            Sql_Command.Parameters.Clear()
                            Sql_Command.Connection = Sql_Conn
                            Sql_Command.CommandText = SqlString
                            Sql_Command.Parameters.AddWithValue("@mg_sid", mg_sid)
                            Sql_Command.Parameters.AddWithValue("@lg_ip", ip_addr)
                            Sql_Command.Parameters.Add("@getdate", SqlDbType.DateTime)
                            Sql_Command.Parameters("@getdate").Value = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID")))

                            Sql_Command.ExecuteNonQuery()

                            ' 刪除一年前所有使用者的登入資料 
                            SqlString = "Delete Mg_Log Where lg_time < DateAdd(yy, -1,@getdate)"
                            Sql_Command.Parameters.Clear()
                            Sql_Command.Connection = Sql_Conn
                            Sql_Command.CommandText = SqlString
                            Sql_Command.Parameters.AddWithValue("@mg_sid", mg_sid)
                            Sql_Command.Parameters.Add("@getdate", SqlDbType.DateTime)
                            Sql_Command.Parameters("@getdate").Value = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID")))

                            Sql_Command.ExecuteNonQuery()
                        End If
                        ''gmi commented out 
                        'Else
                        '    mErr = "帳號、密碼有誤!\n"
                        '    ' 不想讓使用者清楚知道是密碼錯誤，所以帳號、密碼兩者都寫 
                        'End If
                    Else
                        mErr = "請使用正確的方式登入!\n"
                    End If

                    Sql_Command.Dispose()
                    Sql_Reader.Close()
                    Sql_Reader.Dispose()
                Else
                    mErr = "帳號、密碼有誤!\n"
                End If
            End Using
        End Using

        If mErr = "" Then
            ' 以 \t\n 為間隔 
            mCheck = mg_sid & vbTab & vbLf & mg_name & vbTab & vbLf & mg_power.ToString()
        Else
            mCheck = "*" & mErr
        End If

        Return mCheck
    End Function

    ' Check_Power() 檢查權限並存檔 
    ' 輸入參數 mg_sid 管理者代碼 
    ' mg_name 管理者姓名 
    ' mg_power 權限字串 
    ' f_power 現行程權限代碼 
    ' bl_save 是否要存入使用紀錄 
    ' 傳回數值 0 正確 
    ' -1 不明原因錯誤 
    ' -2 登入資料錯誤 (不正常的方式進入) 
    ' -3 無指定功能的使用權限 
    Public Function Check_Power(ByVal mg_sid As String, ByVal mg_name As String, ByVal mg_power As String, ByVal f_power As String, ByVal lg_ip As String, ByVal bl_save As Boolean) As Integer
        Dim sfc As New String_Func()
        Dim mfg As Integer = -1
        Dim SqlString As String = ""
        Dim Sql_Conn As SqlConnection
        Dim Sql_Command As SqlCommand

        If sfc.IsInteger(mg_sid) Then
            If mg_name = "" Then
                mfg = -2
            Else
                If mg_power.Contains(f_power) Then
                    mfg = 0
                Else
                    mfg = -3
                End If
            End If
        Else
            mfg = -2
        End If

        ' 存入使用記錄 
        If mfg = 0 AndAlso bl_save Then
            SqlString = "Insert Into Mg_Log (mg_sid, fi_no2, lg_time, lg_ip) Values"
            SqlString &= " (@mg_sid, @fi_no2, @getdate, @lg_ip)"

            Sql_Conn = New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
            Sql_Conn.Open()
            Sql_Command = New SqlCommand(SqlString, Sql_Conn)
            Sql_Command.Parameters.AddWithValue("@mg_sid", mg_sid)
            Sql_Command.Parameters.AddWithValue("@fi_no2", f_power)
            Sql_Command.Parameters.AddWithValue("@lg_ip", lg_ip)
            Sql_Command.Parameters.Add("@getdate", SqlDbType.DateTime)
            Sql_Command.Parameters("@getdate").Value = TimeZoneInfo.ConvertTime(Now, TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings("TimeZoneID")))


            Sql_Command.ExecuteNonQuery()

            Sql_Command.Dispose()
            Sql_Conn.Close()
        End If

        Return mfg
    End Function

    ' CleanSQL() 清除字串中有 SQL 隱碼攻擊的字串 「'」「 」「;」「--」 「|」「\t」「\n」 
    Public Function CleanSQL(ByVal mString As String) As String
        If mString Is Nothing Then
            mString = ""
        Else
            mString = mString.Replace("'", "''")
            mString = mString.Replace(";", "")
            mString = mString.Replace("--", "")
            mString = mString.Replace("|", "")
            mString = mString.Replace(vbTab, "")
            mString = mString.Replace(vbLf, "")
        End If
        Return mString
    End Function

    ' CheckSQL() 檢查字串中有 SQL 隱碼攻擊的字串 「'」「;」「--」「|」「\t」「\n」 
    Public Function CheckSQL(ByVal mString As String) As Boolean
        Dim mfg As Boolean = False

        If mString Is Nothing Then
            mfg = True
        Else
            'mfg = (mString.Contains("'") OrElse mString.Contains(" ") OrElse mString.Contains(";") OrElse mString.Contains("--") OrElse mString.Contains("|") OrElse mString.Contains(vbTab) OrElse mString.Contains(vbLf))
            mfg = (mString.Contains("'") OrElse mString.Contains(";") OrElse mString.Contains("--") OrElse mString.Contains("|") OrElse mString.Contains(vbTab) OrElse mString.Contains(vbLf))
        End If

        Return mfg
    End Function

    Public Shared Function ExeSQLGetDataTable(ByVal SQLString As String) As DataTable
        Dim returnTable As DataTable = New DataTable

        Using sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
            sql_conn.Open()

            Using Sql_Command As New SqlCommand(SQLString, sql_conn)
                Using Sql_Reader As SqlDataReader = Sql_Command.ExecuteReader()
                    returnTable.Load(Sql_Reader)
                    Sql_Reader.Close()
                End Using
                Sql_Command.Dispose()
            End Using
            sql_conn.Close()
        End Using

        Return returnTable
    End Function

    Public Shared Sub CreateAdminAccount()
        If System.Web.HttpContext.Current.User.IsInRole(ApplicationConfig.Instance().adminsGroup) Then
            Using Sql_conn As New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
                Dim SqlString As String = ""
                Dim decoder As New Decoder()
                Dim tran As SqlClient.SqlTransaction
                Dim mg_sid As Integer
                Sql_conn.Open()
                tran = Sql_conn.BeginTransaction


                ' 建立 SQL 的語法 
                SqlString = "Insert Into Manager (mg_name, mg_nike, mg_id, mg_pass, mg_unit, mg_desc)"
                SqlString &= " Values (@mg_name, @mg_nike, @mg_id, @mg_pass, @mg_unit, @mg_desc);"
                SqlString &= "Select @mg_sid = Scope_Identity()"
                SqlString &= "insert into Func_power select @mg_sid as mg_sid, fi2.fi_no1 ,fi2.fi_no2,'1' as is_enable  from func_item1 fi1 "
                SqlString &= "inner join func_item2 fi2 on fi1.fi_no1 = fi2.fi_no1 where fi1.is_visible = 1 and fi2.is_visible = 1"
                Using Sql_Command As New SqlCommand()
                    Sql_Command.Transaction = tran
                    Sql_Command.Connection = Sql_conn
                    Sql_Command.CommandText = SqlString

                    ' 擷取字串到資料庫所規範的大小 sfc.Left(string mdata, int leng) 
                    Sql_Command.Parameters.AddWithValue("@mg_name", UserIdentity.CreateFromCurrentUser().AccountName.Trim())
                    Sql_Command.Parameters.AddWithValue("@mg_nike", UserIdentity.CreateFromCurrentUser().AccountName.Trim())
                    Sql_Command.Parameters.AddWithValue("@mg_id", UserIdentity.CreateFromCurrentUser().AccountName.Trim())
                    'Sql_Command.Parameters.AddWithValue("@mg_pass", decoder.EnCode(sfc.Left(tb_mg_pass.Text, 12)))
                    Sql_Command.Parameters.AddWithValue("@mg_pass", decoder.EnCode(System.Web.Security.Membership.GeneratePassword(12, 2))) 'gmi changed to store some randome password val
                    Sql_Command.Parameters.AddWithValue("@mg_unit", "S")
                    Sql_Command.Parameters.AddWithValue("@mg_desc", "Automatically Created Admin Account")


                    Dim spt_mg_sid As SqlParameter = Sql_Command.Parameters.Add("@mg_sid", SqlDbType.Int)
                    spt_mg_sid.Direction = ParameterDirection.Output

                    Try
                        Sql_Command.ExecuteNonQuery()
                        tran.Commit()
                        ' 取得新增資料的主鍵值 
                        mg_sid = CInt(spt_mg_sid.Value)
                    Catch
                        tran.Rollback()
                    Finally
                        Sql_conn.Close()
                    End Try
                End Using
            End Using
        End If

    End Sub

    Public Shared Function ExeNonQuery(ByVal strSQL As String, ByRef strMsg As String) As Boolean

        Dim Sql_conn As SqlConnection = New SqlConnection(DBConnUtil.GetConnectionString().ConnectionString)
        Dim Sql_command As SqlCommand = New SqlCommand(strSQL, Sql_conn)

        Try

            Sql_conn.Open()
            Sql_command.ExecuteNonQuery()

            'Sql_command.Parameters.AddWithValue("@mg_sid", Session("mg_sid").ToString())


        Catch ex As Exception
            strMsg = ex.Message
            Return False
        Finally
            Try
                Sql_command.Dispose()
                Sql_conn.Close()
            Catch
            End Try
        End Try
        Return True
    End Function


    ' 心情圖示 
    ' 輸入參數：int code 心情代碼 
    ' 傳回數值：string image 圖示路徑 
    ' string name 圖示名稱 
    Public Structure ImageSymbol
        Private _code As Integer
        Private _image As String
        Private _name As String

        Public Property code() As Integer
            Get
                Return _code
            End Get
            Set(ByVal value As Integer)
                SetCode(value)
            End Set
        End Property

        Public ReadOnly Property image() As String
            Get
                Return _image
            End Get
        End Property

        Public ReadOnly Property name() As String
            Get
                Return _name
            End Get
        End Property

        Private Sub SetCode(ByVal code As Integer)
            _code = code
            _image = "~/images/symbol/"

            Select Case code
                Case 0
                    _image &= "S00.gif"
                    _name = "微笑"
                    Exit Select
                Case 1
                    _image &= "S01.gif"
                    _name = "俏皮"
                    Exit Select
                Case 2
                    _image &= "S02.gif"
                    _name = "得意"
                    Exit Select
                Case 3
                    _image &= "S03.gif"
                    _name = "害羞"
                    Exit Select
                Case 4
                    _image &= "S04.gif"
                    _name = "哭泣"
                    Exit Select
                Case 5
                    _image &= "S05.gif"
                    _name = "禁言"
                    Exit Select
                Case 6
                    _image &= "S06.gif"
                    _name = "氣憤"
                    Exit Select
                Case 7
                    _image &= "S07.gif"
                    _name = "鄙視"
                    Exit Select
                Case 8
                    _image &= "S08.gif"
                    _name = "無言"
                    Exit Select
                Case 9
                    _image &= "S09.gif"
                    _name = "害怕"
                    Exit Select
                Case 10
                    _image &= "S10.gif"
                    _name = "真棒"
                    Exit Select
                Case 11
                    _image &= "S11.gif"
                    _name = "傷心"
                    Exit Select
                Case 12
                    _image &= "S12.gif"
                    _name = "握手"
                    Exit Select
                Case 13
                    _image &= "S13.gif"
                    _name = "豬頭"
                    Exit Select
                Case 14
                    _image &= "S14.gif"
                    _name = "大便"
                    Exit Select
                Case 15
                    _image &= "S15.gif"
                    _name = "電話連絡"
                    Exit Select
                Case 16
                    _image &= "S16.gif"
                    _name = "OK"
                    Exit Select
                Case 17
                    _image &= "S17.gif"
                    _name = "禮物"
                    Exit Select
                Case Else
                    _image &= "S00.gif"
                    _name = "微笑"
                    Exit Select
            End Select
        End Sub
    End Structure
End Class