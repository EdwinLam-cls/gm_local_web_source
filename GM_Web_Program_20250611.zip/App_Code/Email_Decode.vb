﻿'---------------------------------------------------------------------------- 
'專案名稱	公用函數
'程式功能	Email 格式解碼(eml 格式解析)
'設計人員	 
'修改人員 
'備註說明	需配合 CodeBase64.vb、QuotedPrintable.vb 使用
'           屬性與函數的說明請參閱第 19 章
'---------------------------------------------------------------------------- 
Imports System.Collections.Generic
Imports System.IO
Imports System.Text
Imports System.Web

Public Class Email_Decode
	' 變數定義
	Private cb64 As New CodeBase64()
	Private qupr As New QuotedPrintable()

	Private _mail_source As String = ""			' 郵件原始資料
	Private _mail_subject As String = ""		' 郵件標題
	Private _mail_from As String = ""			' 寄件者姓名
	Private _mail_fmail As String = ""			' 寄件者郵箱
	Private _mail_ftime As String = ""			' 寄信時間
	Private _mail_to As String = ""				' 收件者姓名
	Private _mail_tmail As String = ""			' 收件者郵箱
	Private _mail_ttime As String = ""			' 收信時間
	Private _mail_body_TEXT As String = ""		' 郵件TEXT內容
	Private _mail_body_HTML As String = ""		' 郵件HTML內容
	Private _mail_body_type As String = ""		' 郵件內文型態 HTML or TEXT or MIXED
	Private _mail_attach_num As Integer = 0		' 郵件附件數量
	Private _mail_attach_name As String()		' 郵件附件檔名
	Private _mail_attach_type As String()		' 郵件附件格式
	Private _mail_attach_encode As String()		' 郵件附件編碼方式
	Private _mail_attach_codepage As String()	' 郵件附件CodePage
	Private _mail_attach_begin As String()		' 郵附件起始位置
	Private _mail_attach_end As String()		' 郵附件結束位置

    Public Property Mail_Source() As String
        Get
            Return _mail_source
        End Get

        Set(ByVal value As String)
            Me._mail_source = value.Trim()
            Body_Analytic()
        End Set
    End Property

    Public WriteOnly Property Mail_Topic() As String
        Set(ByVal value As String)
            ' 設定完成後即進行解析
            Topic_Analytic(value)
        End Set
    End Property

    Public ReadOnly Property Mail_Subject() As String
        Get
            Return _mail_subject
        End Get
    End Property

    Public ReadOnly Property Mail_From_Name() As String
        Get
            Return _mail_from
        End Get
    End Property

    Public ReadOnly Property Mail_From_EMail() As String
        Get
            Return _mail_fmail
        End Get
    End Property

    Public ReadOnly Property Mail_From_Time() As String
        Get
            Return _mail_ftime
        End Get
    End Property

    Public ReadOnly Property Mail_To_Name() As String
        Get
            Return _mail_to
        End Get
    End Property

    Public ReadOnly Property Mail_To_EMail() As String
        Get
            Return _mail_tmail
        End Get
    End Property

    Public ReadOnly Property Mail_To_Time() As String
        Get
            Return _mail_ttime
        End Get
    End Property

    Public ReadOnly Property Mail_Body_Type() As String
        Get
            Return _mail_body_type
        End Get
    End Property

    Public ReadOnly Property Mail_Body() As String
        Get
            If _mail_body_HTML <> "" Then
                Return _mail_body_HTML
            Else
                Return _mail_body_TEXT
            End If
        End Get
    End Property

    Public ReadOnly Property Mail_Body_TEXT() As String
        Get
            Return _mail_body_TEXT
        End Get
    End Property

    Public ReadOnly Property Mail_Body_HTML() As String
        Get
            Return _mail_body_HTML
        End Get
    End Property

    Public ReadOnly Property Attach_Num() As Integer
        Get
            Return _mail_attach_num
        End Get
    End Property

    Public Function FileName(ByVal fcnt As Integer) As String
        Dim fstr As String = ""

        If _mail_attach_name IsNot Nothing Then
            If fcnt <= _mail_attach_name.Length AndAlso fcnt > -1 Then
                fstr = _mail_attach_name(fcnt)
            End If
        End If
        Return fstr
    End Function

    Public Function FileType(ByVal fcnt As Integer) As String
        Dim fstr As String = ""

        If _mail_attach_type IsNot Nothing Then
            If fcnt <= _mail_attach_type.Length AndAlso fcnt > -1 Then
                fstr = _mail_attach_type(fcnt)
            End If
        End If
        Return fstr
    End Function

    Public Function FileEnCode(ByVal fcnt As Integer) As String
        Dim fstr As String = ""

        If _mail_attach_encode IsNot Nothing Then
            If fcnt <= _mail_attach_encode.Length AndAlso fcnt > -1 Then
                fstr = _mail_attach_encode(fcnt)
            End If
        End If
        Return fstr
    End Function

    Public Function FileCodePage(ByVal fcnt As Integer) As Integer
        Dim fint As Integer = 0

        If _mail_attach_codepage IsNot Nothing Then
            If fcnt <= _mail_attach_codepage.Length AndAlso fcnt > -1 Then
                fint = Integer.Parse(_mail_attach_codepage(fcnt))
            End If
        End If
        Return fint
    End Function

    Public Function FileBegin(ByVal fcnt As Integer) As Integer
        Dim fint As Integer = 0

        If _mail_attach_begin IsNot Nothing Then
            If fcnt <= _mail_attach_begin.Length AndAlso fcnt > -1 Then
                fint = Integer.Parse(_mail_attach_begin(fcnt))
            End If
        End If
        Return fint
    End Function

    Public Function FileEnd(ByVal fcnt As Integer) As Integer
        Dim fint As Integer = 0

        If _mail_attach_end IsNot Nothing Then
            If fcnt <= _mail_attach_end.Length AndAlso fcnt > -1 Then
                fint = Integer.Parse(_mail_attach_end(fcnt))
            End If
        End If
        Return fint
    End Function

    Public Function File(ByVal fcnt As Integer) As Byte()
        Dim bcnt As Integer = 0, ecnt As Integer = 0, codepage As Integer = 0
        Dim fdata As String = ""
        Dim fbyte As Byte() = Nothing

        If _mail_attach_begin IsNot Nothing AndAlso _mail_attach_end IsNot Nothing AndAlso _mail_attach_codepage IsNot Nothing AndAlso _mail_attach_encode IsNot Nothing Then
            If fcnt > -1 AndAlso _mail_attach_begin.Length >= fcnt AndAlso _mail_attach_end.Length >= fcnt AndAlso _mail_attach_codepage.Length >= fcnt AndAlso _mail_attach_encode.Length >= fcnt Then
                If _mail_attach_codepage(fcnt) = "" Then
                    codepage = 65001
                Else
                    codepage = Integer.Parse(_mail_attach_codepage(fcnt))
                End If
                bcnt = Integer.Parse(_mail_attach_begin(fcnt))
                ecnt = Integer.Parse(_mail_attach_end(fcnt))

                If ecnt > bcnt Then
                    fdata = _mail_source.Substring(bcnt, ecnt - bcnt)

                    Select Case _mail_attach_encode(fcnt)
                        Case "base64"
                            fbyte = Convert.FromBase64String(fdata)
                            Exit Select
                        Case "quoted-printable"
                            fdata = qupr.DeCodeQuoted(codepage, fdata)
                            fbyte = System.Text.Encoding.Default.GetBytes(fdata)
                            Exit Select
                        Case Else
                            fbyte = System.Text.Encoding.Default.GetBytes("")
                            Exit Select
                    End Select
                End If
            End If
        End If

        Return fbyte
    End Function

    Private Function ToDTStr(ByVal s_source As String) As String
        Dim s_target As String = ""
        Dim dt_target As DateTime

        Dim tmp_array As String() = s_source.Split(" "c)

        If tmp_array.Length > 5 Then
            ' 有星期的日期格式
            s_target = tmp_array(3) & "/" & MonthToNum(tmp_array(2)).ToString() & "/" & tmp_array(1) & " " & tmp_array(4)
            If DateTime.TryParse(s_target, dt_target) Then
                s_target = dt_target.ToString("yyyy/MM/dd HH:mm:ss")
            Else
                s_target = ""
            End If
        ElseIf tmp_array.Length > 4 Then
            ' 沒有星期的日期格式
            s_target = tmp_array(2) & "/" & MonthToNum(tmp_array(1)).ToString() & "/" & tmp_array(0) & " " & tmp_array(3)
            If DateTime.TryParse(s_target, dt_target) Then
                s_target = dt_target.ToString("yyyy/MM/dd HH:mm:ss")
            Else
                s_target = ""
            End If
        End If

        Return s_target
    End Function

    Private Function MonthToNum(ByVal str_month As String) As Integer
        Dim int_month As Integer = 0

        If str_month.Length >= 3 Then
            str_month = str_month.Substring(0, 3).ToLower()

            Select Case str_month
                Case "jan"
                    int_month = 1
                    Exit Select
                Case "feb"
                    int_month = 2
                    Exit Select
                Case "mar"
                    int_month = 3
                    Exit Select
                Case "apr"
                    int_month = 4
                    Exit Select
                Case "may"
                    int_month = 5
                    Exit Select
                Case "jun"
                    int_month = 6
                    Exit Select
                Case "jul"
                    int_month = 7
                    Exit Select
                Case "aug"
                    int_month = 8
                    Exit Select
                Case "sep"
                    int_month = 9
                    Exit Select
                Case "oct"
                    int_month = 10
                    Exit Select
                Case "nov"
                    int_month = 11
                    Exit Select
                Case "dec"
                    int_month = 12
                    Exit Select
                Case Else
                    int_month = 0
                    Exit Select
            End Select
        Else
            int_month = 0
        End If

        Return int_month
    End Function

    Public Sub Topic_Analytic(ByVal mail_topic As String)
        Dim bcnt As Integer = 0, ecnt As Integer = 0, scnt As Integer = 0, code_page As Integer = 0
        Dim tmpstr As String = "", tmpstr2 As String = "", page_name As String = "", codetype As String = "B"

        ' 擷取寄信時間
        _mail_ftime = ""

        bcnt = mail_topic.IndexOf(vbCr & vbLf & "Date: ")
        If bcnt > -1 Then
            bcnt += 8
            ecnt = mail_topic.IndexOf(vbCr & vbLf, bcnt)

            If ecnt > -1 Then
                _mail_ftime = ToDTStr(mail_topic.Substring(bcnt, ecnt - bcnt))
            End If
        End If

        ' 擷取寄件者姓名及信箱
        _mail_from = ""
        _mail_fmail = ""

        bcnt = mail_topic.IndexOf(vbCr & vbLf & "From: ")
        If bcnt > -1 Then
            bcnt += 8
            ecnt = mail_topic.IndexOf(vbCr & vbLf, bcnt)
            If ecnt > -1 Then
                tmpstr = mail_topic.Substring(bcnt, ecnt - bcnt)

                ' 取得寄件者信箱
                bcnt = tmpstr.IndexOf("<")
                ecnt = tmpstr.IndexOf(">")
                If bcnt > -1 AndAlso ecnt > -1 Then
                    bcnt += 1
                    ecnt -= 1
                    If ecnt > bcnt Then
                        _mail_fmail = tmpstr.Substring(bcnt, ecnt - bcnt + 1)
                    End If
                    bcnt -= 2
                    If bcnt > 0 AndAlso ecnt > (bcnt + 2) Then
                        tmpstr = tmpstr.Remove(bcnt, ecnt - bcnt + 2)
                    Else
                        tmpstr = ""
                    End If
                End If

                ' 取得寄件者姓名
                _mail_from = _mail_fmail

                If tmpstr.Length > 2 Then
                    If tmpstr.Substring(0, 2) = "=?" Then
                        ' 寄件者姓名用 Base64 編碼
                        bcnt = 2
                        ecnt = tmpstr.IndexOf("?B?")
                        If ecnt > -1 Then
                            page_name = tmpstr.Substring(bcnt, ecnt - 2)

                            code_page = cb64.GetCodePage(page_name)

                            ' CodePage 正確
                            If code_page > 0 Then
                                bcnt = ecnt + 3
                                ecnt = tmpstr.IndexOf("?=", bcnt)

                                If ecnt > 0 Then
                                    tmpstr = tmpstr.Substring(bcnt, ecnt - bcnt)

                                    tmpstr = cb64.DeCodeBase64(code_page, tmpstr)

                                    If tmpstr <> "" Then
                                        _mail_from = tmpstr
                                    End If
                                End If
                            End If
                        End If
                    Else
                        If tmpstr.Substring(0, 1) = """" Then
                            ' 沒有編碼
                            ecnt = tmpstr.IndexOf("""", 1)
                            If ecnt > -1 Then
                                _mail_from = tmpstr.Substring(1, ecnt - 1)
                            End If
                        ElseIf tmpstr.Trim() <> "" Then
                            _mail_from = tmpstr.Trim()
                        End If
                    End If
                End If
            End If
        End If

        ' 擷取收信時間
        _mail_ttime = ""

        bcnt = mail_topic.IndexOf(vbCr & vbLf & vbTab & "for ")
        If bcnt > -1 Then
            bcnt = mail_topic.IndexOf("; ", bcnt)

            If bcnt > -1 Then
                bcnt += 2
                ecnt = mail_topic.IndexOf(")" & vbCr & vbLf, bcnt)
                If ecnt > -1 Then
                    _mail_ttime = ToDTStr(mail_topic.Substring(bcnt, ecnt - bcnt + 1))
                End If
            End If
        End If

        ' 擷取收件者姓名及信箱
        _mail_to = ""
        _mail_tmail = ""

        bcnt = mail_topic.IndexOf(vbCr & vbLf & "To: ")
        If bcnt > -1 Then
            bcnt += 6
            ecnt = mail_topic.IndexOf(vbCr & vbLf, bcnt)
            If ecnt > -1 Then
                tmpstr = mail_topic.Substring(bcnt, ecnt - bcnt)

                ' 取得收件者信箱
                bcnt = tmpstr.IndexOf("<")
                ecnt = tmpstr.IndexOf(">")
                If bcnt > -1 AndAlso ecnt > -1 Then
                    bcnt += 1
                    ecnt -= 1
                    If ecnt > bcnt Then
                        _mail_tmail = tmpstr.Substring(bcnt, ecnt - bcnt + 1)
                    End If
                    bcnt -= 2
                    If bcnt > 0 AndAlso ecnt > (bcnt + 2) Then
                        tmpstr = tmpstr.Remove(bcnt, ecnt - bcnt + 2)
                    Else
                        tmpstr = ""
                    End If
                End If

                ' 取得收件者姓名
                _mail_to = _mail_tmail

                If tmpstr.Length > 2 Then
                    If tmpstr.Substring(0, 2) = "=?" Then
                        ' 收件者姓名用 Base64 編碼
                        bcnt = 2
                        ecnt = tmpstr.IndexOf("?B?")
                        If ecnt > -1 Then
                            page_name = tmpstr.Substring(bcnt, ecnt - 2)

                            code_page = cb64.GetCodePage(page_name)

                            ' CodePage 正確
                            If code_page > 0 Then
                                bcnt = ecnt + 3
                                ecnt = tmpstr.IndexOf("?=", bcnt)

                                If ecnt > 0 Then
                                    tmpstr = tmpstr.Substring(bcnt, ecnt - bcnt)

                                    tmpstr = cb64.DeCodeBase64(code_page, tmpstr)

                                    If tmpstr <> "" Then
                                        _mail_to = tmpstr
                                    End If
                                End If
                            End If
                        End If
                    Else
                        If tmpstr.Substring(0, 1) = """" Then
                            ' 沒有編碼
                            ecnt = tmpstr.IndexOf("""", 1)
                            If ecnt > -1 Then
                                _mail_to = tmpstr.Substring(1, ecnt - 1)
                            End If
                        ElseIf tmpstr.Trim() <> "" Then
                            _mail_to = tmpstr.Trim()
                        End If
                    End If
                End If
            End If
        End If

        ' 取得郵件標題
        _mail_subject = ""

        bcnt = mail_topic.IndexOf(vbCr & vbLf & "Subject: ")
        If bcnt > -1 Then
            bcnt += 11
            scnt = mail_topic.IndexOf(vbCr & vbLf, bcnt)
            tmpstr = mail_topic.Substring(bcnt, scnt - bcnt)

            If tmpstr.Substring(0, 2) = "=?" Then
                While tmpstr.Substring(0, 2) = "=?"
                    ' 檢查郵件標題用 Base64 編碼 或 QuotedPrintable 編碼

                    bcnt = 2
                    codetype = "B"
                    ecnt = tmpstr.IndexOf("?B?")
                    If ecnt < 0 Then
                        codetype = "Q"
                        ecnt = tmpstr.IndexOf("?Q?")
                    End If

                    If ecnt > -1 Then
                        page_name = tmpstr.Substring(bcnt, ecnt - bcnt)

                        If codetype = "B" Then
                            code_page = cb64.GetCodePage(page_name)
                        Else
                            code_page = qupr.GetCodePage(page_name)
                        End If

                        ' CodePage 正確
                        If code_page > 0 Then
                            bcnt = ecnt + 3
                            ecnt = tmpstr.IndexOf("?=", bcnt)

                            If ecnt > 0 Then
                                tmpstr2 = tmpstr.Substring(bcnt, ecnt - bcnt).Replace("====", "==")

                                If codetype = "B" Then
                                    tmpstr2 = cb64.DeCodeBase64(code_page, tmpstr2)
                                Else
                                    tmpstr2 = qupr.DeCodeQuoted(code_page, tmpstr2)
                                    tmpstr2 = tmpstr2.Replace("_", " ")
                                End If

                                If tmpstr2 <> "" Then
                                    _mail_subject &= tmpstr2
                                End If
                            Else
                                _mail_subject &= tmpstr.Substring(bcnt, ecnt - bcnt).Trim()
                            End If
                        Else
                            If (ecnt - bcnt) > 0 Then
                                _mail_subject &= tmpstr.Substring(bcnt, ecnt - bcnt).Trim()
                            Else
                                _mail_subject &= "(none)"
                            End If
                        End If

                        If mail_topic.Substring(scnt + 2, 3) = vbTab & "=?" OrElse mail_topic.Substring(scnt + 2, 3) = " =?" Then
                            bcnt = scnt + 3
                            scnt = mail_topic.IndexOf(vbCr & vbLf, bcnt)
                            If scnt > bcnt Then
                                tmpstr = mail_topic.Substring(bcnt, scnt - bcnt).Trim()
                            Else
                                tmpstr = "xx1"
                            End If
                        Else
                            tmpstr = "xx2"
                        End If
                    End If
                End While
            Else
                ' 沒有編碼
                _mail_subject = tmpstr
            End If
        End If
    End Sub

    Public Sub Body_Analytic()
        Dim scnt As Integer = 0, bcnt As Integer = 0, ecnt As Integer = 0, fcnt As Integer = 0, icnt As Integer = 0
        Dim page_name As String = "", dcode As String = "", fmark As String = "", tmpdata As String = "", boundstr As String = ""
        Dim fname As String = "", fbegin As String = "", fend As String = "", ftype As String = "", fencode As String = "", fcodepage As String = ""

        ' 郵件內容相關資料先清空
        _mail_body_HTML = ""
        _mail_body_TEXT = ""
        _mail_body_type = ""
        _mail_attach_num = 0

        ' 尋找是否有附件，若有則找出附件起始標籤
        scnt = _mail_source.IndexOf("Content-Type: multipart/mixed")

        If scnt > 0 Then
            scnt += 29
            bcnt = _mail_source.IndexOf("boundary=", scnt)
            If bcnt > 0 Then
                bcnt += 9
                ecnt = _mail_source.IndexOf(vbCr & vbLf, bcnt)
                If ecnt - bcnt > 0 Then
                    fmark = _mail_source.Substring(bcnt, ecnt - bcnt).Replace("""", "").Replace(" ", "")
                End If
            End If
        End If

        ' 尋找郵件格式 HTML or TEXT or MIXED
        scnt = _mail_source.IndexOf("Content-Type: multipart/alternative")

        If scnt > 0 Then
            scnt += 35

            _mail_body_type = "MIXED"

            bcnt = _mail_source.IndexOf("boundary=", scnt)
            If bcnt > 0 Then
                bcnt += 9
                ecnt = _mail_source.IndexOf(vbCr & vbLf, bcnt)

                If ecnt - bcnt > 0 Then
                    boundstr = _mail_source.Substring(bcnt, ecnt - bcnt)
                    boundstr = boundstr.Replace(" ", "").Replace("""", "")
                End If

                scnt = ecnt + 2
            Else
                boundstr = "--"
            End If
        Else
            scnt = _mail_source.IndexOf(vbCr & vbLf & "Content-Type: ")

            If _mail_source.Substring(scnt + 16, 15) = "multipart/mixed" Then
                ' 非所要找的資料，繼續找下一個符合的條件
                scnt = _mail_source.IndexOf(vbCr & vbLf & "Content-Type: ", scnt + 16)
            End If

            If scnt > 0 Then
                ecnt = _mail_source.IndexOf(vbCr & vbLf, scnt + 2)

                If ecnt - scnt > 16 Then
                    bcnt = scnt + 16

                    ' 取得郵件內容格式、CodePage
                    If _mail_source.Substring(bcnt, 9) = "text/html" Then
                        _mail_body_type = "HTML"

                        bcnt = _mail_source.IndexOf("charset", bcnt)
                        If bcnt > 0 AndAlso ecnt - bcnt > 8 Then
                            bcnt += 8
                            page_name = _mail_source.Substring(bcnt, ecnt - bcnt).Replace("=", "").Replace(" ", "").Replace("""", "")
                        End If
                    ElseIf _mail_source.Substring(bcnt, 10) = "text/plain" Then
                        _mail_body_type = "TEXT"

                        bcnt = _mail_source.IndexOf("charset", bcnt)
                        If bcnt > 0 AndAlso ecnt - bcnt > 8 Then
                            bcnt += 8
                            page_name = _mail_source.Substring(bcnt, ecnt - bcnt).Replace("=", "").Replace(" ", "").Replace("""", "")
                        End If
                    End If
                End If
            End If
        End If

        ' 解析郵件內容
        If _mail_body_type = "TEXT" OrElse _mail_body_type = "HTML" Then
            ' 內文格式為 TEXT 和 HTML 的處理方式

            ' 取得編碼方式"
            bcnt = _mail_source.IndexOf("Content-Transfer-Encoding:")

            If bcnt > 0 Then
                ecnt = _mail_source.IndexOf(vbCr & vbLf, bcnt)
                If ecnt > 0 Then
                    bcnt += 27
                    dcode = _mail_source.Substring(bcnt, ecnt - bcnt)
                End If
            End If

            ' 取得資料並解碼
            bcnt = _mail_source.IndexOf(vbCr & vbLf & vbCr & vbLf, bcnt)
            If bcnt > 0 Then
                bcnt += 4
                If fmark = "" Then
                    ecnt = _mail_source.Length
                Else
                    ecnt = _mail_source.IndexOf(vbCr & vbLf & "--" & fmark, bcnt)
                    If ecnt < 0 Then
                        ecnt = _mail_source.Length
                    End If
                End If
                tmpdata = _mail_source.Substring(bcnt, ecnt - bcnt)
                tmpdata = body_decode(tmpdata, page_name, dcode)

                If _mail_body_type = "TEXT" Then
                    _mail_body_TEXT = tmpdata.Trim()
                Else
                    _mail_body_HTML = tmpdata.Trim()
                End If
            End If
        Else
            ' 內文格式為 MIXED 的處理方式
            scnt = _mail_source.IndexOf(boundstr, scnt)

            If bcnt > 0 Then
                scnt += boundstr.Length

                ' 取得 TEXT 的內文
                bcnt = _mail_source.IndexOf("Content-Type: text/plain;", scnt)

                If bcnt > 0 Then
                    tmpdata = _mail_source.Substring(bcnt + 20, 60)
                    icnt = tmpdata.IndexOf("charset")
                    If icnt > 0 Then
                        icnt += 8

                        ' 取得 CodePage
                        ecnt = tmpdata.IndexOf(vbCr & vbLf, icnt)
                        page_name = tmpdata.Substring(icnt, ecnt - icnt)
                        page_name = page_name.Replace("""", "").Replace(" ", "").Replace("=", "").Replace("""", "")

                        ' 取得編碼方式
                        bcnt += 27
                        bcnt = _mail_source.IndexOf("Content-Transfer-Encoding:", bcnt)
                        If bcnt > 0 Then
                            ecnt = _mail_source.IndexOf(vbCr & vbLf, bcnt)
                            If ecnt > 0 Then
                                bcnt += 27
                                dcode = _mail_source.Substring(bcnt, ecnt - bcnt)
                            End If
                        Else
                            dcode = "quoted-printable"
                        End If

                        ' 取得內文，並解碼
                        bcnt = _mail_source.IndexOf(vbCr & vbLf & vbCr & vbLf, ecnt)

                        If bcnt > 0 Then
                            bcnt += 4
                            ecnt = _mail_source.IndexOf(vbCr & vbLf & "--" & boundstr, bcnt)

                            If ecnt > bcnt Then
                                tmpdata = _mail_source.Substring(bcnt, ecnt - bcnt)
                                tmpdata = body_decode(tmpdata, page_name, dcode)

                                _mail_body_TEXT = tmpdata.Trim()
                            End If
                        End If
                    End If
                End If

                ' 取得 HTML 的內文
                bcnt = _mail_source.IndexOf("Content-Type: text/html;", scnt)

                If bcnt > 0 Then
                    tmpdata = _mail_source.Substring(bcnt + 20, 60)
                    icnt = tmpdata.IndexOf("charset=")
                    If icnt < 0 Then
                        icnt = tmpdata.IndexOf("charset = ")
                        If icnt > 0 Then
                            icnt = icnt + 10
                        Else
                            icnt = -1
                        End If
                    Else
                        icnt = icnt + 8
                    End If

                    If icnt > 0 Then
                        ' 取得 CodePage
                        ecnt = tmpdata.IndexOf(vbCr & vbLf, icnt)
                        page_name = tmpdata.Substring(icnt, ecnt - icnt)
                        page_name = page_name.Replace("""", "")

                        ' 取得編碼方式
                        bcnt += 27
                        bcnt = _mail_source.IndexOf("Content-Transfer-Encoding:", bcnt)
                        If bcnt > 0 Then
                            ecnt = _mail_source.IndexOf(vbCr & vbLf, bcnt)
                            If ecnt > 0 Then
                                bcnt += 27
                                dcode = _mail_source.Substring(bcnt, ecnt - bcnt)
                            End If
                        Else
                            dcode = "quoted-printable"
                        End If

                        ' 取得內文，並解碼
                        bcnt = _mail_source.IndexOf(vbCr & vbLf & vbCr & vbLf, bcnt)
                        If bcnt > 0 Then
                            bcnt += 4
                            ecnt = _mail_source.IndexOf(vbCr & vbLf & "--" & boundstr, bcnt)

                            If ecnt > bcnt Then
                                tmpdata = _mail_source.Substring(bcnt, ecnt - bcnt)
                                _mail_body_HTML = tmpdata

                                tmpdata = body_decode(tmpdata, page_name, dcode)

                                If tmpdata <> "" Then
                                    _mail_body_HTML = tmpdata.Trim()
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If

        ' 附加檔案處理 (計算附檔數量、檔案名稱及起始位置)
        If fmark <> "" Then
            fcnt = 0
            fname = ""
            fbegin = ""

            scnt = _mail_source.IndexOf(fmark, bcnt)
            While scnt > 0
                scnt += fmark.Length

                ' 計算附檔數量
                fcnt += 1

                ' 取得檔案格式
                bcnt = _mail_source.IndexOf("Content-Type: ", scnt)

                If bcnt > 0 Then
                    bcnt += 14
                    ecnt = _mail_source.IndexOf(vbCr & vbLf, bcnt)
                    ftype &= _mail_source.Substring(bcnt, ecnt - bcnt).Replace(";", "") & ";"
                Else
                    ftype &= ";"
                End If

                ' 取得編碼方式
                bcnt = _mail_source.IndexOf("Content-Transfer-Encoding: ", scnt)
                If bcnt > 0 Then
                    bcnt += 27
                    ecnt = _mail_source.IndexOf(vbCr & vbLf, bcnt)
                    fencode &= _mail_source.Substring(bcnt, ecnt - bcnt) & ";"
                Else
                    fencode &= ";"
                End If

                ' 取得檔名及起訖位置
                ' OutLook or OutLook Express
                bcnt = _mail_source.IndexOf(vbCr & vbLf & vbTab & "filename=""", scnt)
                If bcnt > 0 Then
                    bcnt += 13
                Else
                    ' Hotmail
                    bcnt = _mail_source.IndexOf("; filename=""", scnt)
                    If bcnt > 0 Then
                        bcnt += 12
                    End If
                End If

                If bcnt > 0 Then
                    ecnt = _mail_source.IndexOf(vbCr & vbLf, bcnt)
                    tmpdata = _mail_source.Substring(bcnt, ecnt - bcnt)
                    tmpdata = tmpdata.Replace("""", "")

                    fname &= tmpdata.Trim() & ";"
                    fcodepage &= topic_codepage(tmpdata).ToString() & ";"

                    ecnt = _mail_source.IndexOf(vbCr & vbLf & vbCr & vbLf, bcnt)
                    fbegin &= (ecnt + 4).ToString() & ";"
                    fend &= _mail_source.IndexOf(vbCr & vbLf & "--" & fmark, ecnt + fmark.Length).ToString() & ";"
                Else
                    fname &= ";"
                    fcodepage &= ";"
                    fbegin &= "0;"
                    fend &= "0;"
                End If

                scnt = _mail_source.IndexOf(fmark, scnt)
                If scnt + fmark.Length + 5 >= _mail_source.Length Then
                    scnt = 0
                End If
            End While

            ' 將取得的資料分存到指定位置
            _mail_attach_num = fcnt
            _mail_attach_type = ftype.Split(";"c)
            _mail_attach_encode = fencode.Split(";"c)
            _mail_attach_codepage = fcodepage.Split(";"c)
            _mail_attach_begin = fbegin.Split(";"c)
            _mail_attach_end = fend.Split(";"c)
            _mail_attach_name = fname.Split(";"c)

            ' 檔名解碼
            For icnt = 0 To fcnt - 1
                _mail_attach_name(icnt) = topic_decode(_mail_attach_name(icnt)).Replace(vbNullChar, "")
            Next
        Else
            ' 沒有附加檔案
            _mail_attach_num = 0
            _mail_attach_type = Nothing
            _mail_attach_encode = Nothing
            _mail_attach_codepage = Nothing
            _mail_attach_begin = Nothing
            _mail_attach_end = Nothing
            _mail_attach_name = Nothing
        End If
    End Sub

    Private Function body_decode(ByVal bodystr As String, ByVal page_name As String, ByVal codetype As String) As String
        Dim codepage As Integer = cb64.GetCodePage(page_name)

        If codepage > 65535 OrElse codepage < 0 Then
            codepage = 65001
        End If

        Select Case codetype
            Case "base64"
                bodystr = cb64.DeCodeBase64(codepage, bodystr)
                Exit Select
            Case "quoted-printable"
                bodystr = qupr.DeCodeQuoted(codepage, bodystr)
                Exit Select
        End Select

        Return bodystr
    End Function

    Private Function topic_decode(ByVal topstr As String) As String
        Dim page_name As String = "", codetype As String = "B"
        Dim bcnt As Integer = 0, ecnt As Integer = 0, codepage As Integer = 0

        If topstr.Length > 5 Then
            If topstr.Substring(0, 2) = "=?" Then
                bcnt = 2
                ecnt = topstr.IndexOf("?B?")
                If ecnt < 0 Then
                    ecnt = topstr.IndexOf("?Q?")
                    codetype = "Q"
                End If

                page_name = topstr.Substring(bcnt, ecnt - bcnt)
                codepage = cb64.GetCodePage(page_name)

                bcnt = ecnt + 3
                ecnt = topstr.IndexOf("?=", bcnt)

                topstr = topstr.Substring(bcnt, ecnt - bcnt)

                Select Case codetype
                    Case "B"
                        topstr = cb64.DeCodeBase64(codepage, topstr)
                        Exit Select
                    Case "Q"
                        topstr = qupr.DeCodeQuoted(codepage, topstr)
                        Exit Select
                End Select
            End If
        End If

        Return topstr
    End Function

    Private Function topic_codepage(ByVal topstr As String) As Integer
        Dim page_name As String = ""
        Dim bcnt As Integer = 0, ecnt As Integer = 0, codepage As Integer = 0

        If topstr.Substring(0, 2) = "=?" Then
            bcnt = 2
            ecnt = topstr.IndexOf("?B?")
            If ecnt < 0 Then
                ecnt = topstr.IndexOf("?Q?")
            End If

            If ecnt > bcnt Then
                page_name = topstr.Substring(bcnt, ecnt - bcnt)
                codepage = cb64.GetCodePage(page_name)
            Else
                codepage = 65001

            End If
        Else
            codepage = 65001
        End If

        Return codepage
    End Function
End Class