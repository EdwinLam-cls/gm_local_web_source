﻿'---------------------------------------------------------------------------- 
'程式功能 字串函數 
'程式名稱 /App_Code/String_Func.vb
'設計人員 
'修改人員 
'備註說明 
'---------------------------------------------------------------------------- 
Imports System
Imports System.Text

Public Class String_Func
#Region "IsInteger() 檢查是否為整數值"
    Public Function IsInteger(ByVal mdata As String) As Boolean
        Dim mfg As Boolean = True

        For iCnt As Integer = 0 To mdata.Length - 1
            If Not Char.IsDigit(mdata(iCnt)) Then
                mfg = False
                iCnt = mdata.Length
            End If
        Next

        Return mfg
    End Function
#End Region

#Region "Left() 擷取左側字元"
    Public Function Left(ByVal mdata As String) As String
        Return Left(mdata, 1)
    End Function
	Public Function Left(ByVal mdata As String, ByVal leng As Integer) As String
		mdata = mdata.Trim()
		If mdata.Length < leng Then
			leng = mdata.Length
		End If

		Return mdata.Trim().Substring(0, leng)
	End Function
#End Region

#Region "Right() 擷取右側字元"
    Public Function Right(ByVal mdata As String) As String
        Return Right(mdata, 1)
    End Function

	Public Function Right(ByVal mdata As String, ByVal leng As Integer) As String
		mdata = mdata.Trim()

		If mdata.Length < leng Then
			leng = mdata.Length
		End If

		Return mdata.Substring(mdata.Length - leng, leng)
	End Function
#End Region

#Region "FillRight() 以指定字元填滿右方不足長度的位置"
    Public Function FillRight(ByVal mstr As String, ByVal ilen As Integer) As String
        Return FillRight(mstr, ilen, "0")
    End Function

	Public Function FillRight(ByVal mstr As String, ByVal ilen As Integer, ByVal fstr As String) As String
		Dim nstr As String = ""

		' 只取第一個字元作為填滿字元 
		If fstr.Length > 1 Then
			fstr = fstr.Substring(0, 1)
		End If

		If mstr.Length >= ilen Then
			nstr = mstr
		Else
			nstr = mstr & Duplicate(fstr, ilen - mstr.Length)
		End If

		Return nstr
	End Function
#End Region

#Region "FillLeft() 以指定字元填滿左方不足長度的位置"
    Public Function FillLeft(ByVal mstr As String, ByVal ilen As Integer) As String
        Return FillLeft(mstr, ilen, "0")
    End Function

	Public Function FillLeft(ByVal mstr As String, ByVal ilen As Integer, ByVal fstr As String) As String
		Dim nstr As String = ""

		' 只取第一個字元作為填滿字元 
		If fstr.Length > 1 Then
			fstr = fstr.Substring(0, 1)
		End If

		If mstr.Length >= ilen Then
			nstr = mstr
		Else
			nstr = Duplicate(fstr, ilen - mstr.Length) & mstr
		End If

		Return nstr
	End Function
#End Region

#Region "Dupliacte() 產生重覆字串"
    Public Function Duplicate(ByVal mstr As String, ByVal ncnt As Integer) As String
        ' 使用 StringBuilder 加速字串重覆產生的速度 
        Dim dstr As New StringBuilder()
        Dim icnt As Integer = 0

        For icnt = 0 To ncnt - 1
            dstr.Append(mstr)
        Next

        Return dstr.ToString()
    End Function
#End Region

#Region "ChNumber() 個位數字轉中文數字 (零、一、二....)"
    Public Function ChNumber(ByVal NValue As Integer) As String
        Return ChNumber(NValue.ToString())
    End Function

	Public Function ChNumber(ByVal NStr As String) As String
		' 只取右方一個字元 
		NStr = Left(NStr, 1)

		Select Case NStr
			Case "0"
				NStr = "零"
				Exit Select

			Case "1"
				NStr = "一"
				Exit Select

			Case "2"
				NStr = "二"
				Exit Select

			Case "3"
				NStr = "三"
				Exit Select

			Case "4"
				NStr = "四"
				Exit Select

			Case "5"
				NStr = "五"
				Exit Select

			Case "6"
				NStr = "六"
				Exit Select

			Case "7"
				NStr = "七"
				Exit Select

			Case "8"
				NStr = "八"
				Exit Select

			Case "9"
				NStr = "九"
				Exit Select
			Case Else

				NStr = "？"
				Exit Select
		End Select
		Return NStr
	End Function
#End Region

#Region "ChCapitalNumber() 個位數字轉中文大寫數字 (零、壹、貳...)"
    Public Function ChCapitalNumber(ByVal NValue As Integer) As String
        Return ChCapitalNumber(NValue.ToString())
    End Function

	Public Function ChCapitalNumber(ByVal NStr As String) As String
		NStr = Left(NStr, 1)

		Select Case NStr
			Case "0"
				NStr = "零"
				Exit Select

			Case "1"
				NStr = "壹"
				Exit Select

			Case "2"
				NStr = "貳"
				Exit Select

			Case "3"
				NStr = "參"
				Exit Select

			Case "4"
				NStr = "肆"
				Exit Select

			Case "5"
				NStr = "伍"
				Exit Select

			Case "6"
				NStr = "陸"
				Exit Select

			Case "7"
				NStr = "柒"
				Exit Select

			Case "8"
				NStr = "捌"
				Exit Select

			Case "9"
				NStr = "玖"
				Exit Select
			Case Else

				NStr = "？"
				Exit Select
		End Select
		Return NStr
	End Function
#End Region

#Region "GetFourChNumber() 取得每四位數的中文位數字 (萬、億、兆...)"
    Public Function GetFourChNumber(ByVal iDigit As Integer) As String
        Dim sDigit As String = ""

        ' 限於整數態的上限，「京」之後的中文數字是用不到 
        Select Case iDigit
            Case 0
                sDigit = ""
                Exit Select
            Case 1
                sDigit = "萬"
                Exit Select
            Case 2
                sDigit = "億"
                Exit Select
            Case 3
                sDigit = "兆"
                Exit Select
            Case 4
                sDigit = "京"
                Exit Select
            Case 5
                sDigit = "垓"
                Exit Select
            Case 6
                sDigit = "秭"
                Exit Select
            Case 7
                sDigit = "穰"
                Exit Select
            Case 8
                sDigit = "溝"
                Exit Select
            Case 9
                sDigit = "澗"
                Exit Select
            Case 10
                sDigit = "正"
                Exit Select
            Case 11
                sDigit = "載"
                Exit Select
            Case 12
                sDigit = "極"
                Exit Select
            Case Else
                sDigit = "∞"
                Exit Select
        End Select

        Return sDigit
    End Function
#End Region

#Region "GetChNumber() 整數轉中文數字 （10050 => 一萬零五十）"
    Public Function GetChNumber(ByVal mInt As Integer) As String
        Return GetChNumber(mInt.ToString())
    End Function

	Public Function GetChNumber(ByVal mInt As Int64) As String
		Return GetChNumber(mInt.ToString())
	End Function

	Public Function GetChNumber(ByVal mInt As UInt64) As String
		Return GetChNumber(mInt.ToString())
	End Function

	Public Function GetChNumber(ByVal NumStr As [String]) As String
		Dim ChStr As String = "", ChSubStr As String = "", tmpStr As String = ""
		Dim iCnt As Integer = 0, jCnt As Integer = 0, kCnt As Integer = 0, lCnt As Integer = -1, nCnt As Integer = 0

		If Not IsInteger(NumStr) Then
			NumStr = "0"
		End If

		nCnt = NumStr.Length

		' 中文數字以四位數為一個處理單位(萬、億、兆、京....) 
		iCnt = nCnt Mod 4
		NumStr = Duplicate("0", 4 - iCnt) & NumStr
		nCnt = NumStr.Length

		For iCnt = 0 To nCnt - 1 Step 4
			lCnt += 1
			ChSubStr = ""

			For jCnt = 0 To 3
				kCnt = nCnt - iCnt - jCnt - 1
				tmpStr = ChNumber(NumStr.Substring(kCnt, 1))

				If tmpStr = "零" Then
					If Left(ChSubStr, 1) <> "零" AndAlso Left(ChSubStr, 1) <> "" Then
						ChSubStr = tmpStr & ChSubStr
					End If
				Else
					Select Case jCnt
						Case 0
							ChSubStr = tmpStr
							Exit Select
						Case 1
							ChSubStr = (tmpStr & "十") & ChSubStr
							Exit Select
						Case 2
							ChSubStr = (tmpStr & "百") & ChSubStr
							Exit Select
						Case 3
							ChSubStr = (tmpStr & "千") & ChSubStr
							Exit Select
						Case Else
							ChSubStr = (tmpStr & "∞") & ChSubStr
							Exit Select
					End Select
				End If
			Next

			If ChSubStr = "零" AndAlso Left(ChStr, 1) <> "" AndAlso Left(ChStr, 1) <> "零" Then
				ChStr = "零" & ChStr
			Else
				If ChSubStr <> "" Then
					' 取得10000的次方中文數字 
					' 限於整數態的上限，「京」之後的中文數字是用不到 
					ChStr = ChSubStr & GetFourChNumber(lCnt) & ChStr
				End If
			End If
		Next

		If ChStr = "" Then
			ChStr = "零"
		ElseIf Left(ChStr, 1) = "零" Then
			ChStr = ChStr.Substring(1, ChStr.Length - 1)
		End If

		Return ChStr
	End Function
#End Region

#Region "GetChNumberFill() 整數轉中文數字 （10050 => 一萬零千零百五十零）"
    Public Function GetChNumberFill(ByVal mInt As Integer) As String
        Return GetChNumberFill(mInt.ToString())
    End Function

	Public Function GetChNumberFill(ByVal mInt As Int64) As String
		Return GetChNumberFill(mInt.ToString())
	End Function

	Public Function GetChNumberFill(ByVal mInt As UInt64) As String
		Return GetChNumberFill(mInt.ToString())
	End Function

	Public Function GetChNumberFill(ByVal NumStr As String) As String
		Dim ChStr As String = "", ChSubStr As String = "", tmpStr As String = ""
		Dim iCnt As Integer = 0, jCnt As Integer = 0, kCnt As Integer = 0, lCnt As Integer = -1, nCnt As Integer = 0

		If Not IsInteger(NumStr) Then
			NumStr = "0"
		End If
		nCnt = NumStr.Length

		' 中文數字以四位數為一個處理單位(萬、億、兆、京....) 
		iCnt = nCnt Mod 4
		NumStr = Duplicate("0", 4 - iCnt) & NumStr
		nCnt = NumStr.Length

		For iCnt = 0 To nCnt - 1 Step 4
			lCnt += 1
			ChSubStr = ""

			For jCnt = 0 To 3
				kCnt = nCnt - iCnt - jCnt - 1
				tmpStr = ChNumber(NumStr.Substring(kCnt, 1))

				Select Case jCnt
					Case 0
						ChSubStr = tmpStr
						Exit Select
					Case 1
						ChSubStr = (tmpStr & "十") & ChSubStr
						Exit Select
					Case 2
						ChSubStr = (tmpStr & "百") & ChSubStr
						Exit Select
					Case 3
						ChSubStr = (tmpStr & "千") & ChSubStr
						Exit Select
					Case Else
						ChSubStr = tmpStr & ChSubStr
						Exit Select
				End Select
			Next

			If ChSubStr <> "" Then
				' 取得10000的次方中文數字 
				' 限於整數態的上限，「京」之後的中文數字是用不到 
				ChStr = ChSubStr & GetFourChNumber(lCnt) & ChStr
			End If
		Next

		While Left(ChStr, 1) = "零" AndAlso ChStr.Length > 1
			If Left(ChStr, 1) = "零" Then
				ChStr = ChStr.Substring(2, ChStr.Length - 2)
			End If
		End While

		Return ChStr
	End Function
#End Region

#Region "GetChNumberShort() 整數轉簡略中文數字 (10050 => 一零零五零)"
    Public Function GetChNumberShort(ByVal mInt As Integer) As String
        Return GetChNumberShort(mInt.ToString())
    End Function

	Public Function GetChNumberShort(ByVal mInt As Int64) As String
		Return GetChNumberShort(mInt.ToString())
	End Function

	Public Function GetChNumberShort(ByVal mInt As UInt64) As String
		Return GetChNumberShort(mInt.ToString())
	End Function

	Public Function GetChNumberShort(ByVal NumStr As String) As String
		Dim ChStr As String = ""
		Dim iCnt As Integer = 0, nCnt As Integer = 0

		If Not IsInteger(NumStr) Then
			NumStr = "0"
		End If
		nCnt = NumStr.Length

		For iCnt = 0 To nCnt - 1
			ChStr &= ChNumber(NumStr(iCnt).ToString())
		Next

		Return ChStr
	End Function
#End Region

#Region "GetChCapitalNumber() 整數轉中文大寫數字（10050 => 壹萬零伍拾）"
    Public Function GetChCapitalNumber(ByVal mInt As Integer) As String
        Return GetChCapitalNumber(mInt.ToString())
    End Function

	Public Function GetChCapitalNumber(ByVal mInt As Int64) As String
		Return GetChCapitalNumber(mInt.ToString())
	End Function

	Public Function GetChCapitalNumber(ByVal mInt As UInt64) As String
		Return GetChCapitalNumber(mInt.ToString())
	End Function

	Public Function GetChCapitalNumber(ByVal NumStr As String) As String
		Dim ChStr As String = "", ChSubStr As String = "", tmpStr As String = ""
		Dim iCnt As Integer = 0, jCnt As Integer = 0, kCnt As Integer = 0, lCnt As Integer = -1, nCnt As Integer = 0

		If Not IsInteger(NumStr) Then
			NumStr = "0"
		End If
		nCnt = NumStr.Length

		' 中文數字以四位數為一個處理單位(萬、億、兆、京....) 
		iCnt = nCnt Mod 4
		NumStr = Duplicate("0", 4 - iCnt) & NumStr
		nCnt = NumStr.Length

		For iCnt = 0 To nCnt - 1 Step 4
			lCnt += 1
			ChSubStr = ""

			For jCnt = 0 To 3
				kCnt = nCnt - iCnt - jCnt - 1
				tmpStr = ChCapitalNumber(NumStr.Substring(kCnt, 1))

				If tmpStr = "零" Then
					If Left(ChSubStr, 1) <> "零" AndAlso Left(ChSubStr, 1) <> "" Then
						ChSubStr = tmpStr & ChSubStr
					End If
				Else
					Select Case jCnt
						Case 0
							ChSubStr = tmpStr
							Exit Select
						Case 1
							ChSubStr = (tmpStr & "拾") & ChSubStr
							Exit Select
						Case 2
							ChSubStr = (tmpStr & "佰") & ChSubStr
							Exit Select
						Case 3
							ChSubStr = (tmpStr & "仟") & ChSubStr
							Exit Select
						Case Else
							ChSubStr = tmpStr & ChSubStr
							Exit Select
					End Select
				End If
			Next

			If ChSubStr = "零" AndAlso Left(ChStr, 1) <> "" AndAlso Left(ChStr, 1) <> "零" Then
				ChStr = "零" & ChStr
			Else
				If ChSubStr <> "" Then
					' 取得10000的次方中文數字 
					' 限於整數態的上限，「京」之後的中文數字是用不到 
					ChStr = ChSubStr & GetFourChNumber(lCnt) & ChStr
				End If
			End If
		Next

		If ChStr = "" Then
			ChStr = "零"
		ElseIf Left(ChStr, 1) = "零" Then
			ChStr = ChStr.Substring(1, ChStr.Length - 1)
		End If

		Return ChStr
	End Function
#End Region

#Region "GetChCapitalNumberFill() 整數轉中文大寫數字 （10050 => 壹萬零仟零佰伍拾零）"
    Public Function GetChCapitalNumberFill(ByVal mInt As Integer) As String
        Return GetChCapitalNumberFill(mInt.ToString())
    End Function

	Public Function GetChCapitalNumberFill(ByVal mInt As Int64) As String
		Return GetChCapitalNumberFill(mInt.ToString())
	End Function

	Public Function GetChCapitalNumberFill(ByVal mInt As UInt64) As String
		Return GetChCapitalNumberFill(mInt.ToString())
	End Function

	Public Function GetChCapitalNumberFill(ByVal NumStr As String) As String
		Dim ChStr As String = "", ChSubStr As String = "", tmpStr As String = ""
		Dim iCnt As Integer = 0, jCnt As Integer = 0, kCnt As Integer = 0, lCnt As Integer = -1, nCnt As Integer = 0

		If Not IsInteger(NumStr) Then
			NumStr = "0"
		End If
		nCnt = NumStr.Length

		' 中文數字以四位數為一個處理單位(萬、億、兆、京....) 
		iCnt = nCnt Mod 4
		NumStr = Duplicate("0", 4 - iCnt) & NumStr
		nCnt = NumStr.Length

		For iCnt = 0 To nCnt - 1 Step 4
			lCnt += 1
			ChSubStr = ""

			For jCnt = 0 To 3
				kCnt = nCnt - iCnt - jCnt - 1
				tmpStr = ChCapitalNumber(NumStr.Substring(kCnt, 1))

				Select Case jCnt
					Case 0
						ChSubStr = tmpStr
						Exit Select
					Case 1
						ChSubStr = (tmpStr & "拾") & ChSubStr
						Exit Select
					Case 2
						ChSubStr = (tmpStr & "佰") & ChSubStr
						Exit Select
					Case 3
						ChSubStr = (tmpStr & "仟") & ChSubStr
						Exit Select
					Case Else
						ChSubStr = tmpStr & ChSubStr
						Exit Select
				End Select
			Next

			If ChSubStr <> "" Then
				' 取得10000的次方中文數字 
				' 限於整數態的上限，「京」之後的中文數字是用不到 
				ChStr = ChSubStr & GetFourChNumber(lCnt) & ChStr
			End If
		Next

		While Left(ChStr, 1) = "零" AndAlso ChStr.Length > 1
			If Left(ChStr, 1) = "零" Then
				ChStr = ChStr.Substring(2, ChStr.Length - 2)
			End If
		End While

		Return ChStr
	End Function
#End Region

#Region "GetChCapitalNumberShort() 整數轉簡略中文大寫數字 (10050 => 壹零零伍零)"
    Public Function GetChCapitalNumberShort(ByVal mInt As Integer) As String
        Return GetChCapitalNumberShort(mInt.ToString())
    End Function

	Public Function GetChCapitalNumberShort(ByVal mInt As Int64) As String
		Return GetChCapitalNumberShort(mInt.ToString())
	End Function

	Public Function GetChCapitalNumberShort(ByVal mInt As UInt64) As String
		Return GetChCapitalNumberShort(mInt.ToString())
	End Function

	Public Function GetChCapitalNumberShort(ByVal NumStr As String) As String
		Dim ChStr As String = ""
		Dim iCnt As Integer = 0, nCnt As Integer = 0

		If Not IsInteger(NumStr) Then
			NumStr = "0"
		End If
		nCnt = NumStr.Length

		For iCnt = 0 To nCnt - 1
			ChStr &= ChCapitalNumber(NumStr(iCnt).ToString())
		Next

		Return ChStr
	End Function
#End Region
End Class