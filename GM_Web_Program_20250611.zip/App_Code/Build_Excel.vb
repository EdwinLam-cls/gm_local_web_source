﻿'---------------------------------------------------------------------------- 
'程式功能	公用函數
'設計人員	 
'修改人員 
'備註說明	支援 MS Excel XP 及以上版本 (MS Excel 2000 SP1 即可使用，但有部份設定無效)
'			本範例以 Excel 2003 為標準範本設計
'			產生以 UniCode 編碼的 Excel 檔案
'---------------------------------------------------------------------------- 
Imports System.Data.SqlClient
Imports System.Text
Imports System.Web
Imports System.Web.Configuration

Public Class Build_Excel
	' Excel 檔案格式預設值
    Private _author As String = ""                      ' 作者
    Private _company As String = ""                     ' 公司
    Private _title As String = ""                       ' 標題
    Private _subject As String = ""                     ' 主旨
    Private _sheet As String = ""                       ' 工作表名稱 (Sheet)
	Private _top As String = ".79in"					' 上邊界
	Private _bottom As String = ".79in"					' 下邊界
	Private _left As String = ".79in"					' 左邊界
	Private _right As String = ".79in"					' 右邊界
	Private _head As String = ".59in"					' 頁首距離
	Private _foot As String = ".71in"					' 頁尾距離
	Private _customerstyle As String = ""				' 自定格式 CSS
	Private _fsize As String = "12.0"					' 預設字型大小 (pt)
	Private _fname As String = "新細明體"				' 預設中文字型名稱
	Private _paper As String = "A4"						' 紙張格式
	Private _paperindex As String = "9"					' 紙張格式 Letter=L A3=8 A4=9 A5=11 B4=12 B5=13
	Private _landscape As Boolean = False				' 橫印 (true:橫印 false:直印)
	Private _pagealign As Boolean = True				' 頁面水平置中
	Private _pagevalign As Boolean = False				' 頁面垂直置中
	Private _hstring As String = "專題實作範例"			' 頁首文字
	Private _hfsize As String = "8"						' 頁首字型大小 (pt)
	Private _hfname As String = "新細明體"				' 頁首中文字型名稱
	Private _halign As String = "R"						' 頁首文字位置
	Private _fstring As String = "&P\/&N"				' 頁尾文字 (頁碼/總頁碼) 
	Private _ffsize As String = "8"						' 頁尾字型大小 (pt)
	Private _ffname As String = "新細明體"				' 頁尾中文字型名稱
	Private _falign As String = "C"						' 頁尾文字位置

    Public Property Author() As String
        Get
            Return _author
        End Get
        Set(ByVal value As String)
            Me._author = value
        End Set
    End Property

    Public Property Company() As String
        Get
            Return _company
        End Get
        Set(ByVal value As String)
            Me._company = value
        End Set
    End Property

    Public Property Title() As String
        Get
            Return _title
        End Get
        Set(ByVal value As String)
            Me._title = value
        End Set
    End Property

    Public Property Subject() As String
        Get
            Return _subject
        End Get
        Set(ByVal value As String)
            Me._subject = value
        End Set
    End Property

    Public Property Sheet() As String
        Get
            Return _sheet
        End Get
        Set(ByVal value As String)
            Me._sheet = value
        End Set
    End Property

    Public Property Page_Align() As Boolean
        Get
            Return _pagealign
        End Get
        Set(ByVal value As Boolean)
            Me._pagealign = value
        End Set
    End Property

    Public Property Page_VAlign() As Boolean
        Get
            Return _pagevalign
        End Get
        Set(ByVal value As Boolean)
            Me._pagevalign = value
        End Set
    End Property

    Public ReadOnly Property Paper() As String
        Get
            Return _paper
        End Get
    End Property

    Public ReadOnly Property Top() As String
        Get
            Return _top
        End Get
    End Property

    Public ReadOnly Property Left() As String
        Get
            Return _left
        End Get
    End Property

    Public ReadOnly Property Bottom() As String
        Get
            Return _bottom
        End Get
    End Property

    Public ReadOnly Property Right() As String
        Get
            Return _right
        End Get
    End Property

    Public ReadOnly Property HeadString() As String
        Get
            Return _hstring
        End Get
    End Property

    Public ReadOnly Property HeadFontName() As String
        Get
            Return _hfname
        End Get
    End Property

    Public ReadOnly Property HeadFontSize() As Single
        Get
            Return Single.Parse(_hfsize)
        End Get
    End Property

    Public ReadOnly Property HeadAlign() As String
        Get
            Return _halign
        End Get
    End Property

    Public ReadOnly Property HeadHeight() As String
        Get
            Return _head
        End Get
    End Property

    Public ReadOnly Property FootString() As String
        Get
            Return _fstring
        End Get
    End Property

    Public ReadOnly Property FootFontName() As String
        Get
            Return _ffname
        End Get
    End Property

    Public ReadOnly Property FootFontSize() As Single
        Get
            Return Single.Parse(_ffsize)
        End Get
    End Property

    Public ReadOnly Property FootAlign() As String
        Get
            Return _falign
        End Get
    End Property

    Public ReadOnly Property FootHeight() As String
        Get
            Return _foot
        End Get
    End Property

    Public Property DefineStyle() As String
        Get
            Return _customerstyle
        End Get
        Set(ByVal value As String)
            Me._customerstyle = value
        End Set
    End Property

    Public Property FontSize() As Single
        Get
            Return Single.Parse(_fsize)
        End Get
        Set(ByVal value As Single)
            Me._fsize = value.ToString()
        End Set
    End Property

    Public Property FontName() As String
        Get
            Return _fname
        End Get
        Set(ByVal value As String)
            Me._fname = value
        End Set
    End Property

    Public Function SetPaper(ByVal ptype As String, ByVal pstyle As String) As Boolean
        Dim ckbool As Boolean = True

        ptype = ptype.ToUpper()
        pstyle = pstyle.ToUpper()

        If pstyle = "H" OrElse pstyle = "S" Then
            Select Case ptype
                Case "A3"
                    _paper = "A3"
                    _paperindex = "8"
                    Exit Select

                Case "A4"
                    _paper = "A4"
                    _paperindex = "9"
                    Exit Select

                Case "A5"
                    _paper = "A5"
                    _paperindex = "10"
                    Exit Select

                Case "B4"
                    _paper = "B4"
                    _paperindex = "12"
                    Exit Select

                Case "B5"
                    _paper = "B5"
                    _paperindex = "13"
                    Exit Select

                Case "LETTER"
                    _paper = "LETTER"
                    _paperindex = "L"
                    Exit Select
                Case Else

                    ckbool = False
                    Exit Select
            End Select

            If ckbool Then
                If pstyle = "H" Then
                    _landscape = True
                Else
                    _landscape = False
                End If
            End If
        Else
            ckbool = False
        End If

        Return ckbool
    End Function

    Public Sub SetHeadString(ByVal hstring As String, ByVal hfname As String, ByVal hfsize As Single, ByVal halign As String)
        _hstring = hstring
        _hfname = hfname
        _hfsize = hfsize.ToString()

        halign = halign.ToLower()
        Select Case halign
            Case "center"
                _halign = "C"
                Exit Select
            Case "left"
                _halign = "L"
                Exit Select
            Case "right"
                _halign = "R"
                Exit Select
            Case Else
                _halign = "R"
                Exit Select
        End Select
    End Sub

    Public Sub SetFootString(ByVal fstring As String, ByVal ffname As String, ByVal ffsize As Single, ByVal falign As String)
        _fstring = fstring
        _ffname = ffname
        _ffsize = ffsize.ToString()

        falign = falign.ToLower()
        Select Case falign
            Case "center"
                _falign = "C"
                Exit Select
            Case "left"
                _falign = "L"
                Exit Select
            Case "right"
                _falign = "R"
                Exit Select
            Case Else
                _falign = "R"
                Exit Select
        End Select
    End Sub

    Public Function SetHeadHeight(ByVal hheight As Single, ByVal hunit As String) As Boolean
        Dim ckbool As Boolean = False

        hunit = hunit.ToLower()

        If hunit = "in" OrElse hunit = "cm" OrElse hunit = "mm" OrElse hunit = "pt" Then
            _head = hheight.ToString() & hunit
        Else
            ckbool = False
        End If

        Return ckbool
    End Function

    Public Function SetFootHeight(ByVal fheight As Single, ByVal funit As String) As Boolean
        Dim ckbool As Boolean = False

        funit = funit.ToLower()

        If funit = "in" OrElse funit = "cm" OrElse funit = "mm" OrElse funit = "pt" Then
            _foot = fheight.ToString() & funit
        Else
            ckbool = False
        End If

        Return ckbool
    End Function

    Public Function SetMagin(ByVal [stop] As Single, ByVal sleft As Single, ByVal sbottom As Single, ByVal sright As Single, ByVal sunit As String) As Boolean
        Dim ckbool As Boolean = False

        sunit = sunit.ToLower()

        If sunit = "in" OrElse sunit = "cm" OrElse sunit = "mm" OrElse sunit = "pt" Then
            _top = [stop].ToString() & sunit
            _left = sleft.ToString() & sunit
            _bottom = sbottom.ToString() & sunit
            _right = sright.ToString() & sunit
        Else
            ckbool = False
        End If
        Return ckbool
    End Function

    Public Function HeadData() As String
        Dim hstr As New StringBuilder()

        hstr.AppendLine("<html xmlns:o=""urn:schemas-microsoft-com:office:office""")
        hstr.AppendLine("xmlns:x=""urn:schemas-microsoft-com:office:excel""")
        hstr.AppendLine("xmlns=""http://www.w3.org/TR/REC-html40"">")
        hstr.AppendLine("<head>")
        hstr.AppendLine("<meta http-equiv=Content-Type content=""text/html; charset=utf-8"">")
        hstr.AppendLine("<meta name=ProgId content=Excel.Sheet>")
        hstr.AppendLine("<meta name=Generator content=""Microsoft Excel 11"">")
        hstr.AppendLine("<title>" & _title & "</title>")
        hstr.AppendLine("<!--[if gte mso 9]><xml>")
        hstr.AppendLine("<o:DocumentProperties>")
        hstr.AppendLine("<o:Subject>" & _subject & "</o:Subject>")
        hstr.AppendLine("<o:Author>" & _author & "</o:Author>")
        hstr.AppendLine("<o:Company>" & _company & "</o:Company>")
        hstr.AppendLine("<o:Version>11.9999</o:Version>")
        hstr.AppendLine("</o:DocumentProperties>")
        hstr.AppendLine("<o:OfficeDocumentSettings>")
        hstr.AppendLine("<o:RelyOnVML/>")
        hstr.AppendLine("<o:AllowPNG/>")
        hstr.AppendLine("</o:OfficeDocumentSettings>")
        hstr.AppendLine("</xml><![endif]-->")
        hstr.AppendLine("<style>")
        hstr.AppendLine("<!--table")
        hstr.AppendLine("{mso-displayed-decimal-separator:""\."";")
        hstr.AppendLine("mso-displayed-thousand-separator:""\,"";}")
        hstr.AppendLine("@page")

        If _hstring <> "" Then
            ' 頁首文字
            hstr.AppendLine("{mso-header-data:""&" & _halign & "&\0022" & _hfname & "\,標準\0022&" & _hfsize & _hstring & """;")
        End If

        If _fstring <> "" Then
            ' 頁尾文字
            hstr.AppendLine("mso-footer-data:""&" & _falign & "&\0022" & _ffname & "\,標準\0022&" & _ffsize & _fstring & """;")
        End If

        hstr.AppendLine("margin:" & _top & " " & _left & " " & _bottom & " " & _right & ";"");")

        If _landscape Then
            ' 橫印
            hstr.AppendLine("mso-page-orientation:landscape;")
        End If

        If _pagealign Then
            ' 水平置中
            hstr.AppendLine("mso-horizontal-page-align:center;")
        End If

        If _pagevalign Then
            ' 垂直置中
            hstr.AppendLine("mso-vertical-page-align:center;")
        End If

        hstr.AppendLine("mso-header-margin:" & _head)
        hstr.AppendLine("mso-footer-margin:" & _foot & "}")
        hstr.AppendLine("tr")
        hstr.AppendLine("{mso-height-source:auto;")
        hstr.AppendLine("mso-ruby-visibility:none;}")
        hstr.AppendLine("col")
        hstr.AppendLine("{mso-width-source:auto;")
        hstr.AppendLine("mso-ruby-visibility:none;}")
        hstr.AppendLine("br")
        hstr.AppendLine("{mso-data-placement:same-cell;}")
        hstr.AppendLine(".style0")
        hstr.AppendLine("{mso-number-format:General;")
        hstr.AppendLine("text-align:general;")
        hstr.AppendLine("vertical-align:middle;")
        hstr.AppendLine("white-space:nowrap;")
        hstr.AppendLine("mso-rotate:0;")
        hstr.AppendLine("mso-background-source:auto;")
        hstr.AppendLine("mso-pattern:auto;")
        hstr.AppendLine("color:windowtext;")
        hstr.AppendLine("font-size:" & _fsize & "pt;")
        hstr.AppendLine("font-weight:400;")
        hstr.AppendLine("font-style:normal;")
        hstr.AppendLine("text-decoration:none;")
        hstr.AppendLine("font-family:" & _fname & ", serif;")
        hstr.AppendLine("mso-font-charset:136;")
        hstr.AppendLine("border:none;")
        hstr.AppendLine("mso-protection:locked visible;")
        hstr.AppendLine("mso-style-name:一般;")
        hstr.AppendLine("mso-style-id:0;}")
        hstr.AppendLine("td")
        hstr.AppendLine("{mso-style-parent:style0;")
        hstr.AppendLine("padding-top:1px;")
        hstr.AppendLine("padding-right:1px;")
        hstr.AppendLine("padding-left:1px;")
        hstr.AppendLine("mso-ignore:padding;")
        hstr.AppendLine("color:windowtext;")
        hstr.AppendLine("font-size:" & _fsize & "pt;")
        hstr.AppendLine("font-weight:400;")
        hstr.AppendLine("font-style:normal;")
        hstr.AppendLine("text-decoration:none;")
        hstr.AppendLine("font-family:" & _fname & ", serif;")
        hstr.AppendLine("mso-font-charset:136;")
        hstr.AppendLine("mso-number-format:General;")
        hstr.AppendLine("text-align:general;")
        hstr.AppendLine("vertical-align:middle;")
        hstr.AppendLine("border:none;")
        hstr.AppendLine("mso-background-source:auto;")
        hstr.AppendLine("mso-pattern:auto;")
        hstr.AppendLine("mso-protection:locked visible;")
        hstr.AppendLine("white-space:nowrap;")
        hstr.AppendLine("mso-rotate:0;}")
        hstr.AppendLine(_customerstyle)
        ' 自訂 CSS 格式
        hstr.AppendLine("ruby")
        hstr.AppendLine("{ruby-align:left;}")
        hstr.AppendLine("rt")
        hstr.AppendLine("{color:windowtext;")
        hstr.AppendLine("font-size:9.0pt;")
        hstr.AppendLine("font-weight:400;")
        hstr.AppendLine("font-style:normal;")
        hstr.AppendLine("text-decoration:none;")
        hstr.AppendLine("font-family:" & _fname & ", serif;")
        hstr.AppendLine("mso-font-charset:136;")
        hstr.AppendLine("mso-char-type:none;")
        hstr.AppendLine("display:none;}")
        hstr.AppendLine("-->")
        hstr.AppendLine("</style>")
        hstr.AppendLine("<!--[if gte mso 9]><xml>")
        hstr.AppendLine("<x:ExcelWorkbook>")
        hstr.AppendLine("<x:ExcelWorksheets>")
        hstr.AppendLine("<x:ExcelWorksheet>")
        hstr.AppendLine("<x:Name>" & _sheet & "</x:Name>")
        hstr.AppendLine("<x:WorksheetOptions>")
        hstr.AppendLine("<x:DefaultRowHeight>330</x:DefaultRowHeight>")
        hstr.AppendLine("<x:FitToPage/>")
        hstr.AppendLine("<x:FitToPage/>")
        hstr.AppendLine("<x:Print>")
        hstr.AppendLine("<x:FitHeight>1000</x:FitHeight>")
        hstr.AppendLine("<x:ValidPrinterInfo/>")

        If _paperindex <> "L" Then
            ' 紙張格式
            hstr.AppendLine("<x:PaperSizeIndex>" & _paperindex & "</x:PaperSizeIndex>")
        End If

        hstr.AppendLine("<x:HorizontalResolution>600</x:HorizontalResolution>")
        hstr.AppendLine("<x:VerticalResolution>600</x:VerticalResolution>")
        hstr.AppendLine("<x:NumberofCopies>0</x:NumberofCopies>")
        hstr.AppendLine("</x:Print>")
        hstr.AppendLine("<x:Selected/>")
        hstr.AppendLine("<x:Panes>")
        hstr.AppendLine("<x:Pane>")
        hstr.AppendLine("<x:Number>3</x:Number>")
        'hstr.AppendLine("<x:RangeSelection>$A$1:$A$1</x:RangeSelection>");
        hstr.AppendLine("</x:Pane>")
        hstr.AppendLine("</x:Panes>")
        hstr.AppendLine("<x:ProtectContents>False</x:ProtectContents>")
        hstr.AppendLine("<x:ProtectObjects>False</x:ProtectObjects>")
        hstr.AppendLine("<x:ProtectScenarios>False</x:ProtectScenarios>")
        hstr.AppendLine("</x:WorksheetOptions>")
        hstr.AppendLine("</x:ExcelWorksheet>")
        hstr.AppendLine("</x:ExcelWorksheets>")
        'hstr.AppendLine("<x:WindowHeight>12690</x:WindowHeight>");
        'hstr.AppendLine("<x:WindowWidth>18180</x:WindowWidth>");
        'hstr.AppendLine("<x:WindowTopX>480</x:WindowTopX>");
        'hstr.AppendLine("<x:WindowTopY>105</x:WindowTopY>");
        hstr.AppendLine("<x:ProtectStructure>False</x:ProtectStructure>")
        hstr.AppendLine("<x:ProtectWindows>False</x:ProtectWindows>")
        hstr.AppendLine("</x:ExcelWorkbook>")
        hstr.AppendLine("</xml><![endif]-->")
        hstr.AppendLine("</head>")
        hstr.AppendLine("<body link=blue vlink=purple>")

        Return hstr.ToString()
    End Function

    Public Function FootData() As String
        Dim fstr As New StringBuilder()

        fstr.AppendLine("</body>")
        fstr.AppendLine("</html>")

        Return fstr.ToString()
    End Function
End Class