﻿Imports System.Web.Compilation
Imports System.CodeDom

<ExpressionPrefix("DBConnUtil")> _
Public Class DBConnUtilExpressionBuilder
    Inherits System.Web.Compilation.ConnectionStringsExpressionBuilder
    Public Sub New()

    End Sub

    Public Overrides Function EvaluateExpression(ByVal target As Object, ByVal entry As BoundPropertyEntry, ByVal parsedData As Object, ByVal context As ExpressionBuilderContext) As Object
        Dim pair As Pair = DirectCast(parsedData, Pair)
        Dim first As String = CStr(pair.First)
        Dim second As Boolean = CBool(pair.Second)
        If second Then
            Return DBConnUtil.GetConnectionString().ConnectionString
        End If
        Return DBConnUtil.GetConnectionString().ProviderName
    End Function

    Public Overrides Function GetCodeExpression(ByVal entry As BoundPropertyEntry, ByVal parsedData As Object, ByVal context As ExpressionBuilderContext) As CodeExpression
        Dim pair As Pair = DirectCast(parsedData, Pair)
        Dim first As String = CStr(pair.First)
        If CBool(pair.Second) Then
            Return New CodeMethodInvokeExpression(New CodeTypeReferenceExpression(MyClass.GetType), "GetConnectionString", New CodeExpression() {New CodePrimitiveExpression(first)})
        End If
        Return New CodeMethodInvokeExpression(New CodeTypeReferenceExpression(MyClass.GetType), "GetConnectionStringProviderName", New CodeExpression() {New CodePrimitiveExpression(first)})
    End Function


    Public Overloads Shared Function GetConnectionString(ByVal connectionStringName As String) As String
        Dim settings As ConnectionStringSettings = DBConnUtil.GetConnectionString()
        Return settings.ConnectionString
    End Function

    Public Overloads Shared Function GetConnectionStringProviderName(ByVal connectionStringName As String) As String
        Dim settings As ConnectionStringSettings = DBConnUtil.GetConnectionString()
        Return settings.ProviderName
    End Function

    Public Overrides Function ParseExpression(ByVal expression As String, ByVal propertyType As Type, ByVal context As ExpressionBuilderContext) As Object
        Dim x As String = String.Empty
        Dim y As Boolean = True
        If (Not expression Is Nothing) Then
            If expression.EndsWith(".connectionstring", StringComparison.OrdinalIgnoreCase) Then
                x = Server.CurrentEnvironment
            ElseIf expression.EndsWith(".providername", StringComparison.OrdinalIgnoreCase) Then
                y = False
                x = Server.CurrentEnvironment
            Else
                x = Server.CurrentEnvironment
            End If
        End If
        Return New Pair(x, y)
    End Function



End Class
