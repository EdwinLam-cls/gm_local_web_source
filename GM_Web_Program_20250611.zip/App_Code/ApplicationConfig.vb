﻿
Public Class ApplicationConfig
	Inherits System.Configuration.ConfigurationSection
	Private Shared ReadOnly ConfigSection As ApplicationConfig = DirectCast(System.Configuration.ConfigurationManager.GetSection(String.Format("applicationEnvironment/{0}", Server.CurrentEnvironment.ToString().ToLower())), ApplicationConfig)

	Public Shared ReadOnly Property Instance() As ApplicationConfig
		Get
			Return ConfigSection
		End Get
	End Property

	Private Sub New()
	End Sub

	<System.Configuration.ConfigurationProperty("applicationName", IsRequired := True)> _
	Public ReadOnly Property ApplicationName() As String
		Get
			Return Me("applicationName").ToString()
		End Get
	End Property


    <System.Configuration.ConfigurationProperty("adminsGroup", IsRequired:=True)> _
 Public ReadOnly Property adminsGroup() As String
        Get
            Return Me("adminsGroup").ToString()
        End Get
    End Property
End Class